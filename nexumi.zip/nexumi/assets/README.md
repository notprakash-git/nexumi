# assets/

Place your VRM model at:
  assets/3d_model/nexumi.vrm
  assets/3d_model/nexumi_original.vrm   (backup)

Expression blend shape configs are in:
  assets/3d_model/expressions/

Wake word keyword file:
  assets/nexumi_en_linux.ppn   ← download from https://console.picovoice.ai

Optional TTS audio cache goes in:
  assets/sounds/
