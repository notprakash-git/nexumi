"""
tests/test_hime.py
==================
Comprehensive tests for the 3-D model expression system (Hime Display).

Tests are skipped automatically when Hime is not installed.
All controller functions are mocked when unavailable.
Includes expression blending, timing, error handling, queuing, clamping,
process lifecycle, fallback viewer, and concurrency tests.
"""

from __future__ import annotations

import json
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def hime_available() -> bool:
    """Check whether Hime Display dependencies are importable."""
    try:
        import src.integration.hime_controller as hc
        return getattr(hc, "HIME_AVAILABLE", False)
    except ImportError:
        return False


@pytest.fixture
def expression_mapper(mock_expression_mapper: MagicMock) -> Any:
    """Return the expression mapper module (real or mocked)."""
    from src.integration import expression_mapper
    return expression_mapper


@pytest.fixture
def hime_controller(mock_hime_controller: MagicMock) -> Any:
    """Return the Hime controller module (real or mocked)."""
    from src.integration import hime_controller
    return hime_controller


@pytest.fixture
def sample_blendshapes() -> Dict[str, float]:
    """Provide sample blendshape weights for testing."""
    return {
        "eyeBlinkLeft": 0.3,
        "eyeBlinkRight": 0.3,
        "mouthSmileLeft": 0.8,
        "mouthSmileRight": 0.8,
        "browInnerUp": 0.2,
        "browOuterUpLeft": 0.4,
        "browOuterUpRight": 0.4,
        "cheekPuff": 0.1,
        "noseSneerLeft": 0.0,
        "noseSneerRight": 0.0,
        "mouthFrownLeft": 0.0,
        "mouthFrownRight": 0.0,
        "jawOpen": 0.15,
        "mouthClose": 0.0,
    }


@pytest.fixture
def invalid_expression_json(tmp_path: Path) -> Path:
    """Create a malformed expression JSON file."""
    expr_dir = tmp_path / "expressions"
    expr_dir.mkdir()
    bad_file = expr_dir / "broken.json"
    bad_file.write_text("{not valid json")
    return bad_file


@pytest.fixture
def invalid_schema_json(tmp_path: Path) -> Path:
    """Create an expression JSON with missing blend_shapes key."""
    expr_dir = tmp_path / "expressions"
    expr_dir.mkdir()
    bad_file = expr_dir / "no_blendshapes.json"
    bad_file.write_text(json.dumps({"duration": 1.0}))  # Missing blend_shapes
    return bad_file


@pytest.fixture
def expression_dir(tmp_path: Path) -> Path:
    """Create a temporary expression directory with valid JSON files."""
    expr_dir = tmp_path / "expressions"
    expr_dir.mkdir()
    for emotion in ["neutral", "happy", "sad"]:
        fpath = expr_dir / f"{emotion}.json"
        fpath.write_text(json.dumps({
            "blend_shapes": {
                "eyeBlinkLeft": 0.1,
                "mouthSmileLeft": 0.8 if emotion == "happy" else 0.0,
                "mouthFrownLeft": 0.8 if emotion == "sad" else 0.0,
            },
            "duration": 1.0,
        }))
    return expr_dir


# ---------------------------------------------------------------------------
# TestExpressionMapper
# ---------------------------------------------------------------------------
class TestExpressionMapper:
    """Validate expression JSON definitions and blendshape structures."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_all_emotion_json_files_exist(self, expression_mapper: Any) -> None:
        """Every listed emotion must have a corresponding JSON file."""
        emotions = expression_mapper.list_emotions()
        assert len(emotions) > 0, "No emotions defined"
        for emotion in emotions:
            path = Path("assets/expressions") / f"{emotion}.json"
            assert path.exists(), f"Missing expression file: {path}"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_shapes_structure(self, expression_mapper: Any) -> None:
        """Each emotion JSON must contain a valid blend_shapes dict."""
        for emotion in expression_mapper.list_emotions():
            shapes = expression_mapper.get_blend_shapes(emotion)
            assert isinstance(shapes, dict), f"{emotion}: blend_shapes must be a dict"
            for key, value in shapes.items():
                assert isinstance(key, str), f"{emotion}: key must be string"
                assert isinstance(value, (int, float)), f"{emotion}.{key} must be numeric"
                assert 0.0 <= value <= 1.0, f"{emotion}.{key} out of range [0,1]"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_shapes_keys_valid(self, expression_mapper: Any) -> None:
        """Blendshape keys should follow standard naming."""
        valid_prefixes = ("eye", "mouth", "brow", "cheek", "nose", "jaw", "chin", "head")
        for emotion in expression_mapper.list_emotions():
            shapes = expression_mapper.get_blend_shapes(emotion)
            for key in shapes.keys():
                assert any(key.startswith(p) for p in valid_prefixes), (
                    f"{emotion}: Invalid blendshape key '{key}'"
                )

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_neutral_has_zero_weights(self, expression_mapper: Any) -> None:
        """Neutral expression should have minimal blendshape weights."""
        shapes = expression_mapper.get_blend_shapes("neutral")
        for key, value in shapes.items():
            assert value <= 0.1, f"Neutral.{key} should be near 0, got {value}"

    def test_get_blend_shapes_mocked(self, expression_mapper: Any) -> None:
        """When mocked, get_blend_shapes should return an empty dict safely."""
        shapes = expression_mapper.get_blend_shapes("happy")
        assert isinstance(shapes, dict)

    def test_list_emotions_returns_list(self, expression_mapper: Any) -> None:
        """list_emotions should return a list of strings."""
        emotions = expression_mapper.list_emotions()
        assert isinstance(emotions, list)
        for emotion in emotions:
            assert isinstance(emotion, str)
            assert len(emotion) > 0

    def test_validate_expression(self, expression_mapper: Any) -> None:
        """validate_expression should return True for valid emotions."""
        for emotion in expression_mapper.list_emotions():
            assert expression_mapper.validate_expression(emotion) is True

    def test_validate_expression_invalid(self, expression_mapper: Any) -> None:
        """validate_expression should return False for invalid emotions."""
        assert expression_mapper.validate_expression("nonexistent_emotion_123") is False
        assert expression_mapper.validate_expression("") is False

    def test_invalid_expression_json_raises(self, expression_mapper: Any, invalid_expression_json: Path) -> None:
        """Malformed expression JSON file should raise a clear error."""
        with pytest.raises((json.JSONDecodeError, ValueError)):
            expression_mapper.load_expression_file(invalid_expression_json)

    def test_invalid_schema_raises(self, expression_mapper: Any, invalid_schema_json: Path) -> None:
        """Expression JSON missing blend_shapes key should raise ValueError."""
        with pytest.raises((KeyError, ValueError)):
            expression_mapper.load_expression_file(invalid_schema_json)

    def test_missing_expression_directory_fallback(self, expression_mapper: Any, tmp_path: Path) -> None:
        """Missing expression directory should fallback to default expressions or log a warning."""
        missing_dir = tmp_path / "nonexistent_expressions"
        with patch("pathlib.Path.exists", return_value=False):
            result = expression_mapper.get_blend_shapes("neutral")
        # Should return defaults or empty without crashing
        assert isinstance(result, dict)


# ---------------------------------------------------------------------------
# TestHimeController
# ---------------------------------------------------------------------------
class TestHimeController:
    """Test expression application lifecycle."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_apply_expression_runs(self, hime_controller: Any) -> None:
        """apply_expression should not raise for valid emotions."""
        for emotion in ["happy", "sad", "excited", "angry", "flirty", "sleepy"]:
            hime_controller.apply_expression(emotion, duration=0.1)

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_apply_expression_with_duration(self, hime_controller: Any) -> None:
        """apply_expression with duration should complete in expected time."""
        start = time.time()
        hime_controller.apply_expression("happy", duration=0.2)
        elapsed = time.time() - start
        assert elapsed >= 0.15, "Expression should take at least the duration"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_reset_expression_runs(self, hime_controller: Any) -> None:
        """reset_expression should not raise."""
        hime_controller.reset_expression()

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_get_current_expression(self, hime_controller: Any) -> None:
        """get_current_expression should return the active expression."""
        hime_controller.apply_expression("happy", duration=0.1)
        current = hime_controller.get_current_expression()
        assert current == "happy"

    def test_mocked_controller_noop(self, hime_controller: Any) -> None:
        """When Hime is unavailable, controller calls should be no-ops."""
        hime_controller.apply_expression("happy", duration=1.0)
        hime_controller.reset_expression()
        # Should not raise even though HIME_AVAILABLE is False

    def test_apply_invalid_expression_mocked(self, hime_controller: Any) -> None:
        """Applying invalid expression when mocked should not raise."""
        hime_controller.apply_expression("invalid_emotion", duration=1.0)
        # Mock silently ignores invalid expressions

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_hime_display_process_start_stop(self, hime_controller: Any, mocker: "MockerFixture") -> None:
        """Hime Display subprocess should be launched and terminated correctly."""
        mock_popen = mocker.patch("subprocess.Popen")
        mock_process = MagicMock()
        mock_process.poll.return_value = None
        mock_process.terminate = MagicMock()
        mock_process.wait = MagicMock(return_value=0)
        mock_popen.return_value = mock_process

        hime_controller.start_display()
        mock_popen.assert_called_once()

        hime_controller.stop_display()
        mock_process.terminate.assert_called_once()

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_process_start_stop_idempotence(self, hime_controller: Any, mocker: "MockerFixture") -> None:
        """Calling start_display twice should not launch two processes."""
        mock_popen = mocker.patch("subprocess.Popen")
        mock_process = MagicMock()
        mock_process.pid = 12345
        mock_popen.return_value = mock_process

        hime_controller.start_display()
        hime_controller.start_display()  # Second call
        assert mock_popen.call_count == 1, "Should not launch duplicate process"

    def test_fallback_html_viewer_loads(self, hime_controller: Any, tmp_path: Path) -> None:
        """When Hime not available, the fallback 3d_viewer.html loads without errors."""
        viewer_path = tmp_path / "3d_viewer.html"
        viewer_path.write_text("""<!DOCTYPE html><html><body>Fallback viewer</body></html>""")
        result = hime_controller.load_fallback_viewer(str(viewer_path))
        assert result is not None
        assert "viewer" in result.lower() or result == ""


# ---------------------------------------------------------------------------
# TestExpressionBlending
# ---------------------------------------------------------------------------
class TestExpressionBlending:
    """Test expression blending, clamping, and transitions."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_two_expressions(self, expression_mapper: Any) -> None:
        """Blending two expressions should produce intermediate weights."""
        shapes1 = expression_mapper.get_blend_shapes("happy")
        shapes2 = expression_mapper.get_blend_shapes("sad")
        blended = expression_mapper.blend_expressions(shapes1, shapes2, ratio=0.5)

        for key in set(shapes1.keys()) | set(shapes2.keys()):
            v1 = shapes1.get(key, 0.0)
            v2 = shapes2.get(key, 0.0)
            expected = (v1 + v2) / 2
            actual = blended.get(key, 0.0)
            assert abs(actual - expected) < 0.01, (
                f"Blend mismatch for {key}: expected {expected}, got {actual}"
            )

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_ratio_zero(self, expression_mapper: Any) -> None:
        """Ratio 0 should return first expression unchanged."""
        shapes1 = expression_mapper.get_blend_shapes("happy")
        shapes2 = expression_mapper.get_blend_shapes("sad")
        blended = expression_mapper.blend_expressions(shapes1, shapes2, ratio=0.0)
        assert blended == shapes1

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_ratio_one(self, expression_mapper: Any) -> None:
        """Ratio 1 should return second expression unchanged."""
        shapes1 = expression_mapper.get_blend_shapes("happy")
        shapes2 = expression_mapper.get_blend_shapes("sad")
        blended = expression_mapper.blend_expressions(shapes1, shapes2, ratio=1.0)
        assert blended == shapes2

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_blend_clamped_to_range(self, expression_mapper: Any) -> None:
        """Blend ratio should be clamped to [0, 1]."""
        shapes1 = expression_mapper.get_blend_shapes("happy")
        shapes2 = expression_mapper.get_blend_shapes("sad")

        # Test negative ratio
        blended_neg = expression_mapper.blend_expressions(shapes1, shapes2, ratio=-0.5)
        assert blended_neg == shapes1

        # Test ratio > 1
        blended_over = expression_mapper.blend_expressions(shapes1, shapes2, ratio=1.5)
        assert blended_over == shapes2

    def test_blend_clamped_extreme_values(self, expression_mapper: Any) -> None:
        """Blend ratio should clamp for extreme values like -2 and 2."""
        shapes1 = {"eyeBlinkLeft": 0.5}
        shapes2 = {"eyeBlinkLeft": 1.0}

        blended_neg2 = expression_mapper.blend_expressions(shapes1, shapes2, ratio=-2.0)
        assert blended_neg2 == shapes1

        blended_pos2 = expression_mapper.blend_expressions(shapes1, shapes2, ratio=2.0)
        assert blended_pos2 == shapes2

    def test_blend_shape_weight_clamping(self, expression_mapper: Any) -> None:
        """Weights >1.0 should be clamped to 1.0, <0 to 0."""
        raw_shapes = {
            "eyeBlinkLeft": 1.5,   # Should clamp to 1.0
            "mouthSmileLeft": -0.3,  # Should clamp to 0.0
            "jawOpen": 0.5,        # Should stay 0.5
        }
        clamped = expression_mapper.clamp_blend_shapes(raw_shapes)
        assert clamped["eyeBlinkLeft"] == 1.0
        assert clamped["mouthSmileLeft"] == 0.0
        assert clamped["jawOpen"] == 0.5


# ---------------------------------------------------------------------------
# TestExpressionQueuing
# ---------------------------------------------------------------------------
class TestExpressionQueuing:
    """Test expression queuing, priority, and state management."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_queuing(self, hime_controller: Any) -> None:
        """When expressions are applied faster than processed, they should queue or replace current."""
        hime_controller.apply_expression("happy", duration=1.0)
        hime_controller.apply_expression("sad", duration=1.0)
        hime_controller.apply_expression("angry", duration=1.0)
        # Should not crash; either queued or last-one-wins
        current = hime_controller.get_current_expression()
        assert current in ["happy", "sad", "angry", "neutral"]

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_queue_with_priority(self, hime_controller: Any) -> None:
        """Higher priority expression should interrupt or override lower priority."""
        hime_controller.apply_expression("happy", duration=1.0, priority=1)
        hime_controller.apply_expression("angry", duration=1.0, priority=10)
        current = hime_controller.get_current_expression()
        assert current == "angry", "High priority should override low priority"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_state_after_error(self, hime_controller: Any, mocker: "MockerFixture") -> None:
        """If apply_expression fails, state should remain unchanged or reset to neutral."""
        hime_controller.apply_expression("happy", duration=0.1)
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.CalledProcessError(1, "hime_display")
        )
        try:
            hime_controller.apply_expression("sad", duration=0.1)
        except Exception:
            pass
        current = hime_controller.get_current_expression()
        assert current in ["happy", "neutral"], f"Unexpected state after error: {current}"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_fallback_to_neutral_on_timeout(self, hime_controller: Any, mocker: "MockerFixture") -> None:
        """If an expression times out (duration exceeded), state should revert to neutral."""
        mocker.patch("time.time", side_effect=[0.0, 0.0, 5.0])  # Simulate 5s elapsed
        hime_controller.apply_expression("happy", duration=1.0)
        current = hime_controller.get_current_expression()
        assert current == "neutral", "Should revert to neutral after timeout"


# ---------------------------------------------------------------------------
# TestExpressionTiming
# ---------------------------------------------------------------------------
class TestExpressionTiming:
    """Test expression duration and timing."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_duration(self, expression_mapper: Any) -> None:
        """Each expression should have a defined duration."""
        for emotion in expression_mapper.list_emotions():
            duration = expression_mapper.get_expression_duration(emotion)
            assert isinstance(duration, (int, float))
            assert duration > 0, f"{emotion}: duration must be positive"
            assert duration <= 10, f"{emotion}: duration seems too long ({duration}s)"

    def test_default_duration_mocked(self, expression_mapper: Any) -> None:
        """When mocked, default duration should be reasonable."""
        duration = expression_mapper.get_expression_duration("happy")
        assert isinstance(duration, (int, float))
        assert duration > 0


# ---------------------------------------------------------------------------
# TestExpressionConcurrency
# ---------------------------------------------------------------------------
class TestExpressionConcurrency:
    """Test concurrent expression operations."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_concurrent_expression_changes(self, hime_controller: Any) -> None:
        """Multiple rapid expression changes should not crash."""
        errors = []
        def change_expression(emotion: str) -> None:
            try:
                for _ in range(10):
                    hime_controller.apply_expression(emotion, duration=0.05)
            except Exception as e:
                errors.append(e)

        threads = [
            threading.Thread(target=change_expression, args=("happy",)),
            threading.Thread(target=change_expression, args=("sad",)),
            threading.Thread(target=change_expression, args=("angry",)),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent expression changes failed: {errors}"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_concurrent_queuing_final_state(self, hime_controller: Any) -> None:
        """Rapid expression changes should not cause double-apply or lost state."""
        errors = []
        def apply_emotions():
            try:
                for i in range(20):
                    hime_controller.apply_expression("happy", duration=0.01)
                    hime_controller.apply_expression("sad", duration=0.01)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=apply_emotions) for _ in range(2)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent queuing failed: {errors}"
        final = hime_controller.get_current_expression()
        assert final in ["happy", "sad", "neutral"], f"Unexpected final state: {final}"


# ---------------------------------------------------------------------------
# TestExpressionErrorHandling
# ---------------------------------------------------------------------------
class TestExpressionErrorHandling:
    """Test error handling and fallback behavior."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_invalid_expression_name_raises(self, hime_controller: Any) -> None:
        """Invalid expression name should raise ValueError when Hime is available."""
        with pytest.raises((ValueError, KeyError)):
            hime_controller.apply_expression("nonexistent_emotion_xyz", duration=1.0)

    def test_invalid_expression_mocked_no_raise(self, hime_controller: Any) -> None:
        """When mocked, invalid expressions should not raise."""
        hime_controller.apply_expression("nonexistent", duration=1.0)
        # Should not raise

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_missing_blendshape_file(self, expression_mapper: Any) -> None:
        """Missing blendshape file should raise FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            expression_mapper.get_blend_shapes("definitely_nonexistent_emotion")

    def test_empty_expression_list(self, expression_mapper: Any) -> None:
        """Empty expression list should be handled."""
        emotions = expression_mapper.list_emotions()
        assert isinstance(emotions, list)
        # Even if empty, should not crash


# ---------------------------------------------------------------------------
# TestExpressionStatePersistence
# ---------------------------------------------------------------------------
class TestExpressionStatePersistence:
    """Test expression state persistence."""

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_expression_state_survives_reset(self, hime_controller: Any) -> None:
        """After reset, expression should return to neutral."""
        hime_controller.apply_expression("happy", duration=0.1)
        hime_controller.reset_expression()
        current = hime_controller.get_current_expression()
        assert current == "neutral"

    @pytest.mark.skipif(not hime_available, reason="Hime Display not installed")
    def test_multiple_resets_idempotent(self, hime_controller: Any) -> None:
        """Multiple resets should be idempotent."""
        hime_controller.reset_expression()
        hime_controller.reset_expression()
        hime_controller.reset_expression()
        current = hime_controller.get_current_expression()
        assert current == "neutral"
