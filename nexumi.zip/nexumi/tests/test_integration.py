"""
tests/test_integration.py
===========================
End-to-end integration tests with all external services mocked.

Tests the full pipeline: user input → router → tool execution → response.
No real network requests, no WebSocket server, no microphone.
"""

from __future__ import annotations

from typing import Any, Dict, List
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Router tests
# ---------------------------------------------------------------------------
class TestRouter:
    """Test intent routing logic."""

    def test_route_search(self) -> None:
        """'search for ...' should route to search intent."""
        from src.utils.router import route
        assert route("search for Python tutorials") == "search"

    def test_route_desktop_click(self) -> None:
        """'click on ...' should route to desktop_click intent."""
        from src.utils.router import route
        assert route("click on the button") == "desktop_click"

    def test_route_memory_store(self) -> None:
        """'remember that ...' should route to memory_store intent."""
        from src.utils.router import route
        assert route("remember that I like pizza") == "memory_store"

    def test_route_memory_query(self) -> None:
        """'what do you know about me' should route to memory_query intent."""
        from src.utils.router import route
        assert route("what do you know about me") == "memory_query"

    def test_route_chat_default(self) -> None:
        """Generic text should default to chat intent."""
        from src.utils.router import route
        assert route("hello how are you") == "chat"

    def test_extract_search_query(self) -> None:
        """extract_search_query should strip the trigger phrase."""
        from src.utils.router import extract_search_query
        assert extract_search_query("search for Python tutorials") == "Python tutorials"

    def test_extract_fact(self) -> None:
        """extract_fact should parse 'remember that X' into fact text."""
        from src.utils.router import extract_fact
        fact = extract_fact("remember that I like pizza")
        assert "pizza" in fact.lower()

    def test_router_confidence_scoring(self) -> None:
        """Confidence should be higher for exact phrases vs fuzzy matches."""
        from src.utils.router import route_with_confidence

        exact_intent, exact_conf = route_with_confidence("search for cats")
        fuzzy_intent, fuzzy_conf = route_with_confidence("i kinda wanna search cats maybe")

        assert exact_intent == "search"
        assert fuzzy_intent == "search"
        assert exact_conf > fuzzy_conf, "Exact match should have higher confidence"


# ---------------------------------------------------------------------------
# Tool tests (with mocks)
# ---------------------------------------------------------------------------
class TestWebSearch:
    """Test web search with mocked results."""

    def test_search_returns_list(self, mock_web_search: Any) -> None:
        """search() must return a list of result dicts."""
        from src.tools.websearch import search
        results = search("Python programming language", max_results=2)
        assert isinstance(results, list)
        assert len(results) == 2
        for r in results:
            assert "title" in r
            assert "url" in r

    def test_search_respects_max_results(self, mock_web_search: Any) -> None:
        """max_results parameter should limit returned items."""
        from src.tools.websearch import search
        results = search("test", max_results=1)
        assert len(results) == 1

    def test_search_fallback_engines(self, mock_web_search_fallback: Any) -> None:
        """Search should fallback to alternative engines when primary fails."""
        from src.tools.websearch import search

        # Test DuckDuckGo (default)
        results_ddg = search("test query", engine="duckduckgo")
        assert len(results_ddg) > 0
        assert "DDG" in results_ddg[0]["title"]

        # Test Brave
        results_brave = search("test query", engine="brave")
        assert len(results_brave) > 0
        assert "Brave" in results_brave[0]["title"]

        # Test SearXNG
        results_searx = search("test query", engine="searxng")
        assert len(results_searx) > 0
        assert "SearXNG" in results_searx[0]["title"]

    def test_search_fallback_chain_on_failure(self, mocker: "MockerFixture") -> None:
        """When DuckDuckGo fails, should try Brave or SearXNG fallback."""
        from src.tools.websearch import search

        # Mock requests to raise exception for DuckDuckGo
        mock_post = mocker.patch("requests.post")
        mock_post.side_effect = Exception("DuckDuckGo timeout")

        # Mock fallback engines
        mock_brave = mocker.patch("src.tools.websearch._search_brave")
        mock_brave.return_value = [{"title": "Brave fallback", "url": "https://brave.com", "snippet": "Fallback result"}]

        results = search("test query", engine="duckduckgo", fallback=True)
        assert len(results) > 0
        assert "Brave" in results[0]["title"] or "SearXNG" in results[0]["title"]


class TestScreenshot:
    """Test screenshot capture with mocked filesystem."""

    def test_capture_returns_path(self, mock_screenshot: Any, tmp_path: Any) -> None:
        """capture() should return a valid file path."""
        from src.tools.screenshot import capture
        path = capture()
        assert path is not None
        assert isinstance(path, str)
        assert path.endswith(".png")

    def test_describe_returns_string(self, mock_screenshot: Any) -> None:
        """describe() should return a text description."""
        from src.tools.screenshot import describe
        desc = describe("dummy_path.png")
        assert isinstance(desc, str)
        assert len(desc) > 0

    def test_capture_region(self, mock_screenshot: Any) -> None:
        """capture_region() should return a path for a specific screen region."""
        from src.tools.screenshot import capture_region
        path = capture_region(x=0, y=0, width=800, height=600)
        assert isinstance(path, str)
        assert path.endswith(".png")

    def test_capture_window(self, mock_screenshot: Any) -> None:
        """capture_window() should return a path for a specific window."""
        from src.tools.screenshot import capture_window
        path = capture_window(window_name="Firefox")
        assert isinstance(path, str)
        assert path.endswith(".png")

    def test_screenshot_ocr(self, mocker: "MockerFixture") -> None:
        """OCR should extract text from screenshot (future-proof)."""
        from src.tools.screenshot import ocr_extract
        mock_ocr = mocker.patch("src.tools.screenshot._run_ocr")
        mock_ocr.return_value = "Extracted text from image"

        result = ocr_extract("dummy.png")
        assert isinstance(result, str)
        assert "Extracted" in result


class TestDesktop:
    """Test desktop automation tools with mocked backends."""

    def test_click_text(self, mock_desktop: Dict[str, MagicMock]) -> None:
        """desktop.click_text() should use xdotool or pyautogui fallback."""
        from src.tools.desktop import click_text
        click_text("Firefox")
        # Either xdotool or pyautogui should have been called
        assert mock_desktop["xdotool"].called or mock_desktop["pyautogui"].click.called

    def test_click_coordinates(self, mock_desktop: Dict[str, MagicMock]) -> None:
        """click(100, 200) should call pyautogui with those coordinates."""
        from src.tools.desktop import click
        click(x=100, y=200)
        mock_desktop["pyautogui"].click.assert_called_once()
        call_args = mock_desktop["pyautogui"].click.call_args
        assert call_args[1].get("x") == 100
        assert call_args[1].get("y") == 200

    def test_type_text(self, mock_desktop: Dict[str, MagicMock]) -> None:
        """desktop.type_text() should type the given text."""
        from src.tools.desktop import type_text
        type_text("Hello Nexumi")
        assert mock_desktop["pyautogui"].typewrite.called

    def test_scroll(self, mock_desktop: Dict[str, MagicMock]) -> None:
        """desktop.scroll() should scroll the specified amount."""
        from src.tools.desktop import scroll
        scroll(5)
        mock_desktop["pyautogui"].scroll.assert_called_once()

    def test_press_key(self, mock_desktop: Dict[str, MagicMock]) -> None:
        """desktop.press_key() should press the specified key."""
        from src.tools.desktop import press_key
        press_key("enter")
        assert mock_desktop["pyautogui"].keyDown.called
        assert mock_desktop["pyautogui"].keyUp.called


# ---------------------------------------------------------------------------
# Memory DB tests
# ---------------------------------------------------------------------------
class TestMemoryDB:
    """Test brain memory with isolated SQLite DB."""

    def test_remember_and_recall(self, brain_instance: Any, memory_db: str) -> None:
        """Store a fact and recall it by keyword."""
        brain_instance.remember_fact("Integration test fact", category="test")
        facts = brain_instance.recall_facts(keyword="Integration test")
        assert any("Integration test" in f["fact_text"] for f in facts)

    def test_cleanup_removes_fact(self, brain_instance: Any, memory_db: str) -> None:
        """Deleting a fact should make it unrecoverable."""
        brain_instance.remember_fact("Temporary integration fact", category="test")
        facts = brain_instance.recall_facts(keyword="Temporary integration")
        fid = facts[0]["id"]
        brain_instance.delete_fact(fid)
        facts_after = brain_instance.recall_facts(keyword="Temporary integration")
        assert len(facts_after) == 0

    def test_memory_reset_wipe(self, brain_instance: Any, memory_db: str) -> None:
        """brain_instance.clear_memory() should remove all stored facts and conversation history."""
        brain_instance.remember_fact("Fact one", category="test")
        brain_instance.remember_fact("Fact two", category="test")

        brain_instance.clear_memory()

        facts = brain_instance.recall_facts(keyword="Fact")
        assert len(facts) == 0, "All facts should be wiped"
        assert len(brain_instance.conversation_history) == 0, "Conversation history should be cleared"


# ---------------------------------------------------------------------------
# Full pipeline tests
# ---------------------------------------------------------------------------
class TestFullPipeline:
    """Test the complete user-input → response pipeline."""

    def test_chat_pipeline(self, brain_instance: Any, mock_web_search: Any) -> None:
        """Generic chat input should yield a text response without tool calls."""
        from src.utils.router import route
        intent = route("Tell me a joke")
        assert intent == "chat"
        response = brain_instance.respond("Tell me a joke")
        assert isinstance(response, str)
        assert len(response) > 0

    def test_search_pipeline(self, brain_instance: Any, mock_web_search: Any) -> None:
        """Search intent should trigger mocked web search and include results."""
        from src.utils.router import route, extract_search_query
        from src.tools.websearch import search

        user_input = "search for Python tutorials"
        intent = route(user_input)
        assert intent == "search"
        query = extract_search_query(user_input)
        results = search(query, max_results=2)
        assert len(results) > 0
        # Brain should synthesise a response incorporating results
        response = brain_instance.respond(f"Here are search results: {results}")
        assert isinstance(response, str)

    def test_desktop_click_pipeline(self, brain_instance: Any, mock_desktop: Dict[str, MagicMock]) -> None:
        """'click on the Firefox icon' → router → desktop.click_text → response."""
        from src.utils.router import route
        from src.tools.desktop import click_text

        user_input = "click on the Firefox icon"
        intent = route(user_input)
        assert intent == "desktop_click"

        result = click_text("Firefox")
        response = brain_instance.respond(f"I clicked on Firefox. Result: {result}")
        assert isinstance(response, str)
        assert mock_desktop["xdotool"].called or mock_desktop["pyautogui"].click.called

    def test_remember_pipeline(self, brain_instance: Any) -> None:
        """'remember that I like ramen' → router → memory.remember_fact → verify stored."""
        from src.utils.router import route, extract_fact

        user_input = "remember that I like ramen"
        intent = route(user_input)
        assert intent == "memory_store"

        fact_text = extract_fact(user_input)
        brain_instance.remember_fact(fact_text, category="food")

        facts = brain_instance.recall_facts(keyword="ramen")
        assert any("ramen" in f.get("fact_text", "") for f in facts)

        response = brain_instance.respond("I'll remember that!")
        assert isinstance(response, str)

    def test_multi_step_command(self, brain_instance: Any, mock_desktop: Dict[str, MagicMock]) -> None:
        """Multi-step commands: 'open Chrome and search for cats'."""
        from src.utils.router import route
        from src.tools.desktop import click_text
        from src.tools.websearch import search

        # Step 1: Open Chrome
        intent1 = route("open Chrome")
        assert intent1 in ["desktop_click", "chat"]
        if intent1 == "desktop_click":
            click_text("Chrome")

        # Step 2: Search
        intent2 = route("search for cats")
        assert intent2 == "search"
        results = search("cats", max_results=2)

        response = brain_instance.respond(f"Opened Chrome and found {len(results)} results for cats.")
        assert isinstance(response, str)

    def test_multi_step_dispatcher(self, brain_instance: Any, mocker: "MockerFixture") -> None:
        """'open Chrome and search for cats' should be split into two actions by dispatcher."""
        mock_dispatch = mocker.patch("src.utils.router.dispatch_actions")
        mock_dispatch.return_value = [
            {"tool": "desktop_click", "args": {"target": "Chrome"}},
            {"tool": "search", "args": {"query": "cats"}},
        ]

        from src.utils.router import dispatch_multi_step
        actions = dispatch_multi_step("open Chrome and search for cats")

        assert len(actions) == 2
        assert actions[0]["tool"] == "desktop_click"
        assert actions[1]["tool"] == "search"

    def test_error_propagation(self, brain_instance: Any, mock_desktop: Dict[str, MagicMock]) -> None:
        """When a tool fails, the response should indicate failure, not crash."""
        from src.tools.desktop import click_text

        # Mock click_text to return error
        mock_desktop["pyautogui"].locateCenterOnScreen.return_value = None

        result = click_text("NonExistentApp")
        response = brain_instance.respond(f"I tried to click but: {result}")
        assert isinstance(response, str)
        assert "could not click" in response.lower() or "not found" in response.lower() or "error" in response.lower()

    def test_session_grouping(self, brain_instance: Any) -> None:
        """Messages from same session should share session ID; different sessions should not."""
        session_id = "test_session_123"
        context = {"session_id": session_id}

        brain_instance.respond("Hello", context=context)
        brain_instance.respond("How are you?", context=context)

        # Verify both messages used the same session
        assert brain_instance.current_session_id == session_id

        # Different session should not see previous messages
        other_session = "other_session_456"
        brain_instance.respond("New session", context={"session_id": other_session})
        assert brain_instance.current_session_id == other_session

    def test_shutdown_cleanup(self, brain_instance: Any, tmp_path: Any) -> None:
        """Ensure temporary files (screenshots, audio cache) are deleted on shutdown."""
        # Create dummy temp files
        screenshot_path = tmp_path / "temp_screenshot.png"
        audio_path = tmp_path / "temp_audio.mp3"
        screenshot_path.write_bytes(b"\x89PNG")
        audio_path.write_bytes(b"ID3")

        # Set brain to use tmp_path for temp files
        brain_instance.temp_dir = str(tmp_path)
        brain_instance.shutdown()

        # Verify files no longer exist
        assert not screenshot_path.exists(), "Screenshot temp file should be deleted"
        assert not audio_path.exists(), "Audio temp file should be deleted"
