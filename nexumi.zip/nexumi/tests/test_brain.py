"""
tests/test_brain.py
===================
Comprehensive tests for the AI Brain (OpenRouter LLM, memory, mood switching,
fact injection, context management, streaming, concurrency, and error recovery).

All external API calls are mocked; no real network requests.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from typing import TYPE_CHECKING, Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest

if TYPE_CHECKING:
    from pytest_mock import MockerFixture


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def brain(mock_settings: dict, mock_openrouter: MagicMock) -> "Brain":
    """Return a Brain instance with a mocked LLM client."""
    from src.core.brain import get_brain
    return get_brain()


# =========================================================================
# TestBrainRespond - Core response generation
# =========================================================================
class TestBrainRespond:
    """Test basic LLM response generation."""

    def test_respond_returns_string(self, brain: "Brain") -> None:
        """Brain.respond() must return a non-empty string."""
        response = brain.respond("Hello Nexumi, how are you?")
        assert isinstance(response, str) and len(response) > 0, "Empty response!"

    def test_respond_tracks_tokens(self, brain: "Brain") -> None:
        """Token usage should be tracked after each response."""
        initial_tokens = brain.total_tokens_used
        brain.respond("Hello")
        assert brain.total_tokens_used > initial_tokens

    def test_respond_updates_response_time(self, brain: "Brain") -> None:
        """Response time should be recorded."""
        brain.respond("Test")
        assert brain.last_response_time_ms is not None
        assert brain.last_response_time_ms >= 0

    def test_respond_with_context(self, brain: "Brain") -> None:
        """Context should be passed to the LLM."""
        context = {"session_id": "test_123", "platform": "desktop"}
        response = brain.respond("Hello", context=context)
        assert isinstance(response, str)

    def test_respond_with_empty_input(self, brain: "Brain") -> None:
        """Empty input should still return a valid response or error message."""
        response = brain.respond("")
        assert isinstance(response, str)

    def test_respond_with_long_input(self, brain: "Brain") -> None:
        """Long inputs should be handled without truncation errors."""
        long_input = "Hello " * 1000
        response = brain.respond(long_input)
        assert isinstance(response, str)

    def test_respond_with_unicode(self, brain: "Brain") -> None:
        """Unicode input should be handled correctly."""
        response = brain.respond("Hello 世界! 🌍 नमस्ते")
        assert isinstance(response, str)

    def test_respond_with_special_chars(self, brain: "Brain") -> None:
        """Special characters should not cause issues."""
        response = brain.respond("Test <script>alert('xss')</script>")
        assert isinstance(response, str)
        assert "<script>" not in response  # Should be sanitized or escaped

    def test_respond_with_empty_context_dict(self, brain: "Brain") -> None:
        """Empty context dict should not crash."""
        response = brain.respond("Hello", context={})
        assert isinstance(response, str)


# =========================================================================
# TestBrainSystemPrompt - System prompt construction
# =========================================================================
class TestBrainSystemPrompt:
    """Test system prompt building and fact injection."""

    def test_system_prompt_includes_mood(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """System prompt should inject current mood."""
        spy = mocker.spy(brain, "_build_messages")
        brain.set_mood("happy")
        brain.respond("Hey!")
        call_args = spy.call_args
        assert call_args is not None
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "happy" in system_msg["content"].lower()

    def test_system_prompt_includes_facts(self, brain: "Brain", mocker: "MockerFixture", sample_facts: List[Dict[str, Any]]) -> None:
        """System prompt should inject relevant facts."""
        for fact in sample_facts:
            brain.remember_fact(fact["text"], category=fact["category"], confidence=fact["confidence"])

        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Tell me about food I like")
        call_args = spy.call_args
        assert call_args is not None
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "ramen" in system_msg["content"].lower()

    def test_system_prompt_includes_profile(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """System prompt should include user profile info."""
        brain.update_profile(name="Alice", timezone="UTC")

        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hi")
        call_args = spy.call_args
        assert call_args is not None
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "Alice" in system_msg["content"]

    def test_system_prompt_format(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """System prompt should follow expected format with sections."""
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hello")
        call_args = spy.call_args
        assert call_args is not None
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        content = system_msg["content"]
        assert "Nexumi" in content
        assert "personality" in content.lower() or "assistant" in content.lower()

    def test_system_prompt_with_no_facts(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """System prompt should work even with no facts stored."""
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hello")
        call_args = spy.call_args
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert isinstance(system_msg["content"], str)
        assert len(system_msg["content"]) > 0


# =========================================================================
# TestBrainMemory - Fact storage, recall, and management
# =========================================================================
class TestBrainMemory:
    """Test fact storage and recall."""

    def test_remember_fact(self, brain: "Brain", memory_db: str) -> None:
        """Facts should be stored and retrievable."""
        brain.remember_fact("I like ramen noodles", category="food")
        facts = brain.recall_facts(keyword="ramen")
        assert any("ramen" in f.get("fact_text", f.get("text", "")) for f in facts)

    def test_remember_fact_with_metadata(self, brain: "Brain", memory_db: str) -> None:
        """Facts should store category and confidence."""
        brain.remember_fact("I enjoy hiking", category="hobby", confidence=0.9)
        facts = brain.recall_facts(keyword="hiking")
        assert len(facts) == 1
        assert facts[0]["category"] == "hobby"
        assert facts[0]["confidence"] == 0.9

    def test_recall_no_match_returns_empty(self, brain: "Brain") -> None:
        """Recalling a non-existent keyword returns an empty list."""
        facts = brain.recall_facts(keyword="xyz_nonexistent")
        assert facts == []

    def test_recall_multiple_matches(self, brain: "Brain", memory_db: str) -> None:
        """Recalling should return multiple matching facts."""
        brain.remember_fact("I like ramen", category="food")
        brain.remember_fact("I like sushi", category="food")
        brain.remember_fact("I like pizza", category="food")
        facts = brain.recall_facts(keyword="like")
        assert len(facts) >= 3

    def test_recall_sorted_by_confidence(self, brain: "Brain", memory_db: str) -> None:
        """Facts should be sorted by confidence (highest first)."""
        brain.remember_fact("Low confidence fact", category="test", confidence=0.3)
        brain.remember_fact("High confidence fact", category="test", confidence=0.95)
        brain.remember_fact("Medium confidence fact", category="test", confidence=0.6)
        facts = brain.recall_facts(keyword="confidence")
        assert facts[0]["confidence"] >= facts[1]["confidence"]

    def test_delete_fact(self, brain: "Brain", memory_db: str) -> None:
        """Deleting a fact should remove it permanently."""
        brain.remember_fact("Temporary fact", category="test")
        facts_before = brain.recall_facts(keyword="Temporary")
        assert len(facts_before) == 1
        fid = facts_before[0]["id"]
        brain.delete_fact(fid)
        facts_after = brain.recall_facts(keyword="Temporary")
        assert len(facts_after) == 0

    def test_delete_nonexistent_fact(self, brain: "Brain") -> None:
        """Deleting a non-existent fact should not raise."""
        brain.delete_fact("nonexistent_id_12345")  # Should not raise

    def test_recall_updates_reference_count(self, brain: "Brain", memory_db: str) -> None:
        """Recalling a fact should increment its reference count."""
        brain.remember_fact("Reference test fact", category="test")
        facts_before = brain.recall_facts(keyword="Reference")
        initial_refs = facts_before[0].get("reference_count", 0)
        brain.recall_facts(keyword="Reference")
        facts_after = brain.recall_facts(keyword="Reference")
        assert facts_after[0].get("reference_count", 0) > initial_refs

    def test_fact_injection_removed_when_low_confidence(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Facts with confidence below threshold should not appear in prompt."""
        brain.remember_fact("Low confidence fact", category="test", confidence=0.2)
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Tell me about this")
        call_args = spy.call_args
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "Low confidence fact" not in system_msg["content"]


# =========================================================================
# TestBrainMood - Mood switching and state management
# =========================================================================
class TestBrainMood:
    """Test mood switching and prompt injection."""

    def test_set_mood_changes_system_prompt(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Changing mood should update the system prompt content."""
        spy = mocker.spy(brain, "_build_messages")
        brain.set_mood("flirty")
        brain.respond("You look nice today~")
        call_args = spy.call_args
        assert call_args is not None
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "flirty" in system_msg["content"].lower()

    def test_mood_persists_across_calls(self, brain: "Brain") -> None:
        """Mood should remain set between respond() calls."""
        brain.set_mood("sad")
        assert brain.current_mood == "sad"
        brain.respond("Test")
        assert brain.current_mood == "sad"

    def test_mood_transition(self, brain: "Brain") -> None:
        """Mood should change when explicitly set."""
        brain.set_mood("happy")
        assert brain.current_mood == "happy"
        brain.set_mood("angry")
        assert brain.current_mood == "angry"

    def test_invalid_mood_raises(self, brain: "Brain") -> None:
        """Setting an unrecognised mood should raise ValueError."""
        with pytest.raises(ValueError):
            brain.set_mood("invalid_mood_123")

    def test_all_valid_moods(self, brain: "Brain") -> None:
        """All valid moods should be accepted without error."""
        valid_moods = ["normal", "happy", "sad", "angry", "excited", "flirty", "sleepy"]
        for mood in valid_moods:
            brain.set_mood(mood)
            assert brain.current_mood == mood

    def test_mood_affects_response_tone(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Different moods should produce different system prompts."""
        prompts = {}
        spy = mocker.spy(brain, "_build_messages")

        for mood in ["happy", "sad", "flirty"]:
            brain.set_mood(mood)
            brain.respond("Hello")
            call_args = spy.call_args
            messages = call_args[0][0]
            system_msg = next(m for m in messages if m["role"] == "system")
            prompts[mood] = system_msg["content"]

        assert prompts["happy"] != prompts["sad"]
        assert prompts["flirty"] != prompts["happy"]


# =========================================================================
# TestBrainContext - Conversation context management
# =========================================================================
class TestBrainContext:
    """Test context window and conversation history management."""

    def test_context_window_limit(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Context window should not exceed max_messages."""
        spy = mocker.spy(brain, "_build_messages")
        for i in range(25):
            brain.respond(f"Message {i}")

        brain.respond("Final message")
        call_args = spy.call_args
        messages = call_args[0][0]
        conversation = [m for m in messages if m["role"] != "system"]
        assert len(conversation) <= brain.max_context_messages

    def test_context_includes_recent_messages(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Recent messages should be included in context."""
        brain.respond("First message")
        brain.respond("Second message")

        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Third message")
        call_args = spy.call_args
        messages = call_args[0][0]
        conversation = [m for m in messages if m["role"] != "system"]
        contents = [m["content"] for m in conversation]
        assert any("Third message" in c for c in contents)

    def test_context_pruning_old_messages(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Old messages should be pruned when exceeding window."""
        for i in range(brain.max_context_messages + 10):
            brain.respond(f"Old message {i}")

        spy = mocker.spy(brain, "_build_messages")
        brain.respond("New message")
        call_args = spy.call_args
        messages = call_args[0][0]
        conversation = [m for m in messages if m["role"] != "system"]
        contents = [m["content"] for m in conversation]
        assert not any("Old message 0" in c for c in contents)

    def test_empty_context_dict(self, brain: "Brain") -> None:
        """Empty context dict should not crash."""
        response = brain.respond("Hello", context={})
        assert isinstance(response, str)

    def test_very_long_context_truncation(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Very long context should be truncated or summarized."""
        long_msg = "word " * 5000  # ~25K characters
        brain.respond(long_msg)

        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Summary please")
        call_args = spy.call_args
        messages = call_args[0][0]
        # Should not exceed model context window
        total_chars = sum(len(m.get("content", "")) for m in messages)
        assert total_chars < 100000, f"Context too long: {total_chars} chars"


# =========================================================================
# TestBrainStreaming - Streaming response tests
# =========================================================================
class TestBrainStreaming:
    """Test streaming response generation."""

    @pytest.mark.slow
    def test_stream_response_returns_string(self, brain: "Brain", mock_openrouter_streaming: MagicMock) -> None:
        """Streaming respond should return assembled string."""
        response = brain.respond("Hello", stream=True)
        assert isinstance(response, str)
        assert len(response) > 0

    @pytest.mark.slow
    def test_stream_response_chunks_assembled(self, brain: "Brain", mock_openrouter_streaming: MagicMock) -> None:
        """Streaming chunks should be assembled into complete response."""
        response = brain.respond("Hello", stream=True)
        assert "Hello" in response or "Nexumi" in response

    def test_stream_false_uses_regular(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """stream=False should use regular non-streaming path."""
        spy = mocker.spy(brain.client.chat.completions, "create")
        brain.respond("Hello", stream=False)
        call_kwargs = spy.call_args[1] if spy.call_args else {}
        assert call_kwargs.get("stream") is not True


# =========================================================================
# TestBrainErrorHandling - Error recovery and resilience
# =========================================================================
class TestBrainErrorHandling:
    """Test error handling and graceful degradation."""

    def test_api_error_graceful_fallback(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """On API failure, brain should return a fallback message."""
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            side_effect=Exception("Connection timeout"),
        )
        response = brain.respond("Hello?")
        assert isinstance(response, str)
        assert len(response) > 0
        assert any(word in response.lower() for word in ["sorry", "trouble", "error", "unavailable"])

    def test_api_rate_limit_fallback(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """On rate limit, should return appropriate fallback."""
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            side_effect=Exception("Rate limit exceeded"),
        )
        response = brain.respond("Hello?")
        assert isinstance(response, str)
        assert len(response) > 0

    def test_api_invalid_key_fallback(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """On invalid API key, should return appropriate fallback."""
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            side_effect=Exception("Invalid API key"),
        )
        response = brain.respond("Hello?")
        assert isinstance(response, str)
        assert len(response) > 0

    def test_malformed_response_handling(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Malformed API responses should be handled gracefully."""
        mock_response = MagicMock()
        mock_response.choices = []  # Empty choices
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            return_value=mock_response,
        )
        response = brain.respond("Hello")
        assert isinstance(response, str)

    def test_timeout_handling(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Timeout exceptions should be caught and handled."""
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            side_effect=TimeoutError("Request timed out"),
        )
        response = brain.respond("Hello")
        assert isinstance(response, str)

    def test_error_recovery_after_timeout(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """After timeout error, subsequent calls should work."""
        mocker.patch.object(
            brain.client.chat.completions,
            "create",
            side_effect=[
                TimeoutError("Timeout"),
                MagicMock(
                    choices=[MagicMock(message=MagicMock(content="Recovered!"))],
                    usage=MagicMock(total_tokens=5),
                ),
            ],
        )
        response1 = brain.respond("Hello")
        assert isinstance(response1, str)
        response2 = brain.respond("Hello again")
        assert isinstance(response2, str)
        assert "Recovered" in response2 or len(response2) > 0


# =========================================================================
# TestBrainTokenManagement - Token counting and limits
# =========================================================================
class TestBrainTokenManagement:
    """Test token usage tracking and limit enforcement."""

    def test_token_counting(self, brain: "Brain") -> None:
        """Token usage should be tracked."""
        initial = brain.total_tokens_used
        brain.respond("Hello")
        assert brain.total_tokens_used >= initial

    def test_token_limit_warning(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """Approaching token limit should log warning."""
        mock_logger = mocker.patch("src.core.brain.logger")
        brain.total_tokens_used = brain.max_tokens_per_session - 100
        brain.respond("Hello")
        assert mock_logger.warning.called or mock_logger.info.called

    def test_token_limit_reset(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """When limit exceeded, brain should optionally reset."""
        brain.total_tokens_used = brain.max_tokens_per_session + 1
        response = brain.respond("Hello")
        assert isinstance(response, str)

    def test_maximum_token_limit_warning(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """When total_tokens_used approaches limit, brain should warn and optionally reset."""
        mock_logger = mocker.patch("src.core.brain.logger")
        brain.total_tokens_used = brain.max_tokens_per_session - 50
        brain.respond("Hello")
        assert mock_logger.warning.called, "Should warn when approaching token limit"


# =========================================================================
# TestBrainProfileIntegration - User profile integration
# =========================================================================
class TestBrainProfileIntegration:
    """Test integration with user profile data."""

    def test_profile_name_in_prompt(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """User name should appear in system prompt."""
        brain.update_profile(name="Prakash")
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hi")
        call_args = spy.call_args
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "Prakash" in system_msg["content"]

    def test_profile_timezone_in_prompt(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """User timezone should appear in system prompt."""
        brain.update_profile(timezone="Asia/Tokyo")
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hi")
        call_args = spy.call_args
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "Tokyo" in system_msg["content"] or "Asia/Tokyo" in system_msg["content"]

    def test_profile_preferences_in_prompt(self, brain: "Brain", mocker: "MockerFixture") -> None:
        """User preferences should influence system prompt."""
        brain.update_profile(preferences={"response_length": "detailed"})
        spy = mocker.spy(brain, "_build_messages")
        brain.respond("Hi")
        call_args = spy.call_args
        messages = call_args[0][0]
        system_msg = next(m for m in messages if m["role"] == "system")
        assert "detailed" in system_msg["content"].lower() or "verbose" in system_msg["content"].lower()


# =========================================================================
# TestBrainConcurrency - Thread safety
# =========================================================================
class TestBrainConcurrency:
    """Test thread safety of brain operations."""

    @pytest.mark.concurrent
    def test_concurrent_respond_calls(self, brain: "Brain") -> None:
        """Multiple threads calling respond() should not race."""
        errors = []
        results = []

        def respond_thread():
            try:
                for i in range(10):
                    r = brain.respond(f"Thread message {i}")
                    results.append(r)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=respond_thread) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent respond() failed: {errors}"
        assert len(results) == 40, f"Expected 40 responses, got {len(results)}"

    @pytest.mark.concurrent
    def test_concurrent_memory_access(self, brain: "Brain", memory_db: str) -> None:
        """Concurrent fact storage should not corrupt memory."""
        errors = []

        def store_facts():
            try:
                for i in range(20):
                    brain.remember_fact(f"Fact {i}", category="test")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=store_facts) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors, f"Concurrent memory access failed: {errors}"
        facts = brain.recall_facts(keyword="Fact")
        assert len(facts) >= 60, f"Expected >=60 facts, got {len(facts)}"
