"""
tests/test_wakeword.py
======================
Test wake word detection using Vosk (offline, no Porcupine).

Uses a mock recognizer by default; can run with a real tiny Vosk model
if VOSK_MODEL_PATH is set.
"""

from __future__ import annotations

import json
import threading
import wave
from pathlib import Path
from typing import Any, Generator
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _create_dummy_wav(path: Path, duration_sec: float = 1.0, sample_rate: int = 16000) -> Path:
    """Generate a silent mono 16-bit WAV file for testing."""
    num_frames = int(duration_sec * sample_rate)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(b"\x00" * (num_frames * 2))
    return path


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def dummy_wav(tmp_path: Path) -> Path:
    """Provide a dummy WAV file path using pytest tmp_path."""
    return _create_dummy_wav(tmp_path / "dummy.wav", duration_sec=0.5)


@pytest.fixture
def wakeword_module() -> Any:
    """Import the wake word module."""
    from src.core import wakeword
    return wakeword


@pytest.fixture
def mock_vosk_model(mocker: "MockerFixture", tmp_path: Path) -> Path:
    """Create a mock Vosk model directory structure."""
    model_dir = tmp_path / "vosk_model"
    model_dir.mkdir(parents=True)
    (model_dir / "am").mkdir()
    (model_dir / "graph").mkdir()
    (model_dir / "ivector").mkdir()
    (model_dir / "mfcc.conf").write_text("--sample-frequency=16000")
    return model_dir


@pytest.fixture
def has_microphone() -> bool:
    """Check if microphone hardware is available."""
    try:
        import pyaudio
        pa = pyaudio.PyAudio()
        device_count = pa.get_device_count()
        pa.terminate()
        return device_count > 0
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
class TestVoskImports:
    """Verify Vosk dependencies are importable."""

    def test_vosk_import(self) -> None:
        """vosk should be installed."""
        try:
            import vosk
            assert hasattr(vosk, "Model")
            assert hasattr(vosk, "KaldiRecognizer")
        except ImportError:
            pytest.skip("vosk not installed – run: pip install vosk")

    def test_pyaudio_import(self) -> None:
        """pyaudio is optional; test only warns if missing."""
        try:
            import pyaudio
        except ImportError:
            pytest.skip("pyaudio not installed – mic tests unavailable")


class TestKeywordSpotting:
    """Test Vosk-based keyword spotting logic."""

    def test_keyword_detected_in_transcription(self, wakeword_module: Any) -> None:
        """When transcription contains 'nexumi', callback should fire."""
        callback = MagicMock()
        # Simulate recognizer returning text with wake word
        fake_result = json.dumps({"text": "hello nexumi how are you"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_called_once()

    def test_no_keyword_no_callback(self, wakeword_module: Any) -> None:
        """Transcription without wake word should not trigger callback."""
        callback = MagicMock()
        fake_result = json.dumps({"text": "hello how are you today"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_not_called()

    def test_partial_result_ignored(self, wakeword_module: Any) -> None:
        """Partial results (not final) should not trigger callback."""
        callback = MagicMock()
        fake_partial = json.dumps({"partial": "hello nex"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_partial):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_not_called()

    def test_case_insensitive_matching(self, wakeword_module: Any) -> None:
        """Wake word matching should be case-insensitive."""
        callback = MagicMock()
        fake_result = json.dumps({"text": "Hello NEXUMI there"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_called_once()

    def test_wake_word_at_start_of_sentence(self, wakeword_module: Any) -> None:
        """'Nexumi hello' should trigger callback."""
        callback = MagicMock()
        fake_result = json.dumps({"text": "nexumi hello how are you"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_called_once()

    def test_wake_word_at_end_of_sentence(self, wakeword_module: Any) -> None:
        """'hello Nexumi' should trigger callback."""
        callback = MagicMock()
        fake_result = json.dumps({"text": "hello there nexumi"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_called_once()

    def test_false_positive_rejection(self, wakeword_module: Any) -> None:
        """Similar sounding words ('nexus', 'text me') should not trigger."""
        callback = MagicMock()

        # Test "nexus"
        fake_result_nexus = json.dumps({"text": "the nexus is important"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result_nexus):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_not_called()

        # Test "text me"
        callback.reset_mock()
        fake_result_textme = json.dumps({"text": "please text me later"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result_textme):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_not_called()

    def test_keyword_spotting_confidence_threshold(self, wakeword_module: Any) -> None:
        """Vosk confidence score should be checked against threshold."""
        callback = MagicMock()
        # Low confidence result
        fake_result = json.dumps({
            "text": "hello nexumi",
            "result": [
                {"conf": 0.1, "start": 0.0, "end": 1.0, "word": "hello"},
                {"conf": 0.1, "start": 1.0, "end": 2.0, "word": "nexumi"},
            ]
        })
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback, confidence_threshold=0.5)
        callback.assert_not_called()

    def test_multiple_wake_words(self, wakeword_module: Any) -> None:
        """Multiple wake words (e.g., 'nexumi' and 'hey nexus') should both work."""
        callback = MagicMock()

        fake_result1 = json.dumps({"text": "hey nexumi"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result1):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_called_once()

        callback.reset_mock()
        fake_result2 = json.dumps({"text": "hey nexus"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result2):
            wakeword_module.process_audio("dummy.wav", keyword="nexus", callback=callback)
        callback.assert_called_once()

    def test_multi_keyword_list(self, wakeword_module: Any) -> None:
        """Listen for multiple phrases (e.g., 'nexumi', 'hey nexumi')."""
        callback = MagicMock()
        keywords = ["nexumi", "hey nexumi"]

        for kw in keywords:
            fake_result = json.dumps({"text": f"{kw} how are you"})
            with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
                wakeword_module.process_audio("dummy.wav", keywords=keywords, callback=callback)
            callback.assert_called()
            callback.reset_mock()


class TestAudioProcessing:
    """Test audio stream handling."""

    def test_process_wav_file(self, wakeword_module: Any, dummy_wav: Path) -> None:
        """process_audio should accept a valid WAV file path."""
        callback = MagicMock()
        # Patch recognizer to return empty (no wake word)
        fake_result = json.dumps({"text": ""})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio(str(dummy_wav), keyword="nexumi", callback=callback)
        # Should not raise

    def test_invalid_audio_file_raises(self, wakeword_module: Any) -> None:
        """Non-existent or invalid audio file should raise cleanly."""
        with pytest.raises((FileNotFoundError, ValueError)):
            wakeword_module.process_audio("/nonexistent/file.wav", keyword="nexumi", callback=lambda: None)

    def test_background_noise_rejection(self, wakeword_module: Any) -> None:
        """Low-volume speech / noise should not trigger wake word."""
        callback = MagicMock()
        fake_result = json.dumps({"text": "*muffled noise*"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)
        callback.assert_not_called()

    def test_non_16khz_audio_resampling(self, wakeword_module: Any, tmp_path: Path) -> None:
        """Vosk expects 16kHz. If audio is at a different rate, it should be resampled."""
        # Create a 48kHz WAV
        wav_48k = tmp_path / "48k.wav"
        with wave.open(str(wav_48k), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(48000)
            wf.writeframes(b"\x00" * (48000 * 2))

        mock_resample = MagicMock(return_value=16000)
        with patch("src.core.wakeword._resample_audio", mock_resample):
            callback = MagicMock()
            fake_result = json.dumps({"text": "hello nexumi"})
            with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
                wakeword_module.process_audio(str(wav_48k), keyword="nexumi", callback=callback)

        mock_resample.assert_called_once()


class TestVoskModelLoading:
    """Test Vosk model loading and validation."""

    def test_vosk_model_loading_valid_path(self, wakeword_module: Any, mock_vosk_model: Path) -> None:
        """Loading Vosk model from valid path should succeed."""
        mock_model = MagicMock()
        with patch("vosk.Model", return_value=mock_model):
            model = wakeword_module.load_vosk_model(str(mock_vosk_model))
        assert model is not None

    def test_vosk_model_loading_invalid_path(self, wakeword_module: Any) -> None:
        """Invalid model path should raise clear error."""
        with pytest.raises((FileNotFoundError, ValueError, RuntimeError)):
            wakeword_module.load_vosk_model("/nonexistent/vosk_model")

    def test_automatic_model_download(self, wakeword_module: Any, mocker: "MockerFixture", tmp_path: Path) -> None:
        """When model is missing, it should download automatically."""
        mock_download = mocker.patch("src.core.wakeword._download_vosk_model")
        mock_download.return_value = str(tmp_path / "downloaded_model")

        with patch("pathlib.Path.exists", return_value=False):
            wakeword_module.ensure_model(str(tmp_path / "model"))

        mock_download.assert_called_once()


class TestCallbackThreading:
    """Test callback execution threading."""

    def test_callback_not_on_audio_thread(self, wakeword_module: Any) -> None:
        """Callback should not be executed on the audio processing thread (non-blocking)."""
        main_thread_id = threading.current_thread().ident
        callback_thread_ids = []

        def callback():
            callback_thread_ids.append(threading.current_thread().ident)

        fake_result = json.dumps({"text": "hello nexumi"})
        with patch.object(wakeword_module, "_recognize_file", return_value=fake_result):
            wakeword_module.process_audio("dummy.wav", keyword="nexumi", callback=callback)

        assert len(callback_thread_ids) == 1
        assert callback_thread_ids[0] != main_thread_id, "Callback should run on different thread"


class TestLiveListener:
    """Live microphone tests – skipped by default."""

    @pytest.mark.hardware
    @pytest.mark.skipif(
        not has_microphone(),
        reason="Microphone hardware not available in CI"
    )
    def test_live_listener_runs(self, wakeword_module: Any) -> None:
        """Start and stop the live listener without hanging."""
        import threading
        import time

        callback = MagicMock()
        listener = wakeword_module.start_listening(keyword="nexumi", callback=callback)
        time.sleep(0.5)
        wakeword_module.stop_listening(listener)
        # Should not raise; callback may or may not have fired

    @pytest.mark.hardware
    @pytest.mark.skipif(
        not has_microphone(),
        reason="Microphone hardware not available in CI"
    )
    def test_microphone_error_handling(self, wakeword_module: Any, mocker: "MockerFixture") -> None:
        """If no mic available, start_listening should return None and log error."""
        mocker.patch("pyaudio.PyAudio", side_effect=Exception("No audio devices"))

        callback = MagicMock()
        result = wakeword_module.start_listening(keyword="nexumi", callback=callback)
        assert result is None

    @pytest.mark.hardware
    @pytest.mark.skipif(
        not has_microphone(),
        reason="Microphone hardware not available in CI"
    )
    def test_microphone_device_busy(self, wakeword_module: Any, mocker: "MockerFixture") -> None:
        """When microphone device is busy, should return None and log error."""
        mock_logger = mocker.patch("src.core.wakeword.logger")
        mock_pa = mocker.patch("pyaudio.PyAudio")
        mock_pa.return_value.open_stream.side_effect = Exception("Device is busy")

        callback = MagicMock()
        result = wakeword_module.start_listening(keyword="nexumi", callback=callback)
        assert result is None
        mock_logger.error.assert_called()
