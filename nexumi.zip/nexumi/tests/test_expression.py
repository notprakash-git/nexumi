"""
tests/test_expression.py
========================
Comprehensive emotion selector tests with parametrization,
confidence thresholds, multi-language support, negation handling,
emoji mapping, edge cases, and performance benchmarks.

Uses pytest.mark.parametrize for exhaustive coverage.
"""

from __future__ import annotations

import pytest

from src.integration.emotion_selector import select_emotion


# ---------------------------------------------------------------------------
# Parametrised samples
# ---------------------------------------------------------------------------
CORE_EMOTIONS = [
    # Happy
    ("I love you so much!", "Ehehe~ I love you too!", "happy"),
    ("That's amazing news!", "I'm so glad to hear that!", "happy"),
    ("You make me so happy", "You make me smile too!", "happy"),
    ("Best day ever!", "Yay! I'm happy for you!", "happy"),

    # Sad
    ("I feel so sad and empty.", "I'm sorry, I'm here for you.", "sad"),
    ("I miss them so much...", "I'm here if you need to talk.", "sad"),
    ("Everything is terrible", "That sounds really hard.", "sad"),
    ("I feel lonely", "You're not alone, I'm here.", "sad"),

    # Angry
    ("That's so annoying and stupid.", "I'm sorry to hear that.", "angry"),
    ("I hate when this happens.", "That sounds frustrating.", "angry"),
    ("This makes me furious!", "I understand your frustration.", "angry"),
    ("I'm so mad right now", "Take a deep breath.", "angry"),

    # Excited
    ("I'm so excited for this!", "Yes! This is amazing!!", "excited"),
    ("Wow, I can't believe it!", "I know, right?!", "excited"),
    ("This is incredible!", "So exciting!", "excited"),
    ("I won the lottery!", "OMG congratulations!", "excited"),

    # Flirty
    ("You're so cute~", "Ehehe, you're making me blush!", "flirty"),
    ("You look beautiful today", "Oh, you're making me shy~", "flirty"),
    ("I have a crush on you", "Ehehe, you're so sweet~", "flirty"),
    ("Are you single?", "Ehehe, why do you ask?", "flirty"),

    # Sleepy
    ("I'm tired, going to sleep", "Goodnight, sleep well~", "sleepy"),
    ("Goodnight, talk tomorrow", "Sleep tight!", "sleepy"),
    ("I'm so sleepy...", "You should rest~", "sleepy"),
    ("Yawn... bedtime", "Sweet dreams!", "sleepy"),

    # Embarrassed
    ("I'm so embarrassed...", "Don't worry, it happens to everyone!", "embarrassed"),
    ("That was awkward", "Ehehe, it's okay~", "embarrassed"),
    ("I can't believe I did that", "We all make mistakes!", "embarrassed"),

    # Surprised
    ("Oh my god! Really?!", "Yes! Isn't it shocking?!", "surprised"),
    ("No way! I didn't expect that!", "I know! So unexpected!", "surprised"),
    ("Wow, that's surprising!", "Right?! I was shocked too!", "surprised"),

    # Worried
    ("I'm really worried about this", "I understand your concern.", "worried"),
    ("What if something goes wrong?", "Let's think through this together.", "worried"),
    ("I'm anxious about tomorrow", "Everything will be okay.", "worried"),

    # Relaxed
    ("This is so peaceful", "Yes, very calming~", "relaxed"),
    ("I feel so calm right now", "It's nice to relax sometimes.", "relaxed"),
    ("The spa was amazing", "That sounds so relaxing!", "relaxed"),
]

EDGE_CASES = [
    ("", "", "neutral"),
    ("!!!", "???", "neutral"),
    ("I love you", "", "happy"),
    ("", "I love you too!", "happy"),
    ("123 456", "789 000", "neutral"),
    ("...", "...", "neutral"),
    ("Hi", "Hello", "neutral"),
]

MULTILANG_SAMPLES = [
    ("Ich liebe dich", "Ich dich auch!", "happy"),
    ("Je t'aime", "Je t'aime aussi!", "happy"),
    ("Ti amo", "Anch'io ti amo!", "happy"),
    ("Te quiero", "Yo tambien te quiero!", "happy"),
    ("Ai shiteru", "Watashi mo ai shiteru!", "happy"),
    ("Saranghae", "Nado saranghae!", "happy"),
    ("Wo ai ni", "Wo ye ai ni!", "happy"),
]

CONFIDENCE_CASES = [
    ("I love you so much!", "I love you too!", "happy", 0.8),
    ("I hate this!", "I understand.", "angry", 0.8),
    ("I'm tired", "Rest well.", "sleepy", 0.6),
    ("Hello", "Hi there!", "neutral", 0.3),
    ("The weather is nice", "Yes it is.", "neutral", 0.2),
]

# Negation tests - these should NOT be classified as the positive emotion
NEGATION_CASES = [
    ("I'm not happy", "neutral"),  # Should not be "happy"
    ("I don't love this", "neutral"),  # Should not be "happy"
    ("I'm not angry", "neutral"),  # Should not be "angry"
    ("Not excited at all", "neutral"),  # Should not be "excited"
    ("I'm not sad", "neutral"),  # Should not be "sad"
]

# Multi-word negations
MULTI_WORD_NEGATION_CASES = [
    ("I'm not very happy about this", "happy"),  # Should NOT be happy
    ("I am not at all excited", "excited"),  # Should NOT be excited
    ("She is not really angry", "angry"),  # Should NOT be angry
]

# Emoji-only inputs
EMOJI_CASES = [
    ("❤️", "happy"),
    ("😍", "happy"),
    ("😢", "sad"),
    ("😭", "sad"),
    ("😡", "angry"),
    ("😠", "angry"),
    ("😴", "sleepy"),
    ("😱", "surprised"),
    ("😳", "embarrassed"),
    ("😊", "happy"),
]

# Mixed language
MIXED_LANG_CASES = [
    ("I am tres heureux", "happy"),  # French-English mix
    ("Ich bin so happy", "happy"),  # German-English mix
    ("Estoy very angry", "angry"),  # Spanish-English mix
]


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
class TestEmotionCoreClassification:
    """Core emotion classification with parametrized samples."""

    @pytest.mark.parametrize("user_text,ai_text,expected", CORE_EMOTIONS)
    def test_emotion_classification(self, user_text: str, ai_text: str, expected: str) -> None:
        """Emotion selector should map known phrases to correct labels."""
        emotion, confidence = select_emotion(user_text=user_text, ai_text=ai_text)
        assert emotion == expected, (
            f"Expected '{expected}' for user='{user_text[:40]}', got '{emotion}'"
        )
        assert 0.0 <= confidence <= 1.0, "Confidence must be in [0, 1]"

    @pytest.mark.parametrize("user_text,ai_text,expected", EDGE_CASES)
    def test_edge_cases(self, user_text: str, ai_text: str, expected: str) -> None:
        """Edge cases (empty, punctuation-only, missing inputs) should not crash."""
        emotion, confidence = select_emotion(user_text=user_text, ai_text=ai_text)
        assert isinstance(emotion, str)
        assert 0.0 <= confidence <= 1.0

    @pytest.mark.parametrize("user_text,ai_text,expected", MULTILANG_SAMPLES)
    def test_multilanguage(self, user_text: str, ai_text: str, expected: str) -> None:
        """Non-English phrases should be classified correctly."""
        emotion, confidence = select_emotion(user_text=user_text, ai_text=ai_text)
        assert emotion == expected, (
            f"Expected '{expected}' for '{user_text[:30]}', got '{emotion}'"
        )


class TestEmotionConfidence:
    """Test confidence scoring behavior."""

    @pytest.mark.parametrize("user_text,ai_text,expected,min_confidence", CONFIDENCE_CASES)
    def test_confidence_thresholds(
        self, user_text: str, ai_text: str, expected: str, min_confidence: float
    ) -> None:
        """Strong emotional signals should yield high confidence."""
        emotion, confidence = select_emotion(user_text=user_text, ai_text=ai_text)
        assert emotion == expected
        assert confidence >= min_confidence, (
            f"Expected confidence >= {min_confidence} for '{expected}', got {confidence}"
        )

    def test_confidence_high_for_clear_signals(self) -> None:
        """Very strong emotional signals should yield very high confidence."""
        emotion, confidence = select_emotion("I love you so much!", "I love you too!")
        assert emotion == "happy"
        assert confidence >= 0.7, f"Expected high confidence, got {confidence}"

    def test_confidence_low_for_ambiguous(self) -> None:
        """Neutral/ambiguous text should yield low confidence."""
        emotion, confidence = select_emotion("The weather is nice today.", "Yes, it is.")
        assert confidence <= 0.5, f"Expected low confidence, got {confidence}"

    def test_confidence_extreme_emotion(self) -> None:
        """Extreme emotional expressions should yield very high confidence."""
        emotion, confidence = select_emotion(
            "I ABSOLUTELY HATE THIS WITH EVERY FIBER OF MY BEING!!!",
            "I understand your anger."
        )
        assert emotion == "angry"
        assert confidence >= 0.9, f"Expected very high confidence, got {confidence}"

    def test_confidence_calibration_ambiguous(self) -> None:
        """Ambiguous phrases should have low confidence."""
        emotion, confidence = select_emotion("That's interesting", "Yes, indeed.")
        assert confidence <= 0.4, f"Ambiguous phrase should have low confidence, got {confidence}"

    def test_confidence_calibration_clear_vs_ambiguous(self) -> None:
        """Clear signals should have higher confidence than ambiguous ones."""
        _, conf_clear = select_emotion("I love you so much!", "I love you too!")
        _, conf_ambiguous = select_emotion("That's interesting", "Yes, indeed.")
        assert conf_clear > conf_ambiguous, (
            f"Clear signal ({conf_clear}) should be higher than ambiguous ({conf_ambiguous})"
        )


class TestEmotionNegation:
    """Test negation handling - "not happy" should not be "happy"."""

    @pytest.mark.parametrize("user_text,unexpected", NEGATION_CASES)
    def test_negation_not_positive(self, user_text: str, unexpected: str) -> None:
        """Negated emotions should not be classified as the positive emotion."""
        emotion, confidence = select_emotion(user_text=user_text)
        assert emotion != unexpected, (
            f"Negation '{user_text}' incorrectly classified as '{unexpected}'"
        )

    @pytest.mark.parametrize("user_text,unexpected", MULTI_WORD_NEGATION_CASES)
    def test_multi_word_negation(self, user_text: str, unexpected: str) -> None:
        """Multi-word negations should not be classified as the positive emotion."""
        emotion, confidence = select_emotion(user_text=user_text)
        assert emotion != unexpected or confidence < 0.5, (
            f"Multi-word negation '{user_text}' incorrectly classified as '{unexpected}' with high confidence"
        )

    def test_negation_complex(self) -> None:
        """Complex negations should be handled."""
        emotion, confidence = select_emotion("I'm not very happy about this")
        assert emotion != "happy" or confidence < 0.5


class TestEmotionEmoji:
    """Test emoji-only and emoji-rich inputs."""

    @pytest.mark.parametrize("user_text,expected", EMOJI_CASES)
    def test_emoji_classification(self, user_text: str, expected: str) -> None:
        """Emojis should map to correct emotions."""
        emotion, confidence = select_emotion(user_text=user_text)
        assert emotion == expected, (
            f"Emoji '{user_text}' should be '{expected}', got '{emotion}'"
        )

    def test_emoji_mixed_with_text(self) -> None:
        """Emoji mixed with text should not crash."""
        emotion, confidence = select_emotion("I love you! ❤️😍", "❤️")
        assert isinstance(emotion, str)
        assert 0.0 <= confidence <= 1.0

    def test_emoji_only_input(self) -> None:
        """Multiple emojis should be handled."""
        emotion, confidence = select_emotion("😢😭💔")
        assert emotion in ["sad", "neutral"]

    def test_emoji_only_multiple_emotions(self) -> None:
        """Mixed emotion emojis should pick dominant or neutral."""
        emotion, confidence = select_emotion("😡❤️")
        assert isinstance(emotion, str)
        assert 0.0 <= confidence <= 1.0


class TestEmotionMixedLanguage:
    """Test mixed-language inputs."""

    @pytest.mark.parametrize("user_text,expected", MIXED_LANG_CASES)
    def test_mixed_language(self, user_text: str, expected: str) -> None:
        """Mixed-language phrases should be classified."""
        emotion, confidence = select_emotion(user_text=user_text)
        assert emotion == expected, (
            f"Mixed language '{user_text}' should be '{expected}', got '{emotion}'"
        )

    def test_mixed_language_with_emoji(self) -> None:
        """Mixed language with emoji should work."""
        emotion, confidence = select_emotion("Ich bin so happy 😊")
        assert emotion == "happy"


class TestEmotionContextAware:
    """Test context-aware emotion detection."""

    def test_previous_emotion_influence(self) -> None:
        """Previous emotion can influence current detection."""
        emotion1, _ = select_emotion("I love you!", "I love you too!")
        assert emotion1 == "happy"

        emotion2, conf2 = select_emotion("That's nice", "Yes it is~", previous_emotion="happy")
        assert conf2 > 0.3

    def test_emotion_transition_detection(self) -> None:
        """Detecting emotion transitions."""
        emotion1, _ = select_emotion("I'm so happy!", "Yay!")
        assert emotion1 == "happy"

        emotion2, _ = select_emotion("Actually, I feel sad now...", "Oh no, what happened?")
        assert emotion2 == "sad"

    def test_mixed_emotions(self) -> None:
        """Mixed emotions should pick the dominant one."""
        emotion, confidence = select_emotion(
            "I'm happy but also a bit sad",
            "That's a complex feeling."
        )
        assert emotion in ["happy", "sad", "neutral"]
        assert confidence >= 0.2

    def test_emotion_persistence_no_artificial_increase(self) -> None:
        """Same emotion repeated should not artificially increase confidence."""
        _, conf1 = select_emotion("I love you!", "I love you too!")
        _, conf2 = select_emotion("I love you!", "I love you too!")
        assert abs(conf1 - conf2) < 0.01, "Confidence should be deterministic"

    def test_emotion_override_with_force(self) -> None:
        """force_emotion parameter should override detection."""
        emotion, confidence = select_emotion(
            "I love you!", "I love you too!", force_emotion="sad"
        )
        assert emotion == "sad", "force_emotion should override detected emotion"


class TestEmotionSpecialInputs:
    """Test special and problematic inputs."""

    def test_special_characters(self) -> None:
        """Special characters should not crash."""
        emotion, confidence = select_emotion("I <3 you!!! @#$%", "<3")
        assert isinstance(emotion, str)
        assert 0.0 <= confidence <= 1.0

    def test_very_long_input(self) -> None:
        """Very long inputs should be handled."""
        long_text = "I love you " * 100
        emotion, confidence = select_emotion(long_text, "I love you too!")
        assert isinstance(emotion, str)
        assert 0.0 <= confidence <= 1.0

    def test_single_word_input(self) -> None:
        """Single word inputs should work."""
        emotion, confidence = select_emotion("Happy!", "Yay!")
        assert emotion == "happy"

    def test_repeated_punctuation(self) -> None:
        """Repeated punctuation should not affect classification."""
        emotion, confidence = select_emotion("I love you!!!!!!", "I love you too!!!!!!")
        assert emotion == "happy"
        assert confidence >= 0.6

    def test_force_emotion_parameter(self) -> None:
        """force_emotion parameter should override detection."""
        emotion, confidence = select_emotion(
            "I love you!", "I love you too!", force_emotion="sad"
        )
        assert emotion == "sad", "force_emotion should override detected emotion"

    def test_force_emotion_invalid(self) -> None:
        """Invalid force_emotion should fall back to detection or raise."""
        try:
            emotion, confidence = select_emotion(
                "I love you!", "I love you too!", force_emotion="invalid_emotion_xyz"
            )
            # If it doesn't raise, it should at least return a valid emotion
            assert isinstance(emotion, str)
        except (ValueError, KeyError):
            pass  # Also acceptable


class TestEmotionUserOnly:
    """Test user-only input (no AI text)."""

    def test_user_only_happy(self) -> None:
        """User-only happy text should be detected."""
        emotion, confidence = select_emotion(user_text="I am so happy today!")
        assert emotion == "happy"
        assert confidence >= 0.5

    def test_user_only_angry(self) -> None:
        """User-only angry text should be detected."""
        emotion, confidence = select_emotion(user_text="I hate everything right now!")
        assert emotion == "angry"
        assert confidence >= 0.5

    def test_user_only_neutral(self) -> None:
        """User-only neutral text should return neutral."""
        emotion, confidence = select_emotion(user_text="The sky is blue.")
        assert emotion == "neutral"


class TestEmotionPerformance:
    """Performance and stress tests."""

    @pytest.mark.slow
    def test_bulk_classification_performance(self) -> None:
        """Bulk classification should complete in reasonable time."""
        import time

        samples = [
            ("I love you!", "I love you too!"),
            ("I'm so angry!", "Calm down."),
            ("I'm tired", "Rest well."),
        ] * 100

        start = time.time()
        for user_text, ai_text in samples:
            select_emotion(user_text=user_text, ai_text=ai_text)
        elapsed = time.time() - start

        assert elapsed < 5.0, f"Bulk classification took {elapsed:.2f}s, expected < 5s"

    def test_consistency(self) -> None:
        """Same input should yield same output."""
        results = []
        for _ in range(10):
            emotion, confidence = select_emotion("I love you!", "I love you too!")
            results.append((emotion, confidence))

        first = results[0]
        for r in results[1:]:
            assert r == first, f"Inconsistent results: {first} vs {r}"
