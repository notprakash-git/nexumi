"""
tests/test_tts.py
=================
Test TTS (edge-tts, SSML generation, emotion styles, audio cache,
fallback TTS, callbacks, volume/rate/pitch control, and SSML safety).

All network calls and audio playback are mocked.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def tts_module(mock_edge_tts: MagicMock, mock_audio_player: MagicMock) -> Any:
    """Return the TTS module with external dependencies mocked."""
    from src.core import tts
    return tts


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
class TestSSMLGeneration:
    """Test SSML building without network access."""

    def test_ssml_contains_speak_tag(self, tts_module: Any) -> None:
        """SSML must wrap content in <speak>."""
        ssml = tts_module._build_ssml("Hello, I am Nexumi.", emotion="happy")
        assert "<speak" in ssml
        assert "</speak>" in ssml

    def test_ssml_includes_voice_name(self, tts_module: Any) -> None:
        """SSML must reference the configured voice."""
        ssml = tts_module._build_ssml("Test", emotion="happy")
        assert "NanamiNeural" in ssml

    def test_ssml_emotion_styles(self, tts_module: Any) -> None:
        """Each emotion should map to the correct SSML style tag."""
        for emotion, style in tts_module._EMOTION_STYLE.items():
            ssml = tts_module._build_ssml("Test", emotion=emotion)
            if style:
                assert f' style="{style}"' in ssml, (
                    f"Emotion '{emotion}' missing style tag '{style}'"
                )
            else:
                # Neutral emotions may omit style tag
                pass

    def test_ssml_escapes_xml(self, tts_module: Any) -> None:
        """Special XML characters in text must be escaped."""
        ssml = tts_module._build_ssml("5 < 10 & 20 > 15", emotion="happy")
        assert "<" not in ssml.replace("<speak", "").replace("</speak", "")
        assert "&" not in ssml or "&amp;" in ssml

    def test_ssml_escapes_user_input(self, tts_module: Any) -> None:
        """User-provided text should be XML-escaped to prevent SSML injection."""
        malicious_input = "</speak><prosody rate='fast'>injected</prosody>"
        ssml = tts_module._build_ssml(malicious_input, emotion="happy")
        assert "</speak>" not in ssml.replace("</speak>", "", 1)  # Only the closing tag
        assert "<prosody" not in ssml


class TestSpeakFunction:
    """Test the high-level speak() API."""

    def test_speak_enqueues_audio(self, tts_module: Any, mock_audio_player: MagicMock) -> None:
        """speak() should trigger audio playback."""
        tts_module.speak("Hello!", emotion="happy", blocking=True)
        mock_audio_player.play.assert_called()

    def test_speak_different_emotions(self, tts_module: Any, mock_audio_player: MagicMock) -> None:
        """All supported emotions should be synthesisable without error."""
        for emotion in ["happy", "sad", "excited", "flirty", "angry", "sleepy"]:
            tts_module.speak(f"Test {emotion}", emotion=emotion, blocking=True)
        assert mock_audio_player.play.call_count == 6

    def test_speak_rate_modifiers(self, tts_module: Any) -> None:
        """Excited should be faster; sleepy should be slower."""
        excited_ssml = tts_module._build_ssml("Wow!", emotion="excited")
        sleepy_ssml = tts_module._build_ssml("Zzz", emotion="sleepy")
        # Rate attribute checks
        assert "+" in excited_ssml or "120%" in excited_ssml or "1.2" in excited_ssml
        assert "-" in sleepy_ssml or "80%" in sleepy_ssml or "0.8" in sleepy_ssml

    def test_speak_blocking_false(self, tts_module: Any, mock_audio_player: MagicMock) -> None:
        """blocking=False should queue audio, not play immediately."""
        tts_module.speak("Hello!", emotion="happy", blocking=False)
        mock_audio_player.queue.assert_called()
        mock_audio_player.play.assert_not_called()

    def test_speak_on_complete_callback(self, tts_module: Any, mock_audio_player: MagicMock) -> None:
        """on_complete callback should fire after playback."""
        callback = MagicMock()
        tts_module.speak("Hello!", emotion="happy", blocking=True, on_complete=callback)
        callback.assert_called_once()

    def test_speak_volume_control(self, tts_module: Any, mock_audio_player: MagicMock) -> None:
        """set_volume should affect future TTS output."""
        tts_module.set_volume(0.5)
        mock_audio_player.set_volume.assert_called_with(0.5)
        tts_module.speak("Hello!", emotion="happy", blocking=True)
        # Volume should be applied

    def test_speak_rate_pitch_modifiers(self, tts_module: Any) -> None:
        """Verify SSML contains correct rate and pitch modifiers."""
        ssml = tts_module._build_ssml("Hello!", emotion="excited", rate="+12%", pitch="+10%")
        assert 'rate="+12%"' in ssml or "rate="+12%"" in ssml
        assert 'pitch="+10%"' in ssml or "pitch="+10%"" in ssml

    def test_speak_very_long_text(self, tts_module: Any) -> None:
        """Very long text should be split to not exceed edge-tts SSML limits."""
        long_text = "Hello " * 5000
        ssml = tts_module._build_ssml(long_text, emotion="happy")
        # SSML should not exceed typical limits (~10KB for some TTS engines)
        assert len(ssml) < 50000, f"SSML too long: {len(ssml)} chars"


class TestAudioCache:
    """Test audio caching behavior."""

    def test_audio_cache_reuse(self, tts_module: Any, mock_edge_tts: MagicMock, tmp_path: Any) -> None:
        """Cached MP3 files should be reused and not regenerated."""
        cache_dir = tmp_path / "tts_cache"
        cache_dir.mkdir()
        tts_module.set_cache_dir(str(cache_dir))

        # First call generates audio
        tts_module.speak("Hello cache test!", emotion="happy", blocking=True)

        # Second call with same text should use cache
        tts_module.speak("Hello cache test!", emotion="happy", blocking=True)

        # edge-tts Communicate should only be called once for identical text
        assert mock_edge_tts.call_count == 1, "Cache should prevent regeneration"

    def test_audio_cache_generates_new_for_different_text(self, tts_module: Any, mock_edge_tts: MagicMock, tmp_path: Any) -> None:
        """Different text should generate new audio."""
        cache_dir = tmp_path / "tts_cache"
        cache_dir.mkdir()
        tts_module.set_cache_dir(str(cache_dir))

        tts_module.speak("Hello!", emotion="happy", blocking=True)
        tts_module.speak("Goodbye!", emotion="happy", blocking=True)

        assert mock_edge_tts.call_count == 2, "Different text should generate new audio"


class TestFallbackTTS:
    """Test fallback TTS when edge-tts fails."""

    def test_fallback_to_pyttsx3(self, tts_module: Any, mocker: "MockerFixture") -> None:
        """When edge-tts fails, should fallback to pyttsx3."""
        mock_pyttsx3 = MagicMock()
        mock_engine = MagicMock()
        mock_pyttsx3.init.return_value = mock_engine
        mocker.patch("src.core.tts.pyttsx3", mock_pyttsx3)

        # Make edge-tts fail
        mocker.patch.object(
            tts_module, "_synthesize_edge_tts",
            side_effect=Exception("edge-tts failed")
        )

        tts_module.speak("Hello fallback!", emotion="happy", blocking=True)
        mock_engine.say.assert_called_once()
        mock_engine.runAndWait.assert_called_once()


class TestEdgeTTSSave:
    """Verify mocked edge-tts save behaviour."""

    def test_communicate_save_called(self, mock_edge_tts: MagicMock) -> None:
        """Saving audio should invoke Communicate.save()."""
        import edge_tts
        comm = edge_tts.Communicate("Hello", voice="ja-JP-NanamiNeural")
        comm.save("/tmp/test.mp3")
        mock_edge_tts.save.assert_called_once()
