#!/usr/bin/env bash
# =============================================================================
#  start_nexumi.sh
#  Starts all Nexumi components in the correct order.
#
#  Boot order (each must be healthy before the next launches):
#    1. WebSocket server   -- the central hub, everything else connects to it
#    2. Wake word listener -- listens for "Nexumi" on the mic
#    3. Resource monitor   -- watches RAM/CPU, sends warnings to the hub
#    4. Desktop Mate UI    -- PyQt6 window (3D model skipped until you add it)
#
#  Usage:
#    cd ~/nexumi
#    ./start_nexumi.sh
#
#  Each component gets its own log file under logs/:
#    tail -f logs/websocket.log
#    tail -f logs/wakeword.log
#    tail -f logs/monitor.log
#    tail -f logs/ui.log
# =============================================================================

# Do NOT use set -e here -- we want the script to keep running and report
# failures per-component rather than aborting the whole boot sequence.
set -uo pipefail

# ── Paths ─────────────────────────────────────────────────────────────────────
NEXUMI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV="$NEXUMI_DIR/venv"
PID_DIR="$NEXUMI_DIR/data"
PID_FILE="$PID_DIR/nexumi.pids"
LOG_DIR="$NEXUMI_DIR/logs"

# ── Colours ───────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "  ${GREEN}[OK]${RESET}   $*"; }
warn() { echo -e "  ${YELLOW}[WARN]${RESET} $*"; }
fail() { echo -e "  ${RED}[FAIL]${RESET} $*"; }
info() { echo -e "  ${CYAN}....${RESET}  $*"; }

# ── Guard: already running? ───────────────────────────────────────────────────
# Check by module name — more reliable than trusting stale PIDs from a
# previous crash. A PID can be reused by a completely different process.
_NEXUMI_MODULES="src.ui.websocket_server src.core.wakeword src.utils.resource_monitor src.ui.desktop_mate"
ALREADY_RUNNING=0
for _mod in $_NEXUMI_MODULES; do
    if pgrep -f "$_mod" > /dev/null 2>&1; then
        ALREADY_RUNNING=1
        break
    fi
done

if [ "$ALREADY_RUNNING" -eq 1 ]; then
    warn "Nexumi is already running."
    warn "Run ./stop_nexumi.sh first, then start again."
    exit 1
fi

# Remove stale PID file if no processes are actually running
rm -f "$PID_FILE"

# ── Setup ─────────────────────────────────────────────────────────────────────
mkdir -p "$LOG_DIR" "$PID_DIR" "$NEXUMI_DIR/data/screenshots"

echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e "${BOLD}  Nexumi  --  Starting                                      ${RESET}"
echo -e "${BOLD}============================================================${RESET}"

# ── Activate venv ─────────────────────────────────────────────────────────────
if [ -f "$VENV/bin/activate" ]; then
    source "$VENV/bin/activate"
    ok "Virtual environment: $VENV"
else
    warn "venv not found at $VENV -- using system Python."
    warn "Run install.sh first for a clean install."
fi

# ── Move into project root ────────────────────────────────────────────────────
cd "$NEXUMI_DIR"

# ── Load API keys safely ──────────────────────────────────────────────────────
# We read line by line instead of using export $(xargs) which breaks on
# values that contain spaces, quotes, or are left blank.
if [ -f "config/api_keys.env" ]; then
    # set -a exports every variable defined while it is active.
    # This is the correct way to source a KEY=value env file — the old
    # export "$line" created a variable literally named "KEY=value" which
    # is not a valid shell variable and never reached os.environ in Python.
    set -a
    # shellcheck disable=SC1091
    source "config/api_keys.env"
    set +a
    ok "API keys loaded from config/api_keys.env"
else
    warn "config/api_keys.env not found."
    warn "Copy config/api_keys.env.example and fill in your keys."
fi

# ── Validate Python ───────────────────────────────────────────────────────────
PYTHON="$(which python3)"
PY_VER="$("$PYTHON" --version 2>&1)"
ok "Python: $PY_VER  ($PYTHON)"

# =============================================================================
# _launch  name  python_module  logfilename
#
# Starts a Python module with nohup, records its PID in nexumi.pids,
# waits 0.8s and confirms the process is still alive.
# Returns 0 on success, 1 if the process died immediately.
# =============================================================================
_launch() {
    local name="$1"
    local module="$2"
    local logfile="$LOG_DIR/$3"

    info "Launching $name ..."

    nohup "$PYTHON" -m "$module" >> "$logfile" 2>&1 &
    local pid=$!

    sleep 0.8

    if kill -0 "$pid" 2>/dev/null; then
        echo "$pid|$name|$logfile" >> "$PID_FILE"
        ok "$name  (PID $pid)  ->  logs/$3"
        return 0
    else
        fail "$name failed to start immediately."
        fail "Last 10 lines of log:"
        tail -n 10 "$logfile" | sed 's/^/    /'
        return 1
    fi
}

# =============================================================================
# _wait_for_ws  host  port  timeout_seconds
#
# Polls a Python one-liner TCP connect until the port is open or timeout.
# Uses only Python stdlib — no nc, no bc, no external tools required.
# Returns 0 when the port is reachable, 1 on timeout.
# =============================================================================
_wait_for_ws() {
    local host="$1"
    local port="$2"
    local timeout="${3:-12}"
    local half_seconds=0                         # counts 0.5s ticks
    local max_ticks=$(( timeout * 2 ))           # integer arithmetic only

    info "Waiting for WebSocket server on $host:$port ..."

    while true; do
        if "$PYTHON" - <<PYEOF 2>/dev/null
import socket, sys
try:
    s = socket.create_connection(("$host", $port), timeout=0.4)
    s.close(); sys.exit(0)
except Exception:
    sys.exit(1)
PYEOF
        then
            ok "WebSocket server is reachable on $host:$port"
            return 0
        fi

        sleep 0.5
        half_seconds=$(( half_seconds + 1 ))
        if [ "$half_seconds" -ge "$max_ticks" ]; then
            fail "WebSocket server did not become reachable after ${timeout}s."
            fail "Check: tail -n 40 $LOG_DIR/websocket.log"
            return 1
        fi
    done
}

# ── Read WebSocket host/port from settings.json ───────────────────────────────
WS_HOST="$(python3 -c "
import json
try:
    s = json.load(open('config/settings.json'))
    print(s.get('websocket',{}).get('host','localhost'))
except Exception:
    print('localhost')
" 2>/dev/null || echo "localhost")"

WS_PORT="$(python3 -c "
import json
try:
    s = json.load(open('config/settings.json'))
    print(s.get('websocket',{}).get('port', 8765))
except Exception:
    print('8765')
" 2>/dev/null || echo "8765")"


echo ""
echo -e "${BOLD}  Starting components...${RESET}"
echo ""

# =============================================================================
# BLOCK 1 -- WebSocket Hub
# Must start first and be confirmed reachable before anything else boots.
# Libraries needed: websockets, python-dotenv, src.utils.*
# =============================================================================
if ! _launch "WebSocket server" "src.ui.websocket_server" "websocket.log"; then
    fail "Cannot continue without the WebSocket server. Aborting."
    exit 1
fi

if ! _wait_for_ws "$WS_HOST" "$WS_PORT" 12; then
    fail "Aborting -- WebSocket server unreachable."
    exit 1
fi

# =============================================================================
# BLOCK 2 -- Wake Word Listener (Vosk keyword spotting)
# Depends on: WebSocket server (block 1), pyaudio, vosk, Vosk model dir
# Non-fatal: Nexumi still works via the Chat panel without a wake word.
# No API key or .ppn file required — Vosk runs fully offline.
# =============================================================================
VOSK_MODEL="$NEXUMI_DIR/models/vosk-model-small-en-us-0.15"

if [ ! -d "$VOSK_MODEL" ]; then
    warn "Vosk model not found: $VOSK_MODEL"
    warn "Wake word listener skipped — you can still use the Chat panel."
    warn "To fix:  wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    warn "         unzip vosk-model-small-en-us-0.15.zip -d models/"
else
    _launch "Wake word listener" "src.core.wakeword" "wakeword.log" || \
        warn "Wake word listener failed to start -- continuing without it."
fi

# =============================================================================
# BLOCK 3 -- Resource Monitor
# Depends on: WebSocket server (block 1), psutil
# Non-fatal: purely informational RAM/CPU watcher.
# =============================================================================
_launch "Resource monitor" "src.utils.resource_monitor" "monitor.log" || \
    warn "Resource monitor failed -- continuing without it."

# =============================================================================
# BLOCK 4 -- Desktop Mate UI  (PyQt6 window)
# Depends on: WebSocket server (block 1), PyQt6, PyQt6-WebEngine
# Skipped if no display is available (headless / SSH without X forwarding).
# 3D model shows a placeholder if nexumi.vrm is missing -- non-fatal.
# =============================================================================
VRM_PATH="$NEXUMI_DIR/assets/3d_model/nexumi.vrm"

if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
    warn "No display found (DISPLAY and WAYLAND_DISPLAY are both unset)."
    warn "Desktop Mate UI skipped. Set DISPLAY=:0 if running via SSH + X11."
else
    if [ ! -f "$VRM_PATH" ]; then
        warn "nexumi.vrm not found -- UI will show a placeholder."
        warn "Place your VRM file at assets/3d_model/nexumi.vrm when ready."
    fi

    _launch "Desktop Mate UI" "src.ui.desktop_mate" "ui.log" || \
        warn "Desktop Mate UI failed -- check logs/ui.log"
fi

# =============================================================================
# Summary
# =============================================================================
echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e "${BOLD}  Nexumi boot complete.${RESET}"
echo ""
echo "  WebSocket hub : ws://$WS_HOST:$WS_PORT"
echo ""
echo "  Component status:"
if [ -f "$PID_FILE" ]; then
    while IFS='|' read -r pid name _log; do
        if kill -0 "$pid" 2>/dev/null; then
            echo -e "    ${GREEN}[running]${RESET}  $name  (PID $pid)"
        else
            echo -e "    ${RED}[dead]${RESET}     $name  (PID $pid)"
        fi
    done < "$PID_FILE"
fi
echo ""
echo "  Log files:"
echo "    tail -f $LOG_DIR/websocket.log"
echo "    tail -f $LOG_DIR/wakeword.log"
echo "    tail -f $LOG_DIR/monitor.log"
echo "    tail -f $LOG_DIR/ui.log"
echo ""
echo "  Stop with:  ./stop_nexumi.sh"
echo -e "${BOLD}============================================================${RESET}"
echo ""
