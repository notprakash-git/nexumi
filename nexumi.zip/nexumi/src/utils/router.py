"""
src/utils/router.py

Intent router — classifies a user utterance into one of several intents
with confidence scoring and parameter extraction.

Key design decisions
--------------------
- All regex patterns are pre-compiled at module load for performance.
- Confidence scoring is based on pattern specificity (exact phrase > partial).
- Multi-step commands are not supported yet but the API is designed for it.
- Patterns use word boundaries (\b) and require proximity to avoid misrouting.
- The order in _INTENT_PATTERNS matters: more specific intents are checked first.
- All extraction helpers return structured dicts for easy dispatch.
- Weather extraction supports location parsing for API integration.
"""

import re
from typing import Any, Optional, Union

from src.utils.logger import get_logger

log = get_logger("router")

# ---------------------------------------------------------------------------
# Pre-compiled patterns
# Each entry is (intent_name, [(pattern, weight), ...]).
# Weight affects confidence: higher = more specific = higher confidence.
# Within a single intent, the first matching pattern wins (break).
# ---------------------------------------------------------------------------
_INTENT_PATTERNS: list[tuple[str, list[tuple[re.Pattern, float]]]] = []

_RAW_PATTERNS: list[tuple[str, list[tuple[str, float]]]] = [
    # ── Memory ────────────────────────────────────────────────────────────
    ("memory_query", [
        (r"\bwhat do you know about me\b", 1.0),
        (r"\bwhat have i told you\b", 1.0),
        (r"\bdo you remember\b", 0.9),
        (r"\bwhat did i tell you\b", 0.9),
        (r"\byour memory\b", 0.8),
    ]),
    ("memory_store", [
        (r"\bremember that\b", 1.0),
        (r"\bremember this\b", 1.0),
        (r"\bdon'?t forget\b", 0.95),
        (r"\bmy name is\b", 0.95),
        (r"\bmy (favourite|favorite) .{1,30} is\b", 0.9),
        (r"\bmy (birthday|age) is\b", 0.9),
        (r"\bkeep in mind\b", 0.9),
        (r"\bsave that\b", 0.85),
    ]),

    # ── Screenshot ────────────────────────────────────────────────────────
    ("screenshot", [
        (r"\btake a screenshot\b", 1.0),
        (r"\bcapture (my |the )?screen\b", 0.95),
        (r"\bwhat('s| is) on (my |the )?screen\b", 0.9),
        (r"\bscreenshot\b", 0.8),
    ]),

    # ── Application & package management ──────────────────────────────────
    ("app_launch", [
        (r"\blaunch\s+\w+(?:[- ]\w+)*", 0.95),
        (r"\bstart\s+(?:the\s+)?\w+(?:[- ]\w+)*\s+app", 0.9),
        (r"\bopen\s+(?!my\s+eyes|up\b)\w+(?:[- ]\w+)*", 0.9),
    ]),
    ("app_install", [
        (r"\binstall\s+\w+(?:[- ]\w+)*", 0.9),
        (r"\bdownload\s+\w+(?:[- ]\w+)*", 0.85),
    ]),
    ("app_uninstall", [
        (r"\b(?:uninstall|remove)\s+\w+(?:[- ]\w+)*", 0.9),
    ]),
    ("package_search", [
        (r"\b(?:search\s+(?:for\s+)?|find\s+)package\s+\w+", 0.97),
        (r"\bsearch\s+(?:for\s+)?(?:a\s+)?package\s+(?:called\s+)?\w+", 0.85),
    ]),

    # ── File operations ───────────────────────────────────────────────────
    ("file_list", [
        (r"\blist\s+(?:the\s+)?(?:files|directories|folders?)\s+(?:in\s+)?\S+", 0.9),
        (r"\bshow\s+me\s+(?:the\s+)?(?:files\s+in\s+)?\S+", 0.85),
        (r"\bwhat(?:'s| is)\s+in\s+\S+", 0.85),
    ]),
    ("file_delete", [
        (r"\bdelete\s+\S+", 0.95),
        (r"\bremove\s+\S+", 0.9),
        (r"\btrash\s+\S+", 0.9),
    ]),
    ("file_copy", [
        (r"\bcopy\s+.+\s+(?:to|into)\s+\S+", 0.9),
    ]),
    ("file_move", [
        (r"\bmove\s+.+\s+(?:to|into)\s+\S+", 0.9),
        (r"\brename\s+.+\s+to\s+\S+", 0.9),
    ]),
    ("file_info", [
        (r"\binfo\s+(?:about|for|on)\s+\S+", 0.9),
        (r"\bget\s+info\s+(?:for|on)\s+\S+", 0.85),
        (r"\bwhat\s+is\s+\S+", 0.8),
    ]),

    # ── Process management ────────────────────────────────────────────────
    ("process_list", [
        (r"\blist\s+(?:running\s+)?processes", 0.9),
        (r"\bwhat(?:'s| is)\s+running", 0.85),
        (r"\bshow\s+processes", 0.85),
    ]),
    ("process_kill", [
        (r"\b(?:kill|stop|terminate)\s+(?:process\s+)?(?:\w+|\d+)", 0.95),
        (r"\bend\s+(?:process\s+)?(?:\w+|\d+)", 0.9),
    ]),

    # ── System information ────────────────────────────────────────────────
    ("system_info", [
        (r"\b(?:system|computer|pc)\s+(?:info|status|stats|information)\b", 0.95),
        (r"\bhow\s+much\s+(?:ram|memory|disk|cpu|storage)\b", 0.9),
        (r"\bsystem\s+resources\b", 0.9),
        (r"\bcheck\s+(?:system|cpu|ram|memory)\b", 0.85),
    ]),

    # ── Desktop automation (click, type, scroll, etc.) ────────────────────
    ("desktop_click", [
        (r"\bright\.click\b", 1.0),
        (r"\bdouble\.click\b", 1.0),
        (r"\bpress\s+(?:the\s+)?\w+\s+button\b", 0.95),
        (r"\bclick\s+(?:on\s+|the\s+)?\S+", 0.9),
    ]),
    ("desktop_type", [
        (r"\bwrite\s+\S.+", 0.9),
        (r"\btype\s+(?:out\s+|in\s+)?\S+", 0.9),
        (r"\benter\s+(?:this\s+|the\s+)?text\b", 0.85),
    ]),
    ("desktop_scroll", [
        (r"\bscroll\s+(up|down)\b", 0.95),
        (r"\bpage\s+(up|down)\b", 0.9),
        (r"\bscroll\s+the\s+page\b", 0.85),
    ]),
    ("desktop_move", [
        (r"\bmove\s+(?:the\s+)?mouse\b", 0.9),
        (r"\bdrag\s+\S+", 0.9),
    ]),
    ("desktop_press", [
        (r"\bpress\s+(?:the\s+)?(?:enter|return|esc|escape|tab|space|ctrl|shift|alt)\b", 0.95),
        (r"\bhit\s+(?:the\s+)?(?:enter|return|esc|escape|tab|space)\b", 0.95),
        (r"\bpress\s+\w+\b", 0.8),
    ]),

    # ── Weather / Time / Date ─────────────────────────────────────────────
    ("weather", [
        (r"\bwhat('s| is) the weather\b", 1.0),
        (r"\bhow('s| is) the weather\b", 0.95),
        (r"\bweather\s+(?:in |at |for )?\w+", 0.9),
        (r"\bwill it rain\b", 0.9),
        (r"\btemperature\s+(?:in |at )?\w+", 0.85),
    ]),
    ("time", [
        (r"\bwhat time is it\b", 1.0),
        (r"\bcurrent time\b", 0.9),
        (r"\btime now\b", 0.85),
    ]),
    ("date", [
        (r"\bwhat day is it\b", 1.0),
        (r"\bwhat('s| is) the date\b", 0.95),
        (r"\btoday's date\b", 0.9),
    ]),

    # ── Web search ────────────────────────────────────────────────────────
    ("search", [
        (r"\bsearch for\b", 0.95),
        (r"\blook up\b", 0.9),
        (r"\bfind .{2,} online\b", 0.9),
        (r"\bsearch the web\b", 0.9),
        (r"\bgoogle\b", 0.85),
        (r"\bwhat('s| is) the (weather|news|score)\b", 0.8),
    ]),
]


def _compile_patterns() -> None:
    """Compile all raw patterns into regex objects at module load."""
    global _INTENT_PATTERNS
    _INTENT_PATTERNS = [
        (intent, [(re.compile(pat, re.IGNORECASE), weight) for pat, weight in patterns])
        for intent, patterns in _RAW_PATTERNS
    ]


_compile_patterns()


# =============================================================================
# Routing
# =============================================================================
def route(text: str) -> tuple[str, float]:
    """
    Classify text into an intent name and confidence score.

    Args:
        text: Raw user utterance.

    Returns:
        Tuple of (intent_name, confidence) where confidence is 0.0–1.0.
        Returns ('chat', 0.0) if no pattern matches.
    """
    t = text.lower().strip()
    best_intent = "chat"
    best_conf = 0.0

    for intent, patterns in _INTENT_PATTERNS:
        for pat, weight in patterns:
            if pat.search(t):
                if weight > best_conf:
                    best_conf = weight
                    best_intent = intent
                log.debug("Pattern matched [%s] (conf=%.2f): %r", intent, weight, text[:60])
                break  # first match in this intent group wins

    if best_intent == "chat":
        log.debug("Routed [chat] (no match): %r", text[:60])
    else:
        log.debug("Routed [%s] (conf=%.2f): %r", best_intent, best_conf, text[:60])

    return best_intent, best_conf


def list_intents() -> list[str]:
    """Return a list of all registered intent names (for testing / UI)."""
    return [intent for intent, _ in _INTENT_PATTERNS] + ["chat"]


# =============================================================================
# Parameter extraction
# =============================================================================
def extract_search_query(text: str) -> str:
    """
    Strip wake-word and trigger phrases, return the bare search query.

    'Nexumi search for Python tutorials' -> 'Python tutorials'
    """
    t = text.strip()
    t = re.sub(r"^\s*nexumi[,\s]*", "", t, flags=re.IGNORECASE)
    for phrase in [
        "search for", "search the web for", "look up",
        "google", "find online", "search",
    ]:
        t = re.sub(rf"^\s*{re.escape(phrase)}\s*", "", t, flags=re.IGNORECASE)
    return t.strip() or text.strip()


def extract_fact(text: str) -> str:
    """
    Pull the memorable content out of a 'remember that ...' sentence.

    'remember that I like ramen' -> 'I like ramen'
    'my name is Prakash'        -> 'my name is Prakash'
    """
    m = re.search(r"\bremember (?:that|this)\s+(.+)", text, re.IGNORECASE)
    if m:
        return m.group(1).strip().rstrip(".")
    m = re.search(r"\bdon'?t forget\s+(?:that\s+)?(.+)", text, re.IGNORECASE)
    if m:
        return m.group(1).strip().rstrip(".")
    m = re.search(r"\bmy \w+ is .+", text, re.IGNORECASE)
    if m:
        return m.group(0).strip().rstrip(".")
    return text.strip()


def extract_app_name(text: str) -> str:
    """Extract application name from 'open X' or 'launch X' commands."""
    for pat in [
        r"\blaunch\s+(\w+(?:[- ]\w+)*)",
        r"\bstart\s+(?:the\s+)?(\w+(?:[- ]\w+)*)\s+app",
        r"\bopen\s+(?!my\s+eyes|up\b)(\w+(?:[- ]\w+)*)",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip()
    return text.strip()


def extract_package_name(text: str) -> str:
    """Extract package name from install/uninstall/search text."""
    patterns = [
        r"\b(?:install|download|uninstall|remove)\s+(\w+(?:[- ]\w+)*)",
        r"\b(?:search\s+(?:for\s+)?|find\s+)package\s+(\w+)",
        r"\bpackage\s+(?:called\s+)?(\w+)",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            name = m.group(1).strip()
            # Strip common polite suffixes that aren't part of the package name
            name = re.sub(r"\s+(?:please|now|for me)$", "", name, flags=re.IGNORECASE)
            return name
    return text.strip()


def extract_file_paths(text: str, intent: str) -> dict[str, str]:
    """
    Extract file path(s) from file operation text.

    For copy/move: returns {"src": ..., "dest": ...}
    For others:    returns {"path": ...}
    """
    if intent in ("file_copy", "file_move"):
        m = re.search(r"\b(?:copy|move)\s+(.+?)\s+(?:to|into)\s+(.+)", text, re.IGNORECASE)
        if m:
            return {"src": m.group(1).strip(), "dest": m.group(2).strip()}
        m = re.search(r"\brename\s+(.+?)\s+to\s+(.+)", text, re.IGNORECASE)
        if m:
            return {"src": m.group(1).strip(), "dest": m.group(2).strip()}
        return {"src": text.strip(), "dest": ""}

    for pat in [
        r"\b(?:delete|remove|trash)\s+(.+)",
        r"\binfo\s+(?:about|for|on)\s+(.+)",
        r"\bget\s+info\s+(?:for|on)\s+(.+)",
        r"\bwhat\s+is\s+(.+)",
        r"\blist\s+(?:the\s+)?(?:files|directories|folders?)\s+(?:in\s+)?(.+)",
        r"\bshow\s+me\s+(?:the\s+)?(?:files\s+in\s+)?(.+)",
        r"\bwhat(?:'s| is)\s+in\s+(.+)",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return {"path": m.group(1).strip().rstrip(".?")}
    return {"path": text.strip()}


def extract_process_target(text: str) -> str:
    """Extract process name or PID from kill/stop/terminate text."""
    m = re.search(r"\b(?:kill|stop|terminate|end)\s+(?:process\s+)?(\w+|\d+)", text, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return text.strip()


def extract_click_target(text: str) -> str:
    """Extract target from 'click on X' or 'press the X button' commands."""
    for pat in [
        r"\bclick\s+(?:on\s+|the\s+)?(.+)",
        r"\bpress\s+(?:the\s+)?(.+)",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            target = m.group(1).strip()
            # Clean up common suffixes that aren't part of the target name
            target = re.sub(r"\s+button\s*$", "", target, flags=re.IGNORECASE)
            target = re.sub(r"\s+please\s*$", "", target, flags=re.IGNORECASE)
            return target.rstrip(".")
    return text.strip()


def extract_type_text(text: str) -> str:
    """Extract text to type from 'type X' or 'write X for me' commands."""
    for pat in [
        r"\btype\s+(?:out\s+|in\s+)?(.+)",
        r"\bwrite\s+(.+?)(?:\s+for me)?\s*$",
        r"\benter\s+(?:this\s+|the\s+)?text\s*[:\-]?\s*(.+)",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip(".")
    return text.strip()


def extract_scroll_direction(text: str) -> str:
    """Extract scroll direction: 'up' or 'down'."""
    t = text.lower()
    if re.search(r"\b(up|page\s+up)\b", t):
        return "up"
    if re.search(r"\b(down|page\s+down)\b", t):
        return "down"
    return "down"


def extract_drag_coords(text: str) -> dict[str, Any]:
    """
    Extract drag coordinates from 'drag from X,Y to X,Y' commands.
    Returns {"from": (x, y), "to": (x, y)} or empty dict if not found.
    """
    m = re.search(
        r"\bdrag\s+(?:from\s+)?(\d+)[,\s]+(\d+)\s+(?:to\s+)?(\d+)[,\s]+(\d+)",
        text, re.IGNORECASE,
    )
    if m:
        return {
            "from": (int(m.group(1)), int(m.group(2))),
            "to": (int(m.group(3)), int(m.group(4))),
        }
    return {}


def extract_key(text: str) -> str:
    """Extract key name from 'press enter' or 'hit escape' commands."""
    for pat in [
        r"\bpress\s+(?:the\s+)?(\w+(?:\s*\+\s*\w+)*)\b",
        r"\bhit\s+(?:the\s+)?(\w+)\b",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip().lower()
    return ""


def extract_weather_location(text: str) -> str:
    """
    Extract location from weather queries.
    'what's the weather in Tokyo' -> 'Tokyo'
    'will it rain' -> '' (current location)
    """
    for pat in [
        r"\bweather\s+(?:in |at |for )(.+?)(?:\?|$)",
        r"\btemperature\s+(?:in |at )(.+?)(?:\?|$)",
    ]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            return m.group(1).strip().rstrip("?")
    return ""


def extract_all_params(text: str, intent: str) -> dict[str, Any]:
    """
    Extract all relevant parameters for a given intent.
    Returns a dict that can be passed directly to dispatch handlers.

    Extractors that return dicts (e.g., file_copy -> {"src": ..., "dest": ...})
    are merged into the top-level params. Others are placed under "query".
    """
    extractors: dict[str, callable] = {
        "search": extract_search_query,
        "memory_store": extract_fact,
        "memory_query": lambda t: "",
        "app_launch": extract_app_name,
        "app_install": extract_package_name,
        "app_uninstall": extract_package_name,
        "package_search": extract_package_name,
        "file_list": lambda t: extract_file_paths(t, "file_list"),
        "file_delete": lambda t: extract_file_paths(t, "file_delete"),
        "file_copy": lambda t: extract_file_paths(t, "file_copy"),
        "file_move": lambda t: extract_file_paths(t, "file_move"),
        "file_info": lambda t: extract_file_paths(t, "file_info"),
        "process_list": lambda t: "",
        "process_kill": extract_process_target,
        "system_info": lambda t: "",
        "desktop_click": extract_click_target,
        "desktop_type": extract_type_text,
        "desktop_scroll": extract_scroll_direction,
        "desktop_move": extract_drag_coords,
        "desktop_press": extract_key,
        "screenshot": lambda t: "",
        "weather": extract_weather_location,
        "time": lambda t: "",
        "date": lambda t: "",
        "chat": lambda t: t,
    }
    fn = extractors.get(intent, lambda t: t)
    result = fn(text)

    params: dict[str, Any] = {"raw": text}
    if isinstance(result, dict):
        params.update(result)
    else:
        params["query"] = result
    return params
