"""
src/utils/audio_player.py

Non-blocking audio playback with volume control, callbacks, and graceful degradation.

Key design decisions
--------------------
- pygame.mixer is the primary backend; falls back to subprocess (mpg123/aplay)
  if pygame is unavailable or fails at runtime.
- Volume is thread-safe via threading.Lock and applied to both pygame and
  subprocess backends.
- Completion callbacks are per-file and fire on the worker thread.
- Queue inspection and pause/resume are exposed for UI integration.
- Mixer settings (frequency, channels, buffer) are configurable via settings.json.
- The worker thread exits cleanly within ~0.5s of shutdown() being called.
- Fallback command resolution is cached per file extension for performance.
"""

import os
import queue
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable, Optional

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("audio_player")

# ── Load mixer settings from config ───────────────────────────────────────────
_cfg = load_settings()
_audio_cfg = _cfg.get("audio_player", {})

MIXER_FREQ = int(_audio_cfg.get("frequency", 24000))
MIXER_SIZE = int(_audio_cfg.get("size", -16))
MIXER_CHANNELS = int(_audio_cfg.get("channels", 2))
MIXER_BUFFER = int(_audio_cfg.get("buffer", 1024))
FALLBACK_CMD = _audio_cfg.get("fallback_command", "auto")  # "auto", "mpg123", "aplay", "ffplay"

# ── State ─────────────────────────────────────────────────────────────────────
_queue: queue.Queue = queue.Queue()
_stop_event = threading.Event()
_volume_lock = threading.Lock()
_volume: float = 1.0
_callbacks: dict[str, Optional[Callable[[], None]]] = {}
_callbacks_lock = threading.Lock()
_is_paused = False
_pause_lock = threading.Lock()

# ── Fallback command cache ────────────────────────────────────────────────────
_fallback_cache: dict[str, list[str]] = {}

# ── Backend init ──────────────────────────────────────────────────────────────
_PYGAME_OK = False
pygame = None  # type: ignore

try:
    import pygame as _pygame
    pygame = _pygame
    pygame.mixer.init(
        frequency=MIXER_FREQ,
        size=MIXER_SIZE,
        channels=MIXER_CHANNELS,
        buffer=MIXER_BUFFER,
    )
    pygame.mixer.set_num_channels(8)
    _PYGAME_OK = True
    log.info(
        "pygame.mixer initialised (%d Hz, %d ch, buf=%d)",
        MIXER_FREQ, MIXER_CHANNELS, MIXER_BUFFER,
    )
except Exception as exc:
    log.warning("pygame unavailable (%s) — will use subprocess fallback", exc)


# =============================================================================
# Worker thread
# =============================================================================
def _worker() -> None:
    """Background thread: drains the audio queue and plays each file."""
    while not _stop_event.is_set():
        try:
            path = _queue.get(timeout=0.5)
        except queue.Empty:
            continue

        # Wait if paused
        while True:
            with _pause_lock:
                if not _is_paused:
                    break
            time.sleep(0.1)
            if _stop_event.is_set():
                break

        if _stop_event.is_set():
            _queue.task_done()
            continue

        _play_file(path)
        _queue.task_done()


def _play_file(path: str) -> None:
    """Play a single file using the best available backend."""
    basename = os.path.basename(path)
    callback: Optional[Callable[[], None]] = None
    with _callbacks_lock:
        callback = _callbacks.pop(path, None)

    # Try pygame first
    if _PYGAME_OK:
        try:
            _play_pygame(path, basename)
            if callback:
                try:
                    callback()
                except Exception as exc:
                    log.error("Playback callback error: %s", exc)
            return
        except Exception as exc:
            log.warning("pygame playback failed (%s), trying fallback", exc)

    # Subprocess fallback
    try:
        _play_subprocess(path, basename)
        if callback:
            try:
                callback()
            except Exception as exc:
                log.error("Playback callback error: %s", exc)
    except Exception as exc:
        log.error("Fallback playback failed for %s: %s", basename, exc)


def _play_pygame(path: str, basename: str) -> None:
    """Play via pygame.mixer.music with volume control."""
    assert pygame is not None
    pygame.mixer.music.load(path)
    with _volume_lock:
        pygame.mixer.music.set_volume(_volume)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        # Check for pause
        with _pause_lock:
            if _is_paused:
                pygame.mixer.music.pause()
                while True:
                    time.sleep(0.1)
                    with _pause_lock:
                        if not _is_paused:
                            pygame.mixer.music.unpause()
                            break
                    if _stop_event.is_set():
                        pygame.mixer.music.stop()
                        return
        if _stop_event.is_set():
            pygame.mixer.music.stop()
            return
        pygame.time.wait(50)


def _play_subprocess(path: str, basename: str) -> None:
    """Play via external command (mpg123, aplay, or ffplay)."""
    cmd = _resolve_fallback_cmd(path)
    if not cmd:
        raise RuntimeError("No fallback audio player available")

    # Apply volume via command-line if possible
    env = os.environ.copy()
    with _volume_lock:
        if _volume < 1.0 and "mpg123" in cmd[0]:
            # mpg123 supports -g (gain) 0-100
            gain = int(_volume * 100)
            cmd.extend(["-g", str(gain)])

    proc = subprocess.Popen(
        cmd + [path],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    while proc.poll() is None:
        if _stop_event.is_set():
            proc.terminate()
            proc.wait(timeout=2)
            return
        time.sleep(0.1)


def _resolve_fallback_cmd(path: str) -> list[str]:
    """Determine the best subprocess fallback command, with caching."""
    ext = Path(path).suffix.lower()
    cache_key = f"{FALLBACK_CMD}:{ext}"
    if cache_key in _fallback_cache:
        return _fallback_cache[cache_key]

    cmd: list[str] = []
    if FALLBACK_CMD == "mpg123" or (FALLBACK_CMD == "auto" and ext in (".mp3", ".mpeg")):
        if _which("mpg123"):
            cmd = ["mpg123", "-q"]
    if not cmd and (FALLBACK_CMD == "ffplay" or FALLBACK_CMD == "auto"):
        if _which("ffplay"):
            cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"]
    if not cmd and (FALLBACK_CMD == "aplay" or (FALLBACK_CMD == "auto" and ext in (".wav", ".au"))):
        if _which("aplay"):
            cmd = ["aplay", "-q"]
    # Last resort: any available player
    if not cmd:
        for player in ["mpg123", "ffplay", "aplay"]:
            if _which(player):
                if player == "mpg123":
                    cmd = ["mpg123", "-q"]
                elif player == "ffplay":
                    cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"]
                else:
                    cmd = ["aplay", "-q"]
                break

    _fallback_cache[cache_key] = cmd
    return cmd


def _which(cmd: str) -> bool:
    """Check if a command exists in PATH."""
    return subprocess.run(["which", cmd], capture_output=True).returncode == 0


# Start worker thread
_thread = threading.Thread(target=_worker, daemon=True, name="AudioPlayer")
_thread.start()


# =============================================================================
# Public API
# =============================================================================
def play(path: str, *, on_complete: Optional[Callable[[], None]] = None) -> None:
    """
    Enqueue an audio file (WAV or MP3) for non-blocking playback.

    Args:
        path: Absolute path to the audio file.
        on_complete: Optional callback invoked when playback finishes.
    """
    if not os.path.isfile(path):
        log.warning("Audio file not found: %s", path)
        return
    with _callbacks_lock:
        if on_complete:
            _callbacks[path] = on_complete
    _queue.put(path)
    log.debug("Queued: %s", os.path.basename(path))


def set_volume(level: float) -> None:
    """
    Set the global playback volume (0.0 to 1.0).
    Affects both current and future playback.
    """
    level = max(0.0, min(1.0, level))
    with _volume_lock:
        global _volume
        _volume = level
        if _PYGAME_OK and pygame.mixer.music.get_busy():
            pygame.mixer.music.set_volume(level)
    log.debug("Volume set to %.0f%%", level * 100)


def get_volume() -> float:
    """Return the current global volume (0.0 – 1.0)."""
    with _volume_lock:
        return _volume


def pause() -> None:
    """Pause current playback. No-op if nothing is playing."""
    with _pause_lock:
        global _is_paused
        _is_paused = True
    log.debug("Playback paused")


def resume() -> None:
    """Resume paused playback."""
    with _pause_lock:
        global _is_paused
        _is_paused = False
    log.debug("Playback resumed")


def is_paused() -> bool:
    """Return True if playback is currently paused."""
    with _pause_lock:
        return _is_paused


def queue_size() -> int:
    """Return the number of pending audio files in the queue."""
    return _queue.qsize()


def clear_queue() -> None:
    """Remove all pending files from the queue without stopping current playback."""
    count = 0
    while not _queue.empty():
        try:
            _queue.get_nowait()
            _queue.task_done()
            count += 1
        except queue.Empty:
            break
    log.debug("Cleared %d item(s) from audio queue", count)


def stop_all() -> None:
    """Interrupt current playback and clear the pending queue."""
    if _PYGAME_OK:
        pygame.mixer.music.stop()
    clear_queue()
    log.debug("Audio stopped and queue cleared")


def shutdown() -> None:
    """Signal the worker thread to exit and release pygame resources."""
    _stop_event.set()
    if _PYGAME_OK:
        pygame.mixer.music.stop()
        pygame.mixer.quit()
    log.info("Audio player shutdown")
