"""
src/utils/settings.py

Thread-safe settings and character config loader with defaults, validation,
environment overrides, and optional hot-reload.

Key design decisions
--------------------
- Missing keys are automatically filled from DEFAULT_SETTINGS so the app
  never crashes on a missing config value.
- Environment variables override file values (e.g., NEXUMI_WEBSOCKET_PORT=9000).
- Atomic writes use temp file + os.replace to prevent corruption.
- Thread-safe via threading.RLock.
- Optional watchdog-based hot-reload (falls back to polling if watchdog
  is not installed).
- JSON schema validation is attempted with jsonschema if available;
  otherwise a comprehensive custom validator is used.
- The get() function always returns the latest cached value, invalidated
  automatically by hot-reload callbacks.
"""

import json
import os
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Optional

from src.utils.logger import get_logger

log = get_logger("settings")

# ── Paths ─────────────────────────────────────────────────────────────────────
_ROOT = Path(__file__).resolve().parent.parent.parent
_SETTINGS_PATH  = _ROOT / "config" / "settings.json"
_CHARACTER_PATH = _ROOT / "config" / "character.json"

# ── Default settings ──────────────────────────────────────────────────────────
DEFAULT_SETTINGS: dict[str, Any] = {
    "websocket": {
        "host": "localhost",
        "port": 8765,
    },
    "websocket_server": {
        "host": "localhost",
        "port": 8765,
        "health_port": 8766,
        "max_message_size": 65536,
        "ping_interval": 20,
        "ping_timeout": 30,
        "metrics": {
            "enabled": True,
            "interval_sec": 60,
            "path": "logs/ws_metrics.jsonl",
        },
        "rate_limit": {
            "enabled": True,
            "messages": 30,
            "window_sec": 10,
            "burst": 5,
        },
        "stt_timeout": 5,
        "tts_timeout": 10,
        "brain_timeout": 15,
    },
    "window": {
        "x": 1500,
        "y": 200,
        "width": 350,
        "height": 600,
    },
    "memory": {
        "db_path": "data/memory.db",
        "refresh_interval_sec": 30,
    },
    "audio_player": {
        "frequency": 24000,
        "size": -16,
        "channels": 2,
        "buffer": 1024,
        "fallback_command": "auto",
    },
    "logging": {
        "console_level": "INFO",
        "file_level": "DEBUG",
        "json": False,
        "time_rotation": False,
        "async": False,
        "mute_third_party": ["urllib3", "websockets", "asyncio"],
    },
    "resource_monitor": {
        "enabled": True,
        "ram_warning_gb": 7.5,
        "cpu_warning_percent": 90.0,
        "cpu_warning_duration_sec": 300,
        "disk_warning_gb": 5.0,
        "check_interval_seconds": 30,
        "adaptive_interval": True,
        "min_interval_sec": 10,
        "max_interval_sec": 120,
    },
    "websearch": {
        "cache_ttl_sec": 300,
        "max_results": 3,
        "timeout_sec": 10,
        "max_retries": 3,
        "searxng_instance": "",
    },
    "screenshot": {
        "dir": "data/screenshots",
        "retention_days": 7,
    },
    "desktop": {
        "click_delay": 0.05,
        "type_interval": 0.01,
        "scroll_amount": 3,
        "app_map": {},
    },
    "api_keys": {
        "brave_search": "",
        "openai": "",
        "anthropic": "",
    },
    "vision": {
        "provider": "",
    },
}

DEFAULT_CHARACTER: dict[str, Any] = {
    "name": "Nexumi",
    "personality": "friendly and helpful",
    "voice": "default",
    "language": "en",
    "greeting": "Hello! I'm Nexumi, your AI companion.",
}

# ── Thread safety ─────────────────────────────────────────────────────────────
_lock = threading.RLock()
_cache: dict[str, dict] = {}
_watch_callbacks: list[Callable] = []
_watcher: Optional[Any] = None


# =============================================================================
# Internal helpers
# =============================================================================
def _read_json(path: Path, label: str) -> dict:
    """Read and parse a JSON file; raise RuntimeError with context on failure."""
    if not path.is_file():
        raise RuntimeError(
            f"{label} file not found: {path}\n"
            "Make sure you are running from the project root "
            "and that the config/ folder is present."
        )
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"{label} contains invalid JSON: {path}\n"
            f"JSON error: {e}\n"
            "Fix the file and restart Nexumi."
        ) from e


def _merge_defaults(data: dict, defaults: dict) -> dict:
    """Deep-merge data with defaults so missing keys are filled in."""
    result = deepcopy(defaults)
    for key, value in data.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge_defaults(value, result[key])
        else:
            result[key] = value
    return result


def _apply_env_overrides(data: dict, prefix: str = "NEXUMI") -> dict:
    """Override dict values with environment variables like NEXUMI_WEBSOCKET_PORT."""
    result = deepcopy(data)
    for key, value in os.environ.items():
        if not key.startswith(f"{prefix}_"):
            continue
        # NEXUMI_WEBSOCKET_PORT -> websocket.port
        path = key[len(prefix) + 1 :].lower().split("_")
        _set_nested(result, path, _coerce_env_value(value))
    return result


def _set_nested(data: dict, path: list[str], value: Any) -> None:
    """Set a nested dict key by path list."""
    for part in path[:-1]:
        data = data.setdefault(part, {})
    data[path[-1]] = value


def _coerce_env_value(value: str) -> Any:
    """Try to convert env string to int, float, bool, or keep as string."""
    lowered = value.lower()
    if lowered in ("true", "1", "yes", "on"):
        return True
    if lowered in ("false", "0", "no", "off"):
        return False
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _validate(data: dict, label: str) -> None:
    """Validate settings structure. Raises RuntimeError on invalid data."""
    # Try jsonschema if available
    try:
        import jsonschema
        schema = {
            "type": "object",
            "required": ["websocket"],
            "properties": {
                "websocket": {
                    "type": "object",
                    "required": ["host", "port"],
                    "properties": {
                        "host": {"type": "string"},
                        "port": {"type": "integer", "minimum": 1, "maximum": 65535},
                    },
                },
                "websocket_server": {
                    "type": "object",
                    "properties": {
                        "host": {"type": "string"},
                        "port": {"type": "integer", "minimum": 1, "maximum": 65535},
                        "health_port": {"type": "integer", "minimum": 1, "maximum": 65535},
                        "max_message_size": {"type": "integer", "minimum": 1024},
                        "ping_interval": {"type": "integer", "minimum": 1},
                        "ping_timeout": {"type": "integer", "minimum": 1},
                    },
                },
                "window": {
                    "type": "object",
                    "properties": {
                        "x": {"type": "integer"},
                        "y": {"type": "integer"},
                        "width": {"type": "integer", "minimum": 100},
                        "height": {"type": "integer", "minimum": 100},
                    },
                },
                "memory": {
                    "type": "object",
                    "properties": {
                        "db_path": {"type": "string"},
                        "refresh_interval_sec": {"type": "integer", "minimum": 1},
                    },
                },
                "api_keys": {
                    "type": "object",
                },
            },
        }
        jsonschema.validate(instance=data, schema=schema)
        return
    except ImportError:
        pass
    except jsonschema.ValidationError as e:
        raise RuntimeError(f"Settings validation failed: {e.message}") from e

    # Comprehensive custom validation
    required_sections = ["websocket"]
    for section in required_sections:
        if section not in data:
            raise RuntimeError(
                f"Missing '{section}' section in settings.json. "
                f"Add it with default values: {DEFAULT_SETTINGS.get(section, {})}"
            )

    # Validate websocket port range
    ws_port = data.get("websocket", {}).get("port")
    if ws_port is not None and not (1 <= ws_port <= 65535):
        raise RuntimeError(f"Invalid websocket port: {ws_port} (must be 1-65535)")

    # Validate window dimensions
    win = data.get("window", {})
    if win:
        for key in ("width", "height"):
            val = win.get(key)
            if val is not None and val < 100:
                raise RuntimeError(f"Invalid window {key}: {val} (minimum 100)")

    # Validate memory refresh
    mem = data.get("memory", {})
    if mem:
        refresh = mem.get("refresh_interval_sec")
        if refresh is not None and refresh < 1:
            raise RuntimeError(f"Invalid memory refresh_interval_sec: {refresh} (minimum 1)")


# =============================================================================
# Public API
# =============================================================================
def load_settings(config_path: Optional[str] = None) -> dict:
    """
    Load settings.json with defaults, env overrides, and validation.

    Args:
        config_path: Optional alternative path to settings.json.

    Returns:
        Deep-merged settings dict.
    """
    path = Path(config_path) if config_path else _SETTINGS_PATH
    with _lock:
        raw = _read_json(path, "settings.json")
        merged = _merge_defaults(raw, DEFAULT_SETTINGS)
        merged = _apply_env_overrides(merged)
        _validate(merged, "settings.json")
        _cache["settings"] = merged
        return deepcopy(merged)


def save_settings(data: dict, path: Optional[str] = None) -> None:
    """
    Write data back to settings.json atomically.

    Args:
        data: Settings dict to save.
        path: Optional alternative path.
    """
    target = Path(path) if path else _SETTINGS_PATH
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = target.with_suffix(".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, target)
        with _lock:
            _cache["settings"] = deepcopy(data)
        log.info("Settings saved to %s", target)
    except OSError as e:
        raise RuntimeError(f"Failed to save settings: {e}") from e
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def reload_settings() -> dict:
    """Reload settings from disk and return the updated dict."""
    return load_settings()


def load_character() -> dict:
    """Load character.json with defaults."""
    with _lock:
        raw = _read_json(_CHARACTER_PATH, "character.json")
        merged = _merge_defaults(raw, DEFAULT_CHARACTER)
        _cache["character"] = merged
        return deepcopy(merged)


def save_character(data: dict) -> None:
    """Write character.json atomically."""
    _CHARACTER_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = _CHARACTER_PATH.with_suffix(".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, _CHARACTER_PATH)
        with _lock:
            _cache["character"] = deepcopy(data)
        log.info("Character saved")
    except OSError as e:
        raise RuntimeError(f"Failed to save character.json: {e}") from e
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def get(key: str, default: Any = None) -> Any:
    """
    Convenience: load cached settings and return settings[key] or default.
    Cache is automatically invalidated by hot-reload callbacks.
    """
    with _lock:
        settings = _cache.get("settings")
    if settings is None:
        settings = load_settings()
    return settings.get(key, default)


# =============================================================================
# Hot-reload
# =============================================================================
def watch_settings(callback: Callable[[], None]) -> None:
    """
    Register a callback to be invoked when settings.json changes on disk.
    Uses watchdog if available; falls back to a polling thread.
    The callback is also registered as an internal cache invalidator.
    """
    global _watch_callbacks
    _watch_callbacks.append(callback)

    # Internal cache invalidator — always present
    def _invalidate_cache() -> None:
        with _lock:
            _cache.pop("settings", None)

    if _invalidate_cache not in _watch_callbacks:
        _watch_callbacks.append(_invalidate_cache)

    global _watcher
    if _watcher is not None:
        return

    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler

        class _Handler(FileSystemEventHandler):
            def on_modified(self, event):
                if event.src_path.endswith("settings.json"):
                    log.info("Settings file changed — reloading")
                    reload_settings()
                    for cb in _watch_callbacks:
                        try:
                            cb()
                        except Exception as exc:
                            log.error("Settings reload callback error: %s", exc)

        observer = Observer()
        observer.schedule(_Handler(), str(_SETTINGS_PATH.parent), recursive=False)
        observer.start()
        _watcher = observer
        log.info("Settings watchdog started")
    except ImportError:
        log.debug("watchdog not installed — using polling fallback")
        _start_polling_watcher()


def _start_polling_watcher(interval: int = 5) -> None:
    """Poll settings.json mtime and reload if changed."""
    import time

    last_mtime: float = 0.0
    if _SETTINGS_PATH.exists():
        last_mtime = _SETTINGS_PATH.stat().st_mtime

    def _poll() -> None:
        nonlocal last_mtime
        while True:
            time.sleep(interval)
            try:
                if _SETTINGS_PATH.exists():
                    mtime = _SETTINGS_PATH.stat().st_mtime
                    if mtime != last_mtime:
                        last_mtime = mtime
                        log.info("Settings file changed — reloading")
                        reload_settings()
                        for cb in _watch_callbacks:
                            try:
                                cb()
                            except Exception as exc:
                                log.error("Settings reload callback error: %s", exc)
            except Exception as exc:
                log.error("Settings poll error: %s", exc)

    threading.Thread(target=_poll, daemon=True, name="SettingsPoll").start()


def unwatch_settings() -> None:
    """Stop the settings file watcher."""
    global _watcher
    if _watcher is not None:
        try:
            _watcher.stop()
            _watcher.join(timeout=2.0)
        except Exception as exc:
            log.warning("Error stopping watcher: %s", exc)
        _watcher = None
    _watch_callbacks.clear()
