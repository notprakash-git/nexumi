"""
src/utils/logger.py

Rotating file + coloured console logger with configurable levels, JSON mode,
and optional async QueueHandler for performance.

Key design decisions
--------------------
- Console and file levels are configurable via settings.json.
- JSON mode outputs structured lines to the file for external parsing.
- Time-based rotation is supported alongside size-based (off by default).
- Third-party noise suppression via a configurable mute list.
- Async logging uses QueueHandler + QueueListener (off by default).
- Directory creation falls back to /tmp if the logs dir is not writable.
- ANSI colours are applied to a *copy* of the record so file output stays clean.
- Auto-shutdown: registers atexit handler to close async listener.
"""

import atexit
import json
import logging
import logging.handlers
import os
import queue
import sys
import threading
from pathlib import Path
from typing import Any, Callable, Optional

from src.utils.settings import load_settings

# ── Config ────────────────────────────────────────────────────────────────────
try:
    _cfg = load_settings()
except Exception:
    _cfg = {}

_log_cfg = _cfg.get("logging", {})

_CONSOLE_LEVEL = _log_cfg.get("console_level", "INFO").upper()
_FILE_LEVEL    = _log_cfg.get("file_level", "DEBUG").upper()
_JSON_MODE     = _log_cfg.get("json", False)
_TIME_ROTATION = _log_cfg.get("time_rotation", False)
_ASYNC_MODE    = _log_cfg.get("async", False)
_MUTE_LIST     = _log_cfg.get("mute_third_party", ["urllib3", "websockets", "asyncio"])

# ── Paths ─────────────────────────────────────────────────────────────────────
_LOG_DIR = Path(__file__).resolve().parent.parent.parent / "logs"
_LOG_FILE = _LOG_DIR / "nexumi.log"

# Fallback to /tmp if logs dir is not writable
try:
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    test_file = _LOG_DIR / ".write_test"
    test_file.write_text("")
    test_file.unlink()
except OSError:
    _LOG_DIR = Path("/tmp/nexumi_logs")
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    _LOG_FILE = _LOG_DIR / "nexumi.log"

# ── ANSI colours ──────────────────────────────────────────────────────────────
_ANSI: dict[str, str] = {
    "DEBUG":    "\033[36m",   # cyan
    "INFO":     "\033[32m",   # green
    "WARNING":  "\033[33m",   # yellow
    "ERROR":    "\033[31m",   # red
    "CRITICAL": "\033[35m",   # magenta
    "RESET":    "\033[0m",
}

_FMT_FILE    = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_FMT_CONSOLE = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FMT    = "%H:%M:%S"

# ── Global state ──────────────────────────────────────────────────────────────
_listener: Optional[logging.handlers.QueueListener] = None
_listener_lock = threading.Lock()
_all_handlers: list[logging.Handler] = []
_all_handlers_lock = threading.Lock()


# =============================================================================
# Formatters
# =============================================================================
class _ColourFormatter(logging.Formatter):
    """Adds ANSI colour to levelname on a *copy* of the record."""

    def format(self, record: logging.LogRecord) -> str:
        rec = logging.makeLogRecord(record.__dict__)
        colour = _ANSI.get(rec.levelname, "")
        reset = _ANSI["RESET"]
        rec.levelname = f"{colour}{rec.levelname}{reset}"
        return super().format(rec)


class _JsonFormatter(logging.Formatter):
    """Outputs log records as JSON lines."""

    def format(self, record: logging.LogRecord) -> str:
        obj = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        if record.exc_info:
            obj["exception"] = self.formatException(record.exc_info)
        return json.dumps(obj, default=str)


# =============================================================================
# Internal helpers
# =============================================================================
def _build_handlers() -> list[logging.Handler]:
    """Create file and console handlers."""
    handlers: list[logging.Handler] = []

    # File handler
    if _TIME_ROTATION:
        fh: logging.Handler = logging.handlers.TimedRotatingFileHandler(
            _LOG_FILE,
            when="midnight",
            backupCount=7,
            encoding="utf-8",
        )
    else:
        fh = logging.handlers.RotatingFileHandler(
            _LOG_FILE,
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
    fh.setLevel(getattr(logging, _FILE_LEVEL, logging.DEBUG))
    fh.setFormatter(_JsonFormatter() if _JSON_MODE else logging.Formatter(_FMT_FILE))
    handlers.append(fh)

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(getattr(logging, _CONSOLE_LEVEL, logging.INFO))
    ch.setFormatter(_ColourFormatter(_FMT_CONSOLE, datefmt=_DATE_FMT))
    handlers.append(ch)

    return handlers


def _register_handlers(handlers: list[logging.Handler]) -> None:
    """Track all created handlers for runtime level changes."""
    with _all_handlers_lock:
        _all_handlers.extend(handlers)


def _setup_async(handlers: list[logging.Handler]) -> logging.Handler:
    """Set up QueueHandler + QueueListener and return the QueueHandler."""
    global _listener
    with _listener_lock:
        if _listener is None:
            log_queue: queue.Queue[logging.LogRecord] = queue.Queue(-1)
            qh = logging.handlers.QueueHandler(log_queue)
            _listener = logging.handlers.QueueListener(log_queue, *handlers)
            _listener.start()
            # Auto-shutdown on exit
            atexit.register(shutdown_async_listener)
            return qh
        # If listener already exists, just return a new QueueHandler pointing to same queue
        return logging.handlers.QueueHandler(_listener._queue)  # type: ignore


# =============================================================================
# Public API
# =============================================================================
def get_logger(name: str = "nexumi") -> logging.Logger:
    """
    Return a named logger, creating and configuring it on first call.

    Args:
        name: Logger namespace (e.g., "src.ui.desktop_mate").

    Returns:
        Configured logging.Logger instance.
    """
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    logger.propagate = False

    # Suppress third-party noise
    for noisy in _MUTE_LIST:
        logging.getLogger(noisy).setLevel(logging.WARNING)

    handlers = _build_handlers()
    _register_handlers(handlers)

    if _ASYNC_MODE:
        qh = _setup_async(handlers)
        logger.addHandler(qh)
    else:
        for h in handlers:
            logger.addHandler(h)

    return logger


def set_console_level(level: str) -> None:
    """
    Change the console handler level at runtime for ALL loggers.

    Args:
        level: One of DEBUG, INFO, WARNING, ERROR, CRITICAL.
    """
    level_upper = level.upper()
    numeric = getattr(logging, level_upper, None)
    if numeric is None:
        raise ValueError(f"Invalid log level: {level}")

    # Update all known console handlers
    with _all_handlers_lock:
        for handler in _all_handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
                handler.setLevel(numeric)

    # Also update any StreamHandlers on existing loggers
    for logger_name in list(logging.root.manager.loggerDict.keys()):
        logger = logging.getLogger(logger_name)
        for handler in logger.handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
                handler.setLevel(numeric)

    # Update root logger console handlers too
    for handler in logging.root.handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
            handler.setLevel(numeric)


def shutdown_async_listener() -> None:
    """Stop the QueueListener if async logging is enabled. Call on app exit."""
    global _listener
    with _listener_lock:
        if _listener is not None:
            _listener.stop()
            _listener = None
            atexit.unregister(shutdown_async_listener)
