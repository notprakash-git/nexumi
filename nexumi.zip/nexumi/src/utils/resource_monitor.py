"""
src/utils/resource_monitor.py

Resource monitor service for RAM, CPU, and disk usage.

Key design decisions
--------------------
- Can run as a daemon thread or be integrated into an existing asyncio loop.
- Uses a thread-safe send queue instead of creating event loops in threads,
  avoiding "event loop is closed" errors on shutdown.
- Adaptive check interval: increases when system is idle, decreases under load.
- Thresholds and enable/disable are configurable via settings.json.
- Self-test on startup checks psutil availability.
- Disk monitoring warns when home partition free space drops below threshold.
"""

import json
import queue
import threading
import time
from pathlib import Path
from typing import Any, Optional

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("resource_monitor")

# ── Config ────────────────────────────────────────────────────────────────────
try:
    _cfg = load_settings()
except Exception:
    _cfg = {}

_mon_cfg = _cfg.get("resource_monitor", {})
ENABLED         = _mon_cfg.get("enabled", True)
RAM_WARN_GB     = float(_mon_cfg.get("ram_warning_gb", 7.5))
CPU_WARN_PCT    = float(_mon_cfg.get("cpu_warning_percent", 90.0))
CPU_WARN_DURATION = int(_mon_cfg.get("cpu_warning_duration_sec", 300))
DISK_WARN_GB    = float(_mon_cfg.get("disk_warning_gb", 5.0))
CHECK_INTERVAL  = int(_mon_cfg.get("check_interval_seconds", 30))
ADAPTIVE        = _mon_cfg.get("adaptive_interval", True)
MIN_INTERVAL    = int(_mon_cfg.get("min_interval_sec", 10))
MAX_INTERVAL    = int(_mon_cfg.get("max_interval_sec", 120))

_ws_cfg = _cfg.get("websocket", {})
WS_HOST = _ws_cfg.get("host", "localhost")
WS_PORT = int(_ws_cfg.get("port", 8765))

# ── State ─────────────────────────────────────────────────────────────────────
_monitor_thread: Optional[threading.Thread] = None
_stop_event = threading.Event()
_send_queue: queue.Queue = queue.Queue()
_send_thread: Optional[threading.Thread] = None
_send_stop = threading.Event()

# CPU tracking for sustained high usage
_cpu_high_since: Optional[float] = None


# =============================================================================
# Self-test
# =============================================================================
def _self_test() -> bool:
    """Check if psutil is available and functional."""
    try:
        import psutil
        _ = psutil.virtual_memory()
        _ = psutil.cpu_percent(interval=0.1)
        _ = psutil.disk_usage("/")
        log.info("psutil self-test passed")
        return True
    except ImportError:
        log.error("psutil not installed — resource monitor disabled")
        return False
    except Exception as exc:
        log.error("psutil self-test failed: %s", exc)
        return False


# =============================================================================
# WebSocket sender (dedicated thread with its own event loop)
# =============================================================================
def _ws_sender_loop() -> None:
    """
    Dedicated thread that owns its asyncio event loop for WS connections.
    This avoids "event loop is closed" errors because the loop lives for
    the entire lifetime of the sender thread.
    """
    import asyncio
    import websockets

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    ws = None

    async def _connect() -> Any:
        uri = f"ws://{WS_HOST}:{WS_PORT}"
        return await websockets.connect(uri, open_timeout=3)

    async def _send(msg: str) -> None:
        nonlocal ws
        try:
            if ws is None:
                ws = await _connect()
            await ws.send(msg)
        except Exception:
            # Reconnect on any error
            try:
                if ws is not None:
                    await ws.close()
            except Exception:
                pass
            ws = None
            try:
                ws = await _connect()
                await ws.send(msg)
            except Exception as exc:
                log.debug("WS sender reconnect failed: %s", exc)

    while not _send_stop.is_set():
        try:
            msg = _send_queue.get(timeout=1.0)
        except queue.Empty:
            continue
        if msg is None:
            break
        try:
            loop.run_until_complete(_send(msg))
        except Exception as exc:
            log.debug("WS sender error: %s", exc)

    # Cleanup
    if ws is not None:
        try:
            loop.run_until_complete(ws.close())
        except Exception:
            pass
    loop.close()
    log.debug("WS sender thread exited")


def _send_warning(message: str) -> None:
    """Enqueue a warning message for the WS sender thread."""
    try:
        payload = json.dumps({"type": "resource_warning", "message": message})
        _send_queue.put(payload, block=False)
    except queue.Full:
        log.warning("Resource monitor send queue full — dropping warning")


# =============================================================================
# Monitoring logic
# =============================================================================
def _check_ram() -> Optional[str]:
    import psutil
    ram = psutil.virtual_memory()
    ram_used_gb = ram.used / (1024 ** 3)
    ram_total_gb = ram.total / (1024 ** 3)
    log.debug("RAM: %.2f/%.2f GB", ram_used_gb, ram_total_gb)
    if ram_used_gb >= RAM_WARN_GB:
        return f"⚠️ RAM usage is high: {ram_used_gb:.1f} GB used out of {ram_total_gb:.1f} GB. Consider closing apps."
    return None


def _check_cpu() -> Optional[str]:
    import psutil
    global _cpu_high_since
    cpu_pct = psutil.cpu_percent(interval=1)
    log.debug("CPU: %.1f%%", cpu_pct)

    if cpu_pct >= CPU_WARN_PCT:
        now = time.monotonic()
        if _cpu_high_since is None:
            _cpu_high_since = now
        elif now - _cpu_high_since >= CPU_WARN_DURATION:
            _cpu_high_since = None  # reset after warning
            return f"⚠️ CPU has been above {CPU_WARN_PCT:.0f}% for {CPU_WARN_DURATION}s. Consider closing heavy apps."
    else:
        _cpu_high_since = None
    return None


def _check_disk() -> Optional[str]:
    import psutil
    disk = psutil.disk_usage(Path.home())
    free_gb = disk.free / (1024 ** 3)
    log.debug("Disk free: %.2f GB", free_gb)
    if free_gb <= DISK_WARN_GB:
        return f"⚠️ Disk space is low: {free_gb:.1f} GB remaining on home partition."
    return None


def _adaptive_interval(cpu_pct: float, ram_used_pct: float) -> int:
    """Return check interval based on system load."""
    if not ADAPTIVE:
        return CHECK_INTERVAL
    load = max(cpu_pct / 100, ram_used_pct / 100)
    if load < 0.3:
        return MAX_INTERVAL
    if load < 0.6:
        return CHECK_INTERVAL
    return MIN_INTERVAL


# =============================================================================
# Thread-based monitor loop
# =============================================================================
def _monitor_loop() -> None:
    """Main monitoring loop that runs in a daemon thread."""
    log.info(
        "Resource monitor started (RAM≥%.1fGB, CPU≥%.0f%% for %ds, disk≤%.1fGB free)",
        RAM_WARN_GB, CPU_WARN_PCT, CPU_WARN_DURATION, DISK_WARN_GB,
    )

    while not _stop_event.is_set():
        try:
            import psutil
            cpu_pct = psutil.cpu_percent(interval=0.1)
            ram_pct = psutil.virtual_memory().percent
            interval = _adaptive_interval(cpu_pct, ram_pct)

            for check_fn in (_check_ram, _check_cpu, _check_disk):
                msg = check_fn()
                if msg:
                    log.warning(msg)
                    _send_warning(msg)

            # Wait with early exit on stop
            for _ in range(interval):
                if _stop_event.is_set():
                    break
                time.sleep(1)
        except Exception as exc:
            log.error("Resource monitor error: %s", exc)
            time.sleep(CHECK_INTERVAL)

    log.info("Resource monitor stopped")


# =============================================================================
# Public API
# =============================================================================
def start_monitor() -> bool:
    """
    Start the resource monitor in a daemon thread.

    Returns:
        True if the monitor started successfully, False otherwise.
    """
    global _monitor_thread, _send_thread
    if _monitor_thread is not None and _monitor_thread.is_alive():
        log.debug("Resource monitor already running")
        return True
    if not ENABLED:
        log.info("Resource monitor is disabled in settings")
        return False
    if not _self_test():
        return False

    _stop_event.clear()
    _send_stop.clear()

    # Start WS sender thread first
    _send_thread = threading.Thread(
        target=_ws_sender_loop,
        daemon=True,
        name="ResourceMonitor-WS",
    )
    _send_thread.start()

    # Start monitor thread
    _monitor_thread = threading.Thread(
        target=_monitor_loop,
        daemon=True,
        name="ResourceMonitor",
    )
    _monitor_thread.start()
    return True


def stop_monitor() -> None:
    """Signal the resource monitor to stop gracefully."""
    global _monitor_thread, _send_thread
    if _monitor_thread is None or not _monitor_thread.is_alive():
        log.debug("Resource monitor not running")
        return

    _stop_event.set()
    _send_stop.set()
    _send_queue.put(None)  # Signal sender to exit

    _monitor_thread.join(timeout=5.0)
    if _monitor_thread.is_alive():
        log.warning("Resource monitor did not stop within 5 seconds")
    _monitor_thread = None

    if _send_thread is not None:
        _send_thread.join(timeout=3.0)
        if _send_thread.is_alive():
            log.warning("WS sender thread did not stop within 3 seconds")
        _send_thread = None


def is_running() -> bool:
    """Return True if the monitor thread is active."""
    return _monitor_thread is not None and _monitor_thread.is_alive()


# =============================================================================
# CLI entry point
# =============================================================================
if __name__ == "__main__":
    if start_monitor():
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            stop_monitor()
