"""
src/core/stt.py

Speech-to-text engine for Nexumi with pluggable backends, real-time streaming,
voice-activity detection, noise reduction, metrics, and graceful degradation.

Backends (configured via ``settings.json`` → ``stt.backends``)
-------------------------------------------------------------
1. **google** – Web Speech API (online, fastest).
2. **vosk** – Offline Kaldi via Vosk (privacy-first, works without internet).
3. **whisper** – OpenAI Whisper (API or local ``openai-whisper`` / ``faster-whisper``).

Public API
----------
``listen_once()`` → ``Optional[str]``
    Synchronous, blocking call that records one utterance and returns the
    transcription. Backwards-compatible with existing Nexumi code.

``listen_stream()`` → ``AsyncGenerator[str, None]``
    Real-time partial transcription (Vosk-based). Yielded strings can be used
    as live subtitles by the GUI. Call ``stop_streaming()`` or break out of
    the ``async for`` loop to cancel cleanly.

``stop_streaming()`` → ``None``
    Signal an in-progress ``listen_stream()`` to shut down gracefully.

``get_cached_audio()`` → ``bytes``
    Raw PCM from the last *N* seconds (ring buffer). Useful for a “Retry”
    button in the UI.

``retry_cached()`` → ``Optional[str]``
    Re-run the full STT pipeline on the most recently cached audio.

Optional dependencies
---------------------
The following packages are **optional**. If missing, the associated feature is
silently skipped and a warning is logged.

===================  ==========================================================
Package              Feature
===================  ==========================================================
``speechrecognition``  Microphone capture + Google Web Speech API
``pyaudio``            Microphone capture + streaming
``vosk``               Offline Vosk backend + real-time streaming
``openai``             Whisper API mode
``openai-whisper``     Whisper local mode
``faster-whisper``     (alternative) Whisper local mode
``webrtcvad``          Voice-activity trimming (reduces false positives)
``noisereduce``        Spectral noise reduction (heavy, off by default)
``numpy``              Required by ``noisereduce``
===================  ==========================================================

Add them to ``requirements.txt`` (or ``install.sh``) as needed:

.. code-block:: text

    # Core
    speechrecognition
    pyaudio
    vosk

    # Optional
    openai
    openai-whisper
    webrtcvad
    noisereduce
    numpy

Configuration (settings.json)
-----------------------------
.. code-block:: json

    {
      "stt": {
        "backends": ["google", "vosk", "whisper"],
        "language": "en-US",
        "fallback_language": "en-GB",
        "audio": {
          "device_index": null,
          "timeout": 5,
          "phrase_time_limit": 15,
          "pause_threshold": 0.8,
          "non_speaking_duration": 0.5,
          "energy_threshold": 300,
          "dynamic_energy_threshold": true,
          "ambient_noise_duration": 0.5
        },
        "google": { "language": "en-US" },
        "vosk": {
          "model_path": "models/vosk-model-small-en-us-0.15"
        },
        "whisper": {
          "model_size": "base",
          "api_key": null,
          "api_base": null
        },
        "vad": {
          "enabled": false,
          "aggressiveness": 2,
          "frame_duration_ms": 30
        },
        "noise_reduce": {
          "enabled": false
        },
        "degradation": {
          "enabled": true,
          "failure_threshold": 5,
          "cooldown_seconds": 60
        },
        "audio_cache": {
          "enabled": true,
          "max_seconds": 10
        },
        "metrics": {
          "enabled": true,
          "path": "logs/stt_metrics.jsonl"
        },
        "streaming": {
          "frames_per_buffer": 4096,
          "max_silence_seconds": 5
        }
      }
    }

Environment variables
---------------------
``OPENAI_API_KEY``
    Used as a fallback for Whisper API mode when ``stt.whisper.api_key`` is
    not set in ``settings.json``.
"""

from __future__ import annotations

import asyncio
import json
import os
import threading
import time
import wave
from collections import deque
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("stt")

# ── Hard dependencies ──────────────────────────────────────────────────────
try:
    import speech_recognition as sr

    _SR_OK = True
except ImportError:
    sr = None  # type: ignore[assignment]
    _SR_OK = False

# ── Optional dependencies (guarded) ─────────────────────────────────────────
try:
    import webrtcvad

    _VAD_OK = True
except ImportError:
    webrtcvad = None  # type: ignore[assignment]
    _VAD_OK = False

try:
    import noisereduce as nr

    _NR_OK = True
except ImportError:
    nr = None  # type: ignore[assignment]
    _NR_OK = False

try:
    import whisper

    _WHISPER_OK = True
except ImportError:
    whisper = None  # type: ignore[assignment]
    _WHISPER_OK = False

try:
    import numpy as np

    _NUMPY_OK = True
except ImportError:
    np = None  # type: ignore[assignment]
    _NUMPY_OK = False

SAMPLE_RATE = 16000  # Vosk & STT standard


# =============================================================================
# Enums
# =============================================================================
class STTBackend(Enum):
    GOOGLE = "google"
    VOSK = "vosk"
    WHISPER = "whisper"


# =============================================================================
# Metrics
# =============================================================================
class STTMetrics:
    """
    Rolling JSONL metrics writer with size-based rotation (5 MiB × 3 backups).
    Thread-safe via ``threading.Lock``.
    """

    def __init__(self, enabled: bool, path: str, max_bytes: int = 5 * 1024 * 1024):
        self.enabled = enabled
        self.path = Path(path)
        self.max_bytes = max_bytes
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, record: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        with self._lock:
            if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                self._rotate()
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")

    def _rotate(self) -> None:
        for i in range(2, 0, -1):
            old = self.path.with_suffix(f".jsonl.{i}")
            new = self.path.with_suffix(f".jsonl.{i + 1}")
            if old.exists():
                old.rename(new)
        if self.path.exists():
            self.path.rename(self.path.with_suffix(".jsonl.1"))


# =============================================================================
# Audio ring buffer
# =============================================================================
class AudioCache:
    """
    Sliding window of raw 16-bit mono PCM. Stores chunks in a deque so that
    the total retained audio never exceeds *max_seconds*.
    """

    def __init__(self, enabled: bool, max_seconds: int, sample_rate: int = SAMPLE_RATE):
        self.enabled = enabled
        self.sample_rate = sample_rate
        self._max_bytes = sample_rate * 2 * max_seconds
        self._chunks: deque[bytes] = deque()
        self._total_bytes = 0

    def add(self, chunk: bytes) -> None:
        if not self.enabled:
            return
        self._chunks.append(chunk)
        self._total_bytes += len(chunk)
        while self._total_bytes > self._max_bytes and self._chunks:
            removed = self._chunks.popleft()
            self._total_bytes -= len(removed)

    def get_audio(self) -> bytes:
        return b"".join(self._chunks)

    def clear(self) -> None:
        self._chunks.clear()
        self._total_bytes = 0


# =============================================================================
# Main engine
# =============================================================================
class STTEngine:
    """
    Configurable speech-to-text engine.

    Responsibilities
    --------------
    - Capture audio via ``speech_recognition`` (blocking) or PyAudio (streaming).
    - Pre-process with optional VAD and noise reduction.
    - Try backends in priority order with automatic degradation / cooldown.
    - Cache raw audio and expose metrics.
    """

    def __init__(self) -> None:
        self.cfg = load_settings().get("stt", {})
        self._init_audio_settings()
        self._init_backend_settings()
        self._init_feature_settings()

        self.metrics = STTMetrics(
            enabled=self.cfg.get("metrics", {}).get("enabled", True),
            path=self.cfg.get("metrics", {}).get("path", "logs/stt_metrics.jsonl"),
        )
        self.audio_cache = AudioCache(
            enabled=self.cfg.get("audio_cache", {}).get("enabled", True),
            max_seconds=self.cfg.get("audio_cache", {}).get("max_seconds", 10),
        )

        # Degradation state
        self._failure_count = 0
        self._cooldown_until = 0.0
        self._muted_backends: set[str] = set()

        # Streaming lifecycle
        self._stream_stop_event: Optional[asyncio.Event] = None

        # Lazy-loaded models
        self._vosk_model: Any = None
        self._whisper_model: Any = None

    # ── Settings loaders ─────────────────────────────────────────────────────
    def _init_audio_settings(self) -> None:
        audio = self.cfg.get("audio", {})
        self.device_index: Optional[int] = audio.get("device_index")
        self.timeout = audio.get("timeout", 5)
        self.phrase_time_limit = audio.get("phrase_time_limit", 15)
        self.pause_threshold = audio.get("pause_threshold", 0.8)
        self.non_speaking_duration = audio.get("non_speaking_duration", 0.5)
        self.energy_threshold = audio.get("energy_threshold", 300)
        self.dynamic_energy_threshold = audio.get("dynamic_energy_threshold", True)
        self.ambient_noise_duration = audio.get("ambient_noise_duration", 0.5)

    def _init_backend_settings(self) -> None:
        raw_backends = self.cfg.get("backends", ["google", "vosk"])
        self.backends: List[STTBackend] = []
        for b in raw_backends:
            try:
                self.backends.append(STTBackend(b))
            except ValueError:
                log.warning(f"Unknown STT backend '{b}' in settings — skipping")

        self.language = self.cfg.get("language", "en-US")
        self.fallback_language = self.cfg.get("fallback_language", "en-US")

        # Vosk
        self.vosk_model_path = os.path.abspath(
            os.path.join(
                os.path.dirname(__file__),
                "../..",
                self.cfg.get("vosk", {}).get("model_path", "models/vosk-model-small-en-us-0.15"),
            )
        )

        # Whisper
        wh = self.cfg.get("whisper", {})
        self.whisper_model_size = wh.get("model_size", "base")
        # Allow env fallback so users don't have to hard-code keys in JSON
        self.whisper_api_key = wh.get("api_key") or os.environ.get("OPENAI_API_KEY")
        self.whisper_api_base = wh.get("api_base")

    def _init_feature_settings(self) -> None:
        # VAD
        vad = self.cfg.get("vad", {})
        self.vad_enabled = vad.get("enabled", False) and _VAD_OK
        self.vad_aggressiveness = vad.get("aggressiveness", 2)
        self.vad_frame_ms = vad.get("frame_duration_ms", 30)

        # Noise reduction
        nr_cfg = self.cfg.get("noise_reduce", {})
        self.nr_enabled = nr_cfg.get("enabled", False) and _NR_OK and _NUMPY_OK

        # Degradation
        deg = self.cfg.get("degradation", {})
        self.degradation_enabled = deg.get("enabled", True)
        self.failure_threshold = deg.get("failure_threshold", 5)
        self.cooldown_seconds = deg.get("cooldown_seconds", 60)

        # Streaming
        stream = self.cfg.get("streaming", {})
        self.stream_frames = stream.get("frames_per_buffer", 4096)
        self.stream_max_silence = stream.get("max_silence_seconds", 5)

    # ── Degradation helpers ──────────────────────────────────────────────────
    def _active_backends(self) -> List[STTBackend]:
        now = time.time()
        if now > self._cooldown_until:
            self._failure_count = 0
            self._muted_backends.clear()

        active = [b for b in self.backends if b.value not in self._muted_backends]
        return active if active else [STTBackend.VOSK]

    def _record_failure(self, backend: STTBackend) -> None:
        if not self.degradation_enabled:
            return
        if backend == STTBackend.GOOGLE:
            self._failure_count += 1
            if self._failure_count >= self.failure_threshold:
                log.warning(
                    f"Google failed {self.failure_threshold}× — cooling down "
                    f"for {self.cooldown_seconds}s"
                )
                self._muted_backends.add(STTBackend.GOOGLE.value)
                self._cooldown_until = time.time() + self.cooldown_seconds

    def _record_success(self) -> None:
        self._failure_count = 0
        self._muted_backends.discard(STTBackend.GOOGLE.value)

    # ── Model loaders ────────────────────────────────────────────────────────
    def _load_vosk_model(self) -> Any:
        if self._vosk_model is not None:
            return self._vosk_model
        if not os.path.isdir(self.vosk_model_path):
            log.warning(f"Vosk model not found: {self.vosk_model_path}")
            return None
        try:
            from vosk import Model

            self._vosk_model = Model(self.vosk_model_path)
            log.info(f"Vosk model loaded: {self.vosk_model_path}")
            return self._vosk_model
        except Exception as exc:
            log.warning(f"Vosk load failed: {exc}")
            return None

    def _load_whisper_local(self) -> Any:
        if self._whisper_model is not None:
            return self._whisper_model
        if not _WHISPER_OK:
            log.warning("whisper package not installed")
            return None
        try:
            self._whisper_model = whisper.load_model(self.whisper_model_size)
            log.info(f"Local Whisper loaded: {self.whisper_model_size}")
            return self._whisper_model
        except Exception as exc:
            log.warning(f"Local Whisper load failed: {exc}")
            return None

    # ── Pre-processing ─────────────────────────────────────────────────────────
    def _trim_vad(self, audio_bytes: bytes, sample_rate: int = SAMPLE_RATE) -> bytes:
        if not self.vad_enabled or webrtcvad is None:
            return audio_bytes

        try:
            vad = webrtcvad.Vad(self.vad_aggressiveness)
            frame_bytes = int(sample_rate * 2 * self.vad_frame_ms / 1000)

            if len(audio_bytes) < frame_bytes:
                return audio_bytes

            frames: List[Tuple[bytes, bool]] = []
            for i in range(0, len(audio_bytes) - frame_bytes + 1, frame_bytes):
                frame = audio_bytes[i : i + frame_bytes]
                frames.append((frame, vad.is_speech(frame, sample_rate)))

            # Trim leading silence
            start = 0
            for i, (_, is_speech) in enumerate(frames):
                if is_speech:
                    start = i
                    break

            # Trim trailing silence
            end = len(frames)
            for i in range(len(frames) - 1, -1, -1):
                if frames[i][1]:
                    end = i + 1
                    break

            trimmed = b"".join(f for f, _ in frames[start:end])
            log.debug(f"VAD: {len(audio_bytes)} → {len(trimmed)} bytes")
            return trimmed if trimmed else audio_bytes
        except Exception as exc:
            log.warning(f"VAD trim failed: {exc}")
            return audio_bytes

    def _reduce_noise(self, audio_bytes: bytes, sample_rate: int = SAMPLE_RATE) -> bytes:
        if not self.nr_enabled or nr is None or np is None:
            return audio_bytes
        try:
            audio_np = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32) / 32768.0
            reduced = nr.reduce_noise(y=audio_np, sr=sample_rate)
            reduced_int16 = (reduced * 32768.0).astype(np.int16)
            return reduced_int16.tobytes()
        except Exception as exc:
            log.warning(f"Noise reduction failed: {exc}")
            return audio_bytes

    # ── Audio capture ────────────────────────────────────────────────────────
    def _capture_once(self) -> Optional[Tuple[bytes, int]]:
        if not _SR_OK or sr is None:
            log.error("speech_recognition is not installed")
            return None

        recognizer = sr.Recognizer()
        recognizer.energy_threshold = self.energy_threshold
        recognizer.dynamic_energy_threshold = self.dynamic_energy_threshold
        recognizer.pause_threshold = self.pause_threshold
        recognizer.non_speaking_duration = self.non_speaking_duration

        try:
            mic = sr.Microphone(device_index=self.device_index)
            with mic as source:
                log.info("Listening…")
                recognizer.adjust_for_ambient_noise(
                    source, duration=self.ambient_noise_duration
                )
                audio = recognizer.listen(
                    source,
                    timeout=self.timeout,
                    phrase_time_limit=self.phrase_time_limit,
                )
        except sr.WaitTimeoutError:
            log.debug("STT listen timeout")
            return None
        except Exception as exc:
            log.error(f"Microphone error: {exc}")
            return None

        raw = audio.get_raw_data(convert_rate=SAMPLE_RATE, convert_width=2)
        return raw, SAMPLE_RATE

    # ── Backend transcribers ─────────────────────────────────────────────────
    def _transcribe_google(
        self, audio_bytes: bytes, sample_rate: int, language: str
    ) -> Optional[str]:
        if not _SR_OK or sr is None:
            return None
        try:
            audio_data = sr.AudioData(audio_bytes, sample_rate, 2)
            # Create a fresh Recognizer so we don't depend on the capture instance
            recognizer = sr.Recognizer()
            text = recognizer.recognize_google(audio_data, language=language)
            log.info(f"Google STT: {text!r}")
            return text
        except sr.UnknownValueError:
            log.debug("Google STT: could not understand audio")
            return None
        except sr.RequestError as exc:
            log.warning(f"Google STT request error: {exc}")
            return None

    def _transcribe_vosk(self, audio_bytes: bytes, sample_rate: int) -> Optional[str]:
        try:
            from vosk import KaldiRecognizer

            model = self._load_vosk_model()
            if model is None:
                return None
            rec = KaldiRecognizer(model, sample_rate)
            rec.AcceptWaveform(audio_bytes)
            result = json.loads(rec.FinalResult())
            text = result.get("text", "").strip()
            if text:
                log.info(f"Vosk STT: {text!r}")
                return text
            return None
        except Exception as exc:
            log.error(f"Vosk STT error: {exc}")
            return None

    def _transcribe_whisper(
        self, audio_bytes: bytes, sample_rate: int, language: str
    ) -> Optional[str]:
        lang_code = language.split("-")[0] if language != "auto" else None

        # 1) API mode
        if self.whisper_api_key:
            try:
                from openai import OpenAI

                client = OpenAI(api_key=self.whisper_api_key, base_url=self.whisper_api_base)
                with wave.open("tmp_stt_whisper.wav", "wb") as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(sample_rate)
                    wf.writeframes(audio_bytes)

                with open("tmp_stt_whisper.wav", "rb") as audio_file:
                    transcript = client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file,
                        language=lang_code,
                    )
                os.remove("tmp_stt_whisper.wav")
                text = transcript.text.strip()
                if text:
                    log.info(f"Whisper API: {text!r}")
                    return text
            except Exception as exc:
                log.warning(f"Whisper API error: {exc}")

        # 2) Local mode
        model = self._load_whisper_local()
        if model is None:
            return None
        try:
            with wave.open("tmp_stt_whisper.wav", "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(sample_rate)
                wf.writeframes(audio_bytes)

            result = model.transcribe("tmp_stt_whisper.wav", language=lang_code)
            os.remove("tmp_stt_whisper.wav")
            text = result.get("text", "").strip()
            if text:
                log.info(f"Whisper local: {text!r}")
                return text
            return None
        except Exception as exc:
            log.error(f"Whisper local error: {exc}")
            return None

    # ── Public API ───────────────────────────────────────────────────────────
    def listen_once(self) -> Optional[str]:
        """
        Record a single utterance and return the transcribed text.

        Execution flow
        --------------
        1. Capture audio via ``speech_recognition``.
        2. Push raw audio into the ring buffer.
        3. Trim silence with VAD (if enabled).
        4. Reduce noise (if enabled).
        5. Try each active backend in priority order.
        6. Log metrics and return the first successful transcription,
           or ``None`` if every backend fails.
        """
        t0 = time.perf_counter()
        capture = self._capture_once()

        if capture is None:
            self.metrics.log(
                {
                    "timestamp": datetime.now().isoformat(),
                    "event": "listen_once",
                    "success": False,
                    "latency_ms": int((time.perf_counter() - t0) * 1000),
                    "error_type": "capture_failure",
                    "backend": None,
                    "transcription": None,
                    "language": self.language,
                }
            )
            return None

        audio_bytes, sample_rate = capture
        self.audio_cache.add(audio_bytes)

        audio_bytes = self._trim_vad(audio_bytes, sample_rate)
        audio_bytes = self._reduce_noise(audio_bytes, sample_rate)

        text: Optional[str] = None
        used_backend: Optional[str] = None
        error_type: Optional[str] = None

        for backend in self._active_backends():
            t_backend = time.perf_counter()
            try:
                if backend == STTBackend.GOOGLE:
                    text = self._transcribe_google(audio_bytes, sample_rate, self.language)
                elif backend == STTBackend.VOSK:
                    text = self._transcribe_vosk(audio_bytes, sample_rate)
                elif backend == STTBackend.WHISPER:
                    text = self._transcribe_whisper(audio_bytes, sample_rate, self.language)

                if text:
                    used_backend = backend.value
                    self._record_success()
                    break
                else:
                    error_type = "empty_transcription"
                    self._record_failure(backend)
            except Exception as exc:
                error_type = type(exc).__name__
                log.error(f"{backend.value} exception: {exc}")
                self._record_failure(backend)

        latency_ms = int((time.perf_counter() - t0) * 1000)
        self.metrics.log(
            {
                "timestamp": datetime.now().isoformat(),
                "event": "listen_once",
                "success": text is not None,
                "latency_ms": latency_ms,
                "error_type": error_type,
                "backend": used_backend,
                "transcription": text,
                "language": self.language,
            }
        )
        return text

    async def listen_stream(self) -> AsyncGenerator[str, None]:
        """
        Real-time streaming STT using Vosk.

        Yields partial transcriptions as the user speaks. The caller should
        ``break`` out of the ``async for`` loop (or call ``stop_streaming()``)
        to cancel cleanly. The generator will then shut down the PyAudio
        stream and release resources.

        Requires ``vosk`` and ``pyaudio``.
        """
        if STTBackend.VOSK not in self.backends:
            log.warning("listen_stream requires Vosk in stt.backends")
            return

        model = self._load_vosk_model()
        if model is None:
            log.error("Vosk model unavailable — cannot stream")
            return

        try:
            import pyaudio
            from vosk import KaldiRecognizer
        except ImportError as exc:
            log.error(f"Streaming requires pyaudio+vosk: {exc}")
            return

        rec = KaldiRecognizer(model, SAMPLE_RATE)
        pa = pyaudio.PyAudio()

        # Resolve device index (same logic as capture)
        device_index = self.device_index
        if device_index is not None:
            try:
                info = pa.get_device_info_by_index(device_index)
                if info.get("maxInputChannels", 0) <= 0:
                    raise ValueError("no input channels")
            except Exception as exc:
                log.warning(f"Device {device_index} invalid ({exc}), using default")
                device_index = None

        stream = pa.open(
            format=pyaudio.paInt16,
            channels=1,
            rate=SAMPLE_RATE,
            input=True,
            frames_per_buffer=self.stream_frames,
            input_device_index=device_index,
        )

        # Create a fresh cancel event for this streaming session
        self._stream_stop_event = asyncio.Event()
        silence_start: Optional[float] = None
        log.info("Streaming STT started")

        try:
            while not self._stream_stop_event.is_set():
                try:
                    data = stream.read(self.stream_frames, exception_on_overflow=False)
                except Exception:
                    # Stream may be closed during shutdown
                    break

                self.audio_cache.add(data)

                if rec.AcceptWaveform(data):
                    result = json.loads(rec.Result())
                    text = result.get("text", "").strip()
                    if text:
                        silence_start = None
                        yield text
                else:
                    partial = json.loads(rec.PartialResult())
                    text = partial.get("partial", "").strip()
                    if text:
                        silence_start = None
                        yield text
                    else:
                        # Track silence for auto-stop
                        if silence_start is None:
                            silence_start = time.time()
                        elif time.time() - silence_start > self.stream_max_silence:
                            log.debug("Streaming auto-stopped after silence")
                            break

        except asyncio.CancelledError:
            log.info("Streaming cancelled by caller")
        except GeneratorExit:
            log.debug("Streaming generator exited (caller broke out of async for)")
        finally:
            self._stream_stop_event = None
            try:
                stream.stop_stream()
                stream.close()
            except Exception:
                pass
            try:
                pa.terminate()
            except Exception:
                pass
            log.info("Streaming STT stopped")

    def stop_streaming(self) -> None:
        """
        Signal an in-progress ``listen_stream()`` to shut down gracefully.
        Safe to call even if no stream is running.
        """
        if self._stream_stop_event is not None:
            self._stream_stop_event.set()

    def get_cached_audio(self) -> bytes:
        """Return the raw PCM currently held in the ring buffer."""
        return self.audio_cache.get_audio()

    def retry_cached(self) -> Optional[str]:
        """
        Re-run the full STT pipeline on the most recently cached audio.
        Useful when the user clicks “I said that already” in the GUI.
        """
        audio_bytes = self.audio_cache.get_audio()
        if not audio_bytes:
            log.warning("No cached audio to retry")
            return None

        log.info("Retrying STT on cached audio…")
        t0 = time.perf_counter()

        audio_bytes = self._trim_vad(audio_bytes, SAMPLE_RATE)
        audio_bytes = self._reduce_noise(audio_bytes, SAMPLE_RATE)

        text: Optional[str] = None
        used_backend: Optional[str] = None

        for backend in self._active_backends():
            if backend == STTBackend.GOOGLE:
                text = self._transcribe_google(audio_bytes, SAMPLE_RATE, self.language)
            elif backend == STTBackend.VOSK:
                text = self._transcribe_vosk(audio_bytes, SAMPLE_RATE)
            elif backend == STTBackend.WHISPER:
                text = self._transcribe_whisper(audio_bytes, SAMPLE_RATE, self.language)

            if text:
                used_backend = backend.value
                break

        self.metrics.log(
            {
                "timestamp": datetime.now().isoformat(),
                "event": "retry_cached",
                "success": text is not None,
                "latency_ms": int((time.perf_counter() - t0) * 1000),
                "backend": used_backend,
                "transcription": text,
                "language": self.language,
            }
        )
        return text


# =============================================================================
# Module-level singleton (backward-compatible API)
# =============================================================================
_engine: Optional[STTEngine] = None


def _get_engine() -> STTEngine:
    global _engine
    if _engine is None:
        _engine = STTEngine()
    return _engine


def listen_once() -> Optional[str]:
    """
    Record a single utterance from the microphone and return transcribed text.

    Tries configured backends in order with automatic fallback.
    Returns ``None`` if nothing could be understood.
    """
    return _get_engine().listen_once()


async def listen_stream() -> AsyncGenerator[str, None]:
    """
    Async generator yielding partial transcriptions in real time.

    Requires the Vosk backend to be enabled in ``settings.json``.
    """
    engine = _get_engine()
    async for text in engine.listen_stream():
        yield text


def stop_streaming() -> None:
    """Signal an in-progress stream to shut down gracefully."""
    _get_engine().stop_streaming()


def get_cached_audio() -> bytes:
    """Retrieve the last ~10 seconds of raw audio from the ring buffer."""
    return _get_engine().get_cached_audio()


def retry_cached() -> Optional[str]:
    """Re-run STT on the most recently cached audio."""
    return _get_engine().retry_cached()


__all__ = [
    "listen_once",
    "listen_stream",
    "stop_streaming",
    "get_cached_audio",
    "retry_cached",
    "STTBackend",
    "STTEngine",
]
