"""
src/core/brain.py

AI brain for Nexumi using OpenRouter via the openai Python SDK.

OpenRouter is compatible with the OpenAI SDK — you just set two things:
    base_url = "https://openrouter.ai/api/v1"
    api_key  = your OPENROUTER_API_KEY

No LangChain required. This keeps dependencies minimal and avoids
the deprecated LangChain calling style.

Model    : google/gemma-4-31b-it:free  (free tier, no billing needed)
Memory   : rolling window of last 20 conversation turns (in-memory)
           + SQLite long-term facts database
Fallback : returns a canned response if the API call fails for any reason

Required package:  pip install openai python-dotenv
"""
import gc
import json
import os
import sqlite3
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv

from src.utils.logger import get_logger
from src.utils.settings import load_character, load_settings

# ── Load API key from config/api_keys.env ────────────────────────────────────
_ENV_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../config/api_keys.env")
)
load_dotenv(_ENV_PATH)

log       = get_logger("brain")
_settings = load_settings()
_character = load_character()

# ── OpenRouter configuration ─────────────────────────────────────────────────
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL    = "google/gemma-4-31b-it:free"

# ── Fallback responses (used when API is unreachable) ────────────────────────
_FALLBACKS = [
    "Sorry, I had a little hiccup there. Could you say that again?",
    "My thoughts got all tangled. Give me a moment!",
    "I could not quite process that. Try again?",
]
_fallback_idx = 0


def _fallback() -> str:
    """Return the next fallback response in a rotating cycle."""
    global _fallback_idx
    r = _FALLBACKS[_fallback_idx % len(_FALLBACKS)]
    _fallback_idx += 1
    return r


# =============================================================================
# Stubs for optional / not-yet-implemented integrations
# =============================================================================

# Emotion selector — replace with real implementation when available
try:
    from src.integration.emotion_selector import select_emotion
except ImportError:
    def select_emotion(user_input: str, ai_response: str) -> str:
        """Stub emotion selector. Returns 'neutral' by default."""
        return "neutral"

# WebSocket hub — replace with real implementation when available.
# The real src.ui.websocket_server should expose get_websocket_hub() returning
# an object with a broadcast_emotion(emotion: str) method.
try:
    from src.ui.websocket_server import get_websocket_hub
except ImportError:
    class _WebSocketHubStub:
        """Stub WebSocket hub. Logs emotion instead of broadcasting."""
        def broadcast_emotion(self, emotion: str) -> None:
            log.debug(f"[WebSocketStub] Would broadcast emotion: {emotion!r}")

    _websocket_hub_stub = _WebSocketHubStub()

    def get_websocket_hub():
        """Return the global WebSocket hub. Replace stub with real implementation."""
        return _websocket_hub_stub


# =============================================================================
# Helpers
# =============================================================================

def _load_user_profile() -> dict:
    """Load user_profile.json from the config directory if it exists."""
    path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "../../config/user_profile.json")
    )
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Failed to load user_profile.json: {e}")
    return {}


# =============================================================================
# System prompt builder
# =============================================================================
def _build_system_prompt(mood: str, user_name: str) -> str:
    """
    Assemble the system prompt from character.json and the current mood.
    Injects personality, speech style, catchphrases, likes, dislikes,
    and the user's name.
    """
    char   = _character
    base   = (
        char.get("system_prompt_base", "You are Nexumi, a helpful AI companion.")
            .replace("{owner}", user_name)
    )
    style       = char.get("speech_style", {}).get(mood, "")
    catchphrases = ", ".join(char.get("catchphrases", []))
    likes        = ", ".join(char.get("likes", []))
    dislikes     = ", ".join(char.get("dislikes", []))

    return (
        f"{base}\n\n"
        f"Current mood: {mood}\n"
        f"Speech style ({mood}): {style}\n"
        f"Catchphrases you use occasionally: {catchphrases}\n"
        f"Things you like: {likes}\n"
        f"Things you dislike: {dislikes}\n"
        f"Today's date: {datetime.now().strftime('%A, %B %d %Y')}.\n"
        "Keep responses concise — under 3 sentences unless a longer "
        "explanation is genuinely needed. You are a companion, not a "
        "search engine. Be warm, natural, and stay in character."
    )


# =============================================================================
# Brain class
# =============================================================================
class Brain:
    """
    Nexumi's AI brain.

    Connects to OpenRouter using the openai SDK.
    Maintains a rolling conversation history (short-term memory) and
    a SQLite database of long-term facts taught by the user.

    Tool handling (search, desktop control, memory commands) is performed
    by the router before messages reach the brain.
    """

    def __init__(self):
        self._mood          = _settings.get("mood", "normal")
        self._user_profile  = _load_user_profile()
        self._user_name     = self._user_profile.get("name") or _character.get("owner", "my owner")
        self._system_prompt = _build_system_prompt(self._mood, self._user_name)
        self._memory_k      = _settings.get("memory", {}).get("short_term_k", 20)
        self._db_path       = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "../..",
            _settings.get("memory", {}).get("db_path", "data/memory.db")
        ))

        # Conversation history — list of {"role": ..., "content": ...} dicts
        # (same format the OpenAI API expects)
        self._history: list[dict] = []

        self._init_db()
        self._client = self._init_client()

    # ── OpenRouter client ─────────────────────────────────────────────────
    def _init_client(self):
        """
        Create and validate the OpenRouter client.
        Returns the client on success, None if the key is missing.
        """
        try:
            from openai import OpenAI
        except ImportError:
            log.error(
                "openai package not installed. "
                "Run: pip install openai"
            )
            return None

        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()

        if not api_key or api_key == "your_openrouter_api_key_here":
            log.error(
                "OPENROUTER_API_KEY is not set or still has the placeholder value.\n"
                "Edit config/api_keys.env and add your real key.\n"
                "Get a free key at https://openrouter.ai"
            )
            return None

        client = OpenAI(
            base_url=OPENROUTER_BASE_URL,
            api_key=api_key,
            default_headers={
                # OpenRouter uses these for your dashboard and rate limiting
                "HTTP-Referer": "https://nexumi.local",
                "X-Title":      "Nexumi Desktop Companion",
            },
        )

        log.info(
            f"Brain initialised — model: {OPENROUTER_MODEL} "
            f"via {OPENROUTER_BASE_URL}"
        )
        return client

    # ── SQLite long-term memory ───────────────────────────────────────────
    def _init_db(self) -> None:
        """Create the facts table if it does not already exist."""
        os.makedirs(os.path.dirname(self._db_path), exist_ok=True)
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS facts (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    fact_text   TEXT    NOT NULL,
                    category    TEXT    DEFAULT 'general',
                    learned_at  TEXT    DEFAULT CURRENT_TIMESTAMP,
                    confidence  INTEGER DEFAULT 10
                )
            """)
            conn.commit()
        log.debug(f"SQLite memory DB ready: {self._db_path}")

    def remember_fact(self, fact: str, category: str = "general") -> None:
        """Insert a new fact into the long-term memory database."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute(
                "INSERT INTO facts (fact_text, category) VALUES (?, ?)",
                (fact, category)
            )
            conn.commit()
        log.info(f"Stored fact: {fact!r} [{category}]")

    def recall_facts(self, keyword: Optional[str] = None) -> list[dict]:
        """
        Retrieve facts from the database.
        If keyword is given, filter by it. Otherwise return the 50 most recent.
        """
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            if keyword:
                rows = conn.execute(
                    "SELECT * FROM facts "
                    "WHERE fact_text LIKE ? "
                    "ORDER BY learned_at DESC LIMIT 20",
                    (f"%{keyword}%",)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM facts ORDER BY learned_at DESC LIMIT 50"
                ).fetchall()
        return [dict(r) for r in rows]

    def get_all_facts(self) -> list[dict]:
        """Return every stored fact, most recent first. Used by DataPanel."""
        with sqlite3.connect(self._db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM facts ORDER BY learned_at DESC"
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_fact(self, fact_id: int) -> None:
        """Delete a specific fact by its database ID."""
        with sqlite3.connect(self._db_path) as conn:
            conn.execute("DELETE FROM facts WHERE id=?", (fact_id,))
            conn.commit()
        log.debug(f"Deleted fact ID {fact_id}")

    # ── Mood ──────────────────────────────────────────────────────────────
    def set_mood(self, mood: str) -> None:
        """Switch personality mode (normal / flirty) and rebuild system prompt."""
        self._mood          = mood
        self._system_prompt = _build_system_prompt(mood, self._user_name)
        log.info(f"Mood changed to: {mood!r}")

    # ── Short-term memory management ──────────────────────────────────────
    def clear_history(self) -> None:
        """Reset the rolling conversation history."""
        self._history.clear()
        log.info("Short-term memory (conversation history) cleared.")

    # ── Core respond ──────────────────────────────────────────────────────
    def respond(self, user_input: str) -> str:
        """
        Send user_input to the LLM and return the response text.
        Falls back to a canned response if the API call fails.

        Automatically selects an emotion based on the exchange and
        broadcasts it to the WebSocket hub so the 3D avatar updates.
        """
        if not user_input or not user_input.strip():
            return _fallback()

        if self._client is None:
            log.warning("Brain client not initialised — returning fallback")
            return _fallback()

        try:
            # ── Build messages list ────────────────────────────────────────
            # Format: system prompt first, then rolling history, then new user message
            messages = [{"role": "system", "content": self._system_prompt}]
            messages += self._history[-(self._memory_k * 2):]
            messages.append({"role": "user", "content": user_input})

            # ── Call OpenRouter ────────────────────────────────────────────
            log.debug(
                f"Sending to {OPENROUTER_MODEL} "
                f"({len(messages)} messages in context)"
            )
            completion = self._client.chat.completions.create(
                model       = OPENROUTER_MODEL,
                messages    = messages,
                temperature = 0.85,
                max_tokens  = 300,
            )

            ai_text = completion.choices[0].message.content.strip()

            # ── Emotion selection & WebSocket broadcast ───────────────────
            try:
                chosen_emotion = select_emotion(user_input, ai_text)
                hub = get_websocket_hub()
                hub.broadcast_emotion(chosen_emotion)
            except Exception as e:
                # Non-critical: log but never crash the response pipeline
                log.warning(f"Emotion broadcast failed: {e}")

            # ── Update rolling history ─────────────────────────────────────
            self._history.append({"role": "user",      "content": user_input})
            self._history.append({"role": "assistant", "content": ai_text})

            # Keep history bounded to memory_k turns
            if len(self._history) > self._memory_k * 2:
                self._history = self._history[-(self._memory_k * 2):]

            log.debug(f"Response ({len(ai_text)} chars): {ai_text[:80]!r}")
            gc.collect()
            return ai_text

        except Exception as e:
            log.error(f"Brain.respond error: {e}")
            return _fallback()

    def is_ready(self) -> bool:
        """Return True if the client is initialised and ready to respond."""
        return self._client is not None


# =============================================================================
# Module-level singleton
# =============================================================================
_brain: Optional[Brain] = None


def get_brain() -> Brain:
    """Return the shared Brain instance, creating it on first call."""
    global _brain
    if _brain is None:
        _brain = Brain()
    return _brain
