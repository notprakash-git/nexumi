"""
src/core/wakeword.py

Vosk keyword spotting for Nexumi's configurable wake word.

Architecture
------------
1. Audio capture via PyAudio (configurable device index).
2. Vosk KaldiRecognizer processes 16 kHz mono PCM.
3. Two-stage detection:
   - Partial results feed a confidence accumulator (smoothing heuristic).
   - Final results immediately set confidence to 1.0.
4. When confidence >= ``min_confidence`` and the keyword is present,
   a trigger fires (subject to cooldown).
5. On trigger:
   - A WebSocket message ``{"type": "wake_word_detected"}`` is sent.
   - Optional 3-second audio context (raw PCM) is attached as base64.
   - Optional audio feedback (beep/voice) is played locally.
6. A persistent WebSocket connection also listens for remote commands
   (mute / unmute / toggle_mute) from the GUI/system tray.
7. Metrics (detections, uptime, etc.) are flushed to
   ``logs/wakeword_metrics.json`` every 60 s.

Configuration (settings.json)
-----------------------------
.. code-block:: json

    {
      "wake_word": {
        "keyword": "nexumi",
        "vosk_model_path": "models/vosk-model-small-en-us-0.15",
        "audio_device_index": null,
        "min_confidence": 0.5,
        "cooldown_seconds": 2.0,
        "frames_per_buffer": 4096,
        "send_audio_context": false,
        "feedback": {
          "enabled": true,
          "sound": "assets/beep.wav"
        }
      },
      "websocket": {
        "host": "localhost",
        "port": 8765
      }
    }

Command-line overrides
----------------------
--list-devices      Print available input devices and exit.
--keyword TEXT      Override wake word.
--model PATH        Override Vosk model directory.
--device-index N    Override audio input device.
--no-feedback       Disable audio feedback regardless of config.
--log-level LEVEL   DEBUG, INFO, WARNING, or ERROR.

Troubleshooting
---------------
- No microphone detected? Run ``python -m src.core.wakeword --list-devices``
  and update ``audio_device_index`` in settings.json.
- High false-positive rate? Increase ``min_confidence`` (e.g. 0.7) or
  lengthen ``cooldown_seconds``.
- Wake word not detected? Check that the Vosk model matches your language
  and that the microphone is not muted at the OS level.
"""

import argparse
import asyncio
import base64
import collections
import json
import logging
import os
import signal
import sys
import threading
import time
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional, Callable

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from src.utils.settings import load_settings

# ── Constants ────────────────────────────────────────────────────────────────
SAMPLE_RATE = 16000  # Vosk models expect 16 kHz

# Confidence smoothing parameters
_CONFIDENCE_STEP_UP = 0.25   # boost when keyword appears in partial result
_CONFIDENCE_STEP_DOWN = 0.15  # decay when keyword absent


# =============================================================================
# CLI helpers
# =============================================================================
def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m src.core.wakeword",
        description="Nexumi wake-word listener with Vosk + WebSocket hub",
    )
    parser.add_argument(
        "--list-devices", action="store_true",
        help="List available audio input devices and exit"
    )
    parser.add_argument(
        "--keyword", type=str, default=None,
        help="Override the wake word defined in settings.json"
    )
    parser.add_argument(
        "--model", type=str, default=None,
        help="Override the Vosk model path"
    )
    parser.add_argument(
        "--device-index", type=int, default=None,
        help="Override the audio input device index"
    )
    parser.add_argument(
        "--no-feedback", action="store_true",
        help="Disable audio feedback even if enabled in settings"
    )
    parser.add_argument(
        "--log-level", type=str, default=None,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Override the logging level for the wakeword module"
    )
    return parser


def _list_devices() -> None:
    """Print all PyAudio input devices to stdout."""
    try:
        import pyaudio
    except ImportError:
        print("ERROR: pyaudio is not installed. Run: pip install pyaudio")
        return
    pa = pyaudio.PyAudio()
    print("Available audio input devices:")
    found = False
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        if info.get("maxInputChannels", 0) > 0:
            found = True
            print(
                f"  Index {i}: {info.get('name')}  "
                f"(channels={info.get('maxInputChannels')}, "
                f"defaultRate={int(info.get('defaultSampleRate'))})"
            )
    if not found:
        print("  (none found)")
    pa.terminate()


# =============================================================================
# WebSocket hub (bidirectional: send + receive commands)
# =============================================================================
class WebSocketHub:
    """
    Persistent WebSocket client running in a background thread.
    - Sends queued JSON payloads to the server.
    - Dispatches incoming messages via ``on_message`` callback.
    - Auto-reconnects with 1-second backoff.
    """

    def __init__(
        self,
        uri: str,
        on_message: Optional[Callable[[dict], None]] = None,
    ):
        self.uri = uri
        self.on_message = on_message
        self._queue: Optional[asyncio.Queue] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._stop_event = threading.Event()

    def start(self) -> None:
        self._thread.start()

    def stop(self, timeout: float = 3.0) -> None:
        self._stop_event.set()
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=timeout)

    def send(self, payload: dict) -> None:
        if self._loop is not None and self._loop.is_running() and self._queue is not None:
            asyncio.run_coroutine_threadsafe(self._queue.put(payload), self._loop)
        else:
            logging.getLogger("wakeword").warning("WebSocket hub not ready, dropping message")

    def _run(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._queue = asyncio.Queue()
        try:
            self._loop.run_until_complete(self._main_loop())
        finally:
            self._loop.close()

    async def _main_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                import websockets
                async with websockets.connect(self.uri, open_timeout=5) as ws:
                    logging.getLogger("wakeword").info("WebSocket hub connected")
                    listener = asyncio.create_task(self._listen(ws))
                    sender = asyncio.create_task(self._send_loop(ws))
                    done, pending = await asyncio.wait(
                        [listener, sender],
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    for task in pending:
                        task.cancel()
                    logging.getLogger("wakeword").warning(
                        "WebSocket hub disconnected, reconnecting in 1 s…"
                    )
            except Exception as exc:
                logging.getLogger("wakeword").warning(
                    f"WebSocket hub connection error: {exc}"
                )
            await asyncio.sleep(1)

    async def _listen(self, ws) -> None:
        try:
            async for message in ws:
                if self._stop_event.is_set():
                    break
                try:
                    data = json.loads(message)
                    if self.on_message:
                        self.on_message(data)
                except json.JSONDecodeError:
                    logging.getLogger("wakeword").warning(
                        f"Received invalid JSON from WS: {message[:200]}"
                    )
        except Exception as exc:
            if not self._stop_event.is_set():
                logging.getLogger("wakeword").warning(f"WebSocket listen error: {exc}")

    async def _send_loop(self, ws) -> None:
        try:
            while not self._stop_event.is_set():
                try:
                    payload = await asyncio.wait_for(self._queue.get(), timeout=0.5)
                except asyncio.TimeoutError:
                    continue
                await ws.send(json.dumps(payload))
        except Exception as exc:
            if not self._stop_event.is_set():
                logging.getLogger("wakeword").warning(f"WebSocket send error: {exc}")


# =============================================================================
# Main listener class
# =============================================================================
class WakeWordListener:
    """
    Encapsulates the entire wake-word pipeline: audio, Vosk, confidence
    tracking, WebSocket integration, metrics, and graceful shutdown.
    """

    def __init__(self, args: argparse.Namespace):
        self._args = args
        self._cfg = load_settings()
        self._apply_overrides()

        self._stop_event = threading.Event()
        self._muted = False
        self._confidence = 0.0
        self._last_detection = 0.0

        # Audio context ring buffer (3 seconds of raw PCM)
        buffer_maxlen = max(1, int((SAMPLE_RATE * 3) / self.frames_per_buffer))
        self._audio_buffer: collections.deque = collections.deque(maxlen=buffer_maxlen)

        # Metrics
        self._metrics_lock = threading.Lock()
        self._metrics = {
            "start_time": time.time(),
            "detections": 0,
            "false_positives": 0,
            "uptime_seconds": 0,
            "last_detection": None,
        }
        self._metrics_path = Path("logs/wakeword_metrics.json")

        # WebSocket hub (bidirectional)
        self._hub = WebSocketHub(self.ws_uri, on_message=self._on_ws_message)

        # Logger (configured after overrides so CLI --log-level works)
        self.log = self._setup_logging()

        # Background threads
        self._metrics_thread = threading.Thread(target=self._metrics_loop, daemon=True)

    # ── Configuration ───────────────────────────────────────────────────────
    def _apply_overrides(self) -> None:
        ww_cfg = self._cfg.get("wake_word", {})
        ws_cfg = self._cfg.get("websocket", {})

        self.keyword = (self._args.keyword or ww_cfg.get("keyword", "nexumi")).lower()

        raw_model = self._args.model or ww_cfg.get(
            "vosk_model_path", "models/vosk-model-small-en-us-0.15"
        )
        self.model_path = os.path.abspath(
            os.path.join(os.path.dirname(__file__), "../..", raw_model)
        )

        self.device_index = (
            self._args.device_index
            if self._args.device_index is not None
            else ww_cfg.get("audio_device_index", None)
        )

        fb_cfg = ww_cfg.get("feedback", {})
        self.feedback_enabled = (not self._args.no_feedback) and fb_cfg.get("enabled", False)
        self.feedback_sound = fb_cfg.get("sound", None)

        self.send_audio_context = ww_cfg.get("send_audio_context", False)
        self.min_confidence = ww_cfg.get("min_confidence", 0.5)
        self.cooldown = ww_cfg.get("cooldown_seconds", 2.0)
        self.frames_per_buffer = ww_cfg.get("frames_per_buffer", 4096)

        self.ws_uri = (
            f"ws://{ws_cfg.get('host', 'localhost')}:{ws_cfg.get('port', 8765)}"
        )

    # ── Logging ──────────────────────────────────────────────────────────────
    def _setup_logging(self) -> logging.Logger:
        logger = logging.getLogger("wakeword")
        # Ensure a file handler with rotation exists
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        handler = RotatingFileHandler(
            logs_dir / "wakeword.log",
            maxBytes=5 * 1024 * 1024,  # 5 MiB
            backupCount=3,
            encoding="utf-8",
        )
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        # Avoid adding duplicate handlers if re-initialised
        if not any(isinstance(h, RotatingFileHandler) for h in logger.handlers):
            logger.addHandler(handler)

        if self._args.log_level:
            logger.setLevel(getattr(logging, self._args.log_level))
        return logger

    # ── WebSocket command handler ────────────────────────────────────────────
    def _on_ws_message(self, data: dict) -> None:
        msg_type = data.get("type")
        action = data.get("action")

        if msg_type == "command" and action == "toggle_mute":
            self._muted = not self._muted
            self.log.info(f"Wake word listener muted toggled → {self._muted}")
        elif msg_type == "command" and action == "mute":
            self._muted = True
            self.log.info("Wake word listener muted (remote)")
        elif msg_type == "command" and action == "unmute":
            self._muted = False
            self.log.info("Wake word listener unmuted (remote)")
        elif msg_type == "mute":
            self._muted = bool(data.get("value", True))
            self.log.info(f"Wake word listener muted → {self._muted} (remote)")
        elif msg_type == "command" and action == "report_false_positive":
            with self._metrics_lock:
                self._metrics["false_positives"] += 1
            self.log.info("False positive reported (remote)")

    # ── Metrics ──────────────────────────────────────────────────────────────
    def _metrics_loop(self) -> None:
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=60.0)
            self._update_metrics()
            self._write_metrics()

    def _update_metrics(self) -> None:
        with self._metrics_lock:
            self._metrics["uptime_seconds"] = int(
                time.time() - self._metrics["start_time"]
            )

    def _write_metrics(self) -> None:
        with self._metrics_lock:
            snapshot = dict(self._metrics)
        try:
            self._metrics_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._metrics_path, "w", encoding="utf-8") as f:
                json.dump(snapshot, f, indent=2)
        except Exception as exc:
            self.log.warning(f"Failed to write metrics: {exc}")

    # ── Audio feedback ─────────────────────────────────────────────────────────
    def _play_feedback(self) -> None:
        if not self.feedback_enabled:
            return

        played = False
        sound_path = self.feedback_sound

        if sound_path and os.path.isfile(sound_path):
            # Attempt 1: simpleaudio (lightweight, no GUI needed)
            try:
                import simpleaudio as sa
                wave_obj = sa.WaveObject.from_wave_file(sound_path)
                wave_obj.play()
                played = True
                self.log.debug(f"Feedback via simpleaudio: {sound_path}")
            except Exception:
                pass

            # Attempt 2: pygame mixer (works headless with SDL_AUDIODRIVER=dummy)
            if not played:
                try:
                    import pygame
                    pygame.mixer.init(frequency=SAMPLE_RATE)
                    pygame.mixer.music.load(sound_path)
                    pygame.mixer.music.play()
                    played = True
                    self.log.debug(f"Feedback via pygame: {sound_path}")
                except Exception:
                    pass

        if not played:
            # Delegate to UI if local playback unavailable
            self._hub.send({
                "type": "wake_word_feedback",
                "sound": sound_path,
                "reason": "direct_playback_unavailable",
            })
            self.log.debug("Requested feedback via WebSocket (direct playback unavailable)")
        else:
            self.log.debug("Feedback sound triggered")

    # ── Audio device helpers ───────────────────────────────────────────────────
    def _open_audio_stream(self):
        import pyaudio

        self._pa = pyaudio.PyAudio()
        device_index = self.device_index

        if device_index is not None:
            try:
                info = self._pa.get_device_info_by_index(device_index)
                if info.get("maxInputChannels", 0) <= 0:
                    raise ValueError("device has no input channels")
                self.log.info(
                    f"Using requested audio device {device_index}: {info.get('name')}"
                )
            except Exception as exc:
                self.log.warning(
                    f"Requested device_index {device_index} invalid ({exc}), "
                    "falling back to default"
                )
                device_index = None

        try:
            self._stream = self._pa.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=SAMPLE_RATE,
                input=True,
                frames_per_buffer=self.frames_per_buffer,
                input_device_index=device_index,
            )
        except Exception as exc:
            self.log.error(f"Failed to open audio stream: {exc}")
            raise

    # ── Core detection loop ────────────────────────────────────────────────────
    def run(self) -> None:
        # Signal handling
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        if not os.environ.get("DISPLAY"):
            self.log.info("No DISPLAY detected — running in headless/audio-only mode")

        # Validate Vosk / PyAudio
        try:
            import vosk
            import pyaudio
        except ImportError as exc:
            self.log.error(f"Missing required package: {exc}. Run: pip install vosk pyaudio")
            return

        if not os.path.isdir(self.model_path):
            self.log.error(
                f"Vosk model not found: {self.model_path}\n"
                "Run install.sh to download it, or:\n"
                "  wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip\n"
                "  unzip -q vosk-model-small-en-us-0.15.zip -d models/"
            )
            return

        # Start background services
        self._hub.start()
        self._metrics_thread.start()

        # Initialise audio
        try:
            self._open_audio_stream()
        except Exception:
            self.shutdown()
            return

        # Initialise Vosk
        try:
            model = vosk.Model(self.model_path)
            recognizer = vosk.KaldiRecognizer(model, SAMPLE_RATE)
        except Exception as exc:
            self.log.error(f"Vosk recognizer init failed: {exc}")
            self.shutdown()
            return

        self.log.info(
            f"Vosk keyword spotter active — keyword='{self.keyword}', "
            f"confidence_threshold={self.min_confidence}, "
            f"cooldown={self.cooldown}s"
        )

        # ── Main loop ──────────────────────────────────────────────────────────
        try:
            while not self._stop_event.is_set():
                try:
                    data = self._stream.read(
                        self.frames_per_buffer, exception_on_overflow=False
                    )
                except Exception as exc:
                    if self._stop_event.is_set():
                        break
                    self.log.warning(f"Audio stream read error: {exc}")
                    continue

                # Accumulate audio context if enabled
                if self.send_audio_context:
                    self._audio_buffer.append(data)

                # Run Vosk
                if recognizer.AcceptWaveform(data):
                    result = json.loads(recognizer.Result())
                    final_text = result.get("text", "").lower().strip()
                    keyword_in_partial = False
                    keyword_in_final = self.keyword in final_text
                else:
                    partial = json.loads(recognizer.PartialResult())
                    partial_text = partial.get("partial", "").lower().strip()
                    keyword_in_partial = self.keyword in partial_text
                    keyword_in_final = False

                # Skip confidence / trigger logic while muted
                if self._muted:
                    continue

                # ── Confidence smoothing ─────────────────────────────────────
                if keyword_in_final:
                    self._confidence = 1.0
                elif keyword_in_partial:
                    self._confidence = min(1.0, self._confidence + _CONFIDENCE_STEP_UP)
                else:
                    self._confidence = max(
                        0.0, self._confidence - _CONFIDENCE_STEP_DOWN
                    )

                self.log.debug(
                    f"Confidence: {self._confidence:.2f} "
                    f"(partial={keyword_in_partial}, final={keyword_in_final})"
                )

                # ── Trigger ──────────────────────────────────────────────────
                if self._confidence >= self.min_confidence and (
                    keyword_in_partial or keyword_in_final
                ):
                    now = time.time()
                    if now - self._last_detection >= self.cooldown:
                        self._last_detection = now
                        self._trigger(keyword_in_final)
                        self._confidence = 0.0

        except KeyboardInterrupt:
            self.log.info("KeyboardInterrupt received")
        finally:
            self.shutdown()

    def _trigger(self, from_final: bool) -> None:
        result_type = "final" if from_final else "partial"
        self.log.info(
            f"🎤 Wake word '{self.keyword}' detected! "
            f"(confidence triggered, source={result_type})"
        )

        with self._metrics_lock:
            self._metrics["detections"] += 1
            self._metrics["last_detection"] = datetime.now().isoformat()

        payload: dict = {"type": "wake_word_detected"}

        if self.send_audio_context:
            audio_bytes = b"".join(self._audio_buffer)
            if audio_bytes:
                payload["audio_context_b64"] = base64.b64encode(audio_bytes).decode("utf-8")
                payload["audio_context_format"] = {
                    "sample_rate": SAMPLE_RATE,
                    "channels": 1,
                    "sample_width": 2,
                    "encoding": "pcm_s16le",
                }
                self._audio_buffer.clear()

        self._hub.send(payload)
        self._play_feedback()

    # ── Lifecycle ────────────────────────────────────────────────────────────
    def _signal_handler(self, signum: int, _frame) -> None:
        self.log.info(f"Received signal {signum}, initiating graceful shutdown…")
        self._stop_event.set()
        try:
            if hasattr(self, "_stream") and self._stream:
                self._stream.stop_stream()
        except Exception:
            pass

    def shutdown(self) -> None:
        if self._stop_event.is_set():
            # Avoid double-shutdown
            pass
        self._stop_event.set()

        self.log.info("Shutting down wake word listener…")

        # Unblock audio read
        try:
            if hasattr(self, "_stream") and self._stream:
                self._stream.stop_stream()
                self._stream.close()
        except Exception as exc:
            self.log.debug(f"Error closing audio stream: {exc}")

        try:
            if hasattr(self, "_pa") and self._pa:
                self._pa.terminate()
        except Exception as exc:
            self.log.debug(f"Error terminating PyAudio: {exc}")

        # Stop background threads
        self._hub.stop(timeout=3.0)
        self._update_metrics()
        self._write_metrics()

        self.log.info("Wake word listener shut down cleanly")


# =============================================================================
# Entry point
# =============================================================================
def run() -> None:
    parser = _build_arg_parser()
    args = parser.parse_args()

    if args.list_devices:
        _list_devices()
        return

    listener = WakeWordListener(args)
    listener.run()


if __name__ == "__main__":
    run()
