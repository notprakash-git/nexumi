"""
src/core/tts.py

Text-to-speech engine for Nexumi.

Features
--------
- **Queued synthesis** – single background worker consumes a FIFO queue so
  overlapping ``speak()`` calls never glitch.
- **LRU disk cache** – frequently spoken phrases are keyed by
  ``hash(text+emotion+voice+prosody)`` and stored as MP3 in a temp directory.
  TTL and size limits are configurable.
- **Per-emotion prosody** – rate, volume, pitch, voice, and SSML style are
  overridable via ``settings.json``.
- **Long-text splitting** – texts longer than ``max_text_length`` are split at
  sentence boundaries, synthesised as separate chunks, and seamlessly
  concatenated into one MP3 for playback.
- **Retry with backoff** – Edge-TTS network failures retry 3× (1 s, 2 s) before
  falling back to pyttsx3.
- **Streaming synthesis** – ``synthesise_stream()`` yields raw MP3 chunks as
  they arrive from Microsoft’s servers, enabling real-time playback and
  frame-accurate lip-sync.
- **Interrupt / stop** – ``stop()`` drains the queue and aborts the current
  utterance.
- **Lip-sync WebSocket events** – broadcasts ``tts_start`` / ``tts_end`` (and
  per-chunk markers when streaming) so the 3D avatar can animate.
- **Prefetch** – ``prefetch()`` warms the cache with common phrases at startup.
- **Graceful cleanup** – all temp cache files are removed on exit
  (``atexit`` + signal handlers).

Public API
----------
``speak(text, emotion="neutral", blocking=False)``
    Enqueue an utterance. If *blocking* is ``True``, blocks until playback
    finishes.

``stop()``
    Clear the queue and abort the current utterance.

``is_speaking() -> bool``
    Return ``True`` if an utterance is currently being synthesised or played.

``prefetch(phrases, emotion="neutral")``
    Pre-generate MP3s for common phrases in the background.

``synthesise_stream(text, emotion="neutral") -> AsyncGenerator[bytes, None]``
    Yield raw MP3 audio chunks in real time (requires ``edge-tts`` ≥ 6.x).

``speak_streaming(text, emotion="neutral") -> AsyncGenerator[bytes, None]``
    Convenience wrapper around ``synthesise_stream`` that also broadcasts
    WebSocket lip-sync events.

``list_voices()``
    Utility: print all available Edge-TTS voices to stdout.

Configuration (settings.json)
-----------------------------
.. code-block:: json

    {
      "tts": {
        "default_voice": "ja-JP-NanamiNeural",
        "default_rate": "+0%",
        "default_volume": "+0%",
        "default_pitch": "+0Hz",
        "max_text_length": 5000,
        "emotions": {
          "happy":    { "style": "cheerful",      "rate": "+0%",  "styledegree": 1.5 },
          "excited":  { "style": "cheerful",      "rate": "+12%", "styledegree": 2.0 },
          "flirty":   { "style": "affectionate",  "rate": "+0%",  "styledegree": 1.5 },
          "sad":      { "style": "sad",           "rate": "-8%",  "styledegree": 1.5 },
          "angry":    { "style": "angry",         "rate": "+6%",  "styledegree": 1.5 },
          "sleepy":   { "style": "gentle",        "rate": "-12%", "styledegree": 1.5 },
          "neutral":  { "style": null,            "rate": "+0%" }
        },
        "cache": {
          "enabled": true,
          "max_size": 100,
          "ttl_seconds": 3600,
          "directory": null
        },
        "fallback": {
          "enabled": true,
          "engine": "pyttsx3",
          "rate": 165,
          "volume": 0.85
        },
        "websocket": {
          "enabled": true
        }
      }
    }

Optional dependencies
---------------------
- ``edge-tts`` – primary Microsoft Edge TTS engine (required).
- ``pyttsx3`` – offline fallback when Edge TTS fails.
- ``pydub`` – used to cleanly concatenate multi-chunk MP3s. If missing,
  falls back to binary concatenation (works for Edge-TTS MP3s).
- ``websockets`` – only needed if the WebSocket hub is used for lip-sync.
"""

import asyncio
import atexit
import hashlib
import os
import queue
import re
import signal
import sys
import tempfile
import threading
import time
import xml.sax.saxutils as saxutils
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncGenerator, Callable, Dict, List, Optional, Tuple

from src.utils.logger import get_logger
from src.utils.settings import load_settings

# ── Audio player imports (best-effort) ───────────────────────────────────────
try:
    from src.utils.audio_player import play as audio_play, stop as audio_stop
except ImportError:
    try:
        from src.utils.audio_player import play as audio_play
    except ImportError:
        audio_play = None  # type: ignore[assignment]
    audio_stop = None  # type: ignore[assignment,misc]

# ── WebSocket hub (optional, for lip-sync) ───────────────────────────────────
try:
    from src.ui.websocket_server import get_websocket_hub
except ImportError:
    class _WebSocketHubStub:
        def broadcast(self, payload: Dict[str, Any]) -> None:
            pass

    _ws_hub_stub = _WebSocketHubStub()

    def get_websocket_hub() -> _WebSocketHubStub:  # type: ignore[misc]
        return _ws_hub_stub

log = get_logger("tts")

# ── Settings ─────────────────────────────────────────────────────────────────
_SETTINGS = load_settings().get("tts", {})

# ── Defaults ─────────────────────────────────────────────────────────────────
DEFAULT_VOICE = _SETTINGS.get("default_voice", "ja-JP-NanamiNeural")
DEFAULT_RATE = _SETTINGS.get("default_rate", "+0%")
DEFAULT_VOLUME = _SETTINGS.get("default_volume", "+0%")
DEFAULT_PITCH = _SETTINGS.get("default_pitch", "+0Hz")
MAX_TEXT_LENGTH = _SETTINGS.get("max_text_length", 5000)

# Cache config
_CACHE_CFG = _SETTINGS.get("cache", {})
CACHE_ENABLED = _CACHE_CFG.get("enabled", True)
CACHE_MAX_SIZE = _CACHE_CFG.get("max_size", 100)
CACHE_TTL = _CACHE_CFG.get("ttl_seconds", 3600)
_CACHE_DIR = _CACHE_CFG.get("directory")
if _CACHE_DIR:
    CACHE_DIR = Path(_CACHE_DIR).expanduser()
else:
    CACHE_DIR = Path(tempfile.gettempdir()) / "nexumi_tts_cache"

# Fallback config
_FALLBACK_CFG = _SETTINGS.get("fallback", {})
FALLBACK_ENABLED = _FALLBACK_CFG.get("enabled", True)
FALLBACK_ENGINE = _FALLBACK_CFG.get("engine", "pyttsx3")
FALLBACK_RATE = _FALLBACK_CFG.get("rate", 165)
FALLBACK_VOLUME = _FALLBACK_CFG.get("volume", 0.85)

# WebSocket config
_WS_ENABLED = _SETTINGS.get("websocket", {}).get("enabled", True)

# Emotion overrides
_EMOTION_OVERRIDES: Dict[str, Dict[str, Any]] = _SETTINGS.get("emotions", {})


# =============================================================================
# Data structures
# =============================================================================
@dataclass
class TTSRequest:
    text: str
    emotion: str = "neutral"
    blocking: bool = False
    on_start: Optional[Callable[[], None]] = None
    on_end: Optional[Callable[[], None]] = None
    done_event: threading.Event = field(default_factory=threading.Event)


# =============================================================================
# TTSEngine
# =============================================================================
class TTSEngine:
    """
    Nexumi text-to-speech engine.

    A single background worker thread pulls requests from a FIFO queue,
    synthesises them (with LRU disk caching), plays them sequentially, and
    broadcasts WebSocket lip-sync events.
    """

    def __init__(self) -> None:
        self._queue: queue.Queue[TTSRequest] = queue.Queue()
        self._shutdown = threading.Event()
        self._abort = threading.Event()
        self._speaking = threading.Event()

        self._worker = threading.Thread(target=self._worker_loop, daemon=True, name="TTSWorker")
        self._worker.start()

        # Cache state
        self._cache: Dict[str, Tuple[str, float]] = {}  # key -> (path, last_access)
        self._cache_lock = threading.Lock()
        self._cache_dir = CACHE_DIR
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._load_existing_cache()

        # Cleanup
        atexit.register(self._cleanup_all)
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        # Metrics
        self._metrics_lock = threading.Lock()
        self._metrics = {
            "synthesised": 0,
            "cache_hits": 0,
            "fallbacks": 0,
            "stopped": 0,
            "retries": 0,
            "chunks": 0,
        }

    # ── Settings helpers ─────────────────────────────────────────────────────
    def _emotion_cfg(self, emotion: str) -> Dict[str, Any]:
        return _EMOTION_OVERRIDES.get(emotion, {})

    def _voice(self, emotion: str) -> str:
        return self._emotion_cfg(emotion).get("voice") or DEFAULT_VOICE

    def _rate(self, emotion: str) -> str:
        return self._emotion_cfg(emotion).get("rate") or DEFAULT_RATE

    def _volume(self, emotion: str) -> str:
        return self._emotion_cfg(emotion).get("volume") or DEFAULT_VOLUME

    def _pitch(self, emotion: str) -> str:
        return self._emotion_cfg(emotion).get("pitch") or DEFAULT_PITCH

    def _style(self, emotion: str) -> Optional[str]:
        return self._emotion_cfg(emotion).get("style")

    def _styledegree(self, emotion: str) -> float:
        return self._emotion_cfg(emotion).get("styledegree", 1.5)

    # ── Cache management ─────────────────────────────────────────────────────
    def _load_existing_cache(self) -> None:
        """Scan cache directory on startup to rebuild the in-memory index."""
        if not CACHE_ENABLED:
            return
        now = time.time()
        for f in self._cache_dir.glob("*.mp3"):
            key = f.stem
            mtime = f.stat().st_mtime
            if now - mtime > CACHE_TTL:
                try:
                    f.unlink()
                except OSError:
                    pass
            else:
                self._cache[key] = (str(f), mtime)

    def _cache_key(self, text: str, emotion: str) -> str:
        voice = self._voice(emotion)
        rate = self._rate(emotion)
        vol = self._volume(emotion)
        pitch = self._pitch(emotion)
        style = self._style(emotion) or ""
        raw = f"{text}|{emotion}|{voice}|{rate}|{vol}|{pitch}|{style}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _get_cached(self, key: str) -> Optional[str]:
        if not CACHE_ENABLED:
            return None
        with self._cache_lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            path, ts = entry
            if time.time() - ts > CACHE_TTL:
                self._remove_cache_entry(key)
                return None
            self._cache[key] = (path, time.time())
            with self._metrics_lock:
                self._metrics["cache_hits"] += 1
            return path

    def _put_cache(self, key: str, path: str) -> None:
        if not CACHE_ENABLED:
            return
        with self._cache_lock:
            while len(self._cache) >= CACHE_MAX_SIZE:
                oldest_key = min(self._cache, key=lambda k: self._cache[k][1])
                self._remove_cache_entry(oldest_key)
            self._cache[key] = (path, time.time())

    def _remove_cache_entry(self, key: str) -> None:
        entry = self._cache.pop(key, None)
        if entry:
            try:
                Path(entry[0]).unlink(missing_ok=True)
            except OSError:
                pass

    def _cleanup_all(self) -> None:
        """Remove every cached MP3 and temp file on process exit."""
        log.info("TTS cleanup: removing cache files…")
        with self._cache_lock:
            for path, _ in list(self._cache.values()):
                try:
                    Path(path).unlink(missing_ok=True)
                except OSError:
                    pass
            self._cache.clear()
        try:
            self._cache_dir.rmdir()
        except OSError:
            pass

    # ── Text splitting ───────────────────────────────────────────────────────
    @staticmethod
    def _split_text(text: str, max_length: int = MAX_TEXT_LENGTH) -> List[str]:
        """
        Split *text* at sentence boundaries so no chunk exceeds *max_length*.
        Falls back to word-boundary splitting for individual sentences that are
        still too long.
        """
        if len(text) <= max_length:
            return [text]

        sentences = re.split(r'(?<<=[.!?])\s+|\n+', text)
        chunks: List[str] = []
        current = ""

        for raw_sent in sentences:
            sent = raw_sent.strip()
            if not sent:
                continue

            # Sentence itself exceeds limit → split at word boundaries
            if len(sent) > max_length:
                if current:
                    chunks.append(current.strip())
                    current = ""
                words = sent.split()
                temp = ""
                for w in words:
                    if temp and len(temp) + 1 + len(w) > max_length:
                        chunks.append(temp.strip())
                        temp = w
                    else:
                        temp = f"{temp} {w}" if temp else w
                if temp:
                    current = temp.strip()
                continue

            # Try to append to current chunk
            projected = f"{current} {sent}" if current else sent
            if len(projected) <= max_length:
                current = projected
            else:
                if current:
                    chunks.append(current.strip())
                current = sent

        if current:
            chunks.append(current.strip())

        return chunks if chunks else [text[:max_length]]

    # ── SSML construction ────────────────────────────────────────────────────
    @staticmethod
    def _sanitize_text(text: str) -> str:
        """Remove illegal XML control characters and escape entities."""
        text = "".join(ch for ch in text if ord(ch) >= 32 or ch in "\t\n\r")
        return saxutils.escape(text)

    def _build_ssml(self, text: str, emotion: str) -> str:
        """Wrap text in SSML with per-emotion prosody and express-as style."""
        safe_text = self._sanitize_text(text)

        if len(safe_text) > MAX_TEXT_LENGTH:
            log.warning(
                f"Text length {len(safe_text)} exceeds max {MAX_TEXT_LENGTH}; "
                "it will be split into multiple chunks"
            )

        rate = self._rate(emotion)
        volume = self._volume(emotion)
        pitch = self._pitch(emotion)
        style = self._style(emotion)
        styledegree = self._styledegree(emotion)

        prosody = (
            f'<prosody rate="{rate}" volume="{volume}" pitch="{pitch}">'
            f"{safe_text}"
            f"</prosody>"
        )

        if style:
            inner = (
                f'<mstts:express-as style="{style}" styledegree="{styledegree}">'
                f"{prosody}"
                f"</mstts:express-as>"
            )
        else:
            inner = prosody

        voice = self._voice(emotion)
        ssml = (
            '<speak version="1.0" '
            'xmlns="http://www.w3.org/2001/10/synthesis" '
            'xmlns:mstts="http://www.w3.org/2001/mstts" '
            'xml:lang="en-US">'
            f'<voice name="{voice}">'
            f"{inner}"
            "</voice>"
            "</speak>"
        )
        return ssml

    # ── Synthesis (with retry) ───────────────────────────────────────────────
    async def _synthesise_async(self, text: str, emotion: str, out_path: str) -> bool:
        """Run edge-tts with exponential-backoff retry and write MP3 to *out_path*."""
        try:
            import edge_tts
        except ImportError:
            log.error("edge-tts not installed. Run: pip install edge-tts")
            return False

        ssml = self._build_ssml(text, emotion)
        voice = self._voice(emotion)
        rate = self._rate(emotion)
        volume = self._volume(emotion)
        pitch = self._pitch(emotion)

        for attempt in range(3):
            try:
                communicate = edge_tts.Communicate(
                    ssml,
                    voice=voice,
                    rate=rate,
                    volume=volume,
                    pitch=pitch,
                )
                await communicate.save(out_path)
                if os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
                    return True
                else:
                    raise RuntimeError("edge-tts produced empty file")
            except Exception as exc:
                if attempt < 2:
                    wait = 2 ** attempt  # 1 s, 2 s
                    log.warning(
                        f"edge-tts attempt {attempt + 1}/3 failed, "
                        f"retrying in {wait}s: {exc}"
                    )
                    with self._metrics_lock:
                        self._metrics["retries"] += 1
                    await asyncio.sleep(wait)
                else:
                    log.error(f"edge-tts synthesis failed after 3 attempts: {exc}")
        return False

    def _synthesise(self, text: str, emotion: str) -> Optional[str]:
        """
        Return a path to the synthesised MP3, using the cache if possible.
        Returns ``None`` on failure.
        """
        key = self._cache_key(text, emotion)
        cached = self._get_cached(key)
        if cached:
            log.debug(f"TTS cache hit for key {key[:16]}…")
            return cached

        out_path = self._cache_dir / f"{key}.mp3"
        try:
            ok = asyncio.run(self._synthesise_async(text, emotion, str(out_path)))
            if ok:
                self._put_cache(key, str(out_path))
                with self._metrics_lock:
                    self._metrics["synthesised"] += 1
                return str(out_path)
        except Exception as exc:
            log.error(f"TTS synthesis wrapper error: {exc}")

        out_path.unlink(missing_ok=True)
        return None

    # ── Streaming synthesis ──────────────────────────────────────────────────
    async def synthesise_stream(
        self, text: str, emotion: str = "neutral"
    ) -> AsyncGenerator[bytes, None]:
        """
        Yield raw MP3 audio chunks as they arrive from Edge TTS.
        Requires ``edge-tts`` ≥ 6.x (which exposes ``Communicate.stream()``).
        """
        if not text or not text.strip():
            return

        try:
            import edge_tts
        except ImportError:
            log.error("edge-tts not installed")
            return

        ssml = self._build_ssml(text, emotion)
        try:
            communicate = edge_tts.Communicate(
                ssml,
                voice=self._voice(emotion),
                rate=self._rate(emotion),
                volume=self._volume(emotion),
                pitch=self._pitch(emotion),
            )
            async for chunk in communicate.stream():
                if chunk.get("type") == "audio":
                    yield chunk["data"]
        except Exception as exc:
            log.error(f"edge-tts streaming error: {exc}")

    # ── MP3 concatenation ────────────────────────────────────────────────────
    def _concat_mp3(self, paths: List[str]) -> Optional[str]:
        """Merge multiple MP3 files into one. Returns path to combined file."""
        if len(paths) == 1:
            return paths[0]

        # Try pydub first (cleanest, handles headers correctly)
        try:
            from pydub import AudioSegment
            combined = AudioSegment.empty()
            for p in paths:
                combined += AudioSegment.from_mp3(p)
            out = tempfile.mktemp(suffix=".mp3", prefix="nexumi_tts_combined_")
            combined.export(out, format="mp3")
            return out
        except ImportError:
            pass
        except Exception as exc:
            log.warning(f"pydub concatenation failed: {exc}")

        # Fallback: binary concatenation (works for Edge-TTS CBR MP3s)
        out = tempfile.mktemp(suffix=".mp3", prefix="nexumi_tts_combined_")
        try:
            with open(out, "wb") as outfile:
                for p in paths:
                    with open(p, "rb") as infile:
                        outfile.write(infile.read())
            return out
        except Exception as exc:
            log.error(f"Binary MP3 concatenation failed: {exc}")
            return None

    # ── Fallback ─────────────────────────────────────────────────────────────
    def _fallback_speak(self, text: str) -> None:
        """Offline fallback when Edge TTS fails."""
        if not FALLBACK_ENABLED:
            return
        try:
            if FALLBACK_ENGINE == "pyttsx3":
                import pyttsx3

                engine = pyttsx3.init()
                engine.setProperty("rate", FALLBACK_RATE)
                engine.setProperty("volume", FALLBACK_VOLUME)
                engine.say(text)
                engine.runAndWait()
                log.warning("Used pyttsx3 fallback for TTS")
                with self._metrics_lock:
                    self._metrics["fallbacks"] += 1
            else:
                log.error(f"Unknown fallback engine: {FALLBACK_ENGINE}")
        except Exception as exc:
            log.error(f"TTS fallback failed: {exc}")

    # ── WebSocket lip-sync helpers ───────────────────────────────────────────
    def _broadcast(self, msg_type: str, payload: Dict[str, Any]) -> None:
        if not _WS_ENABLED:
            return
        try:
            hub = get_websocket_hub()
            hub.broadcast({"type": msg_type, **payload})
        except Exception as exc:
            log.debug(f"WebSocket broadcast failed: {exc}")

    # ── Worker loop ──────────────────────────────────────────────────────────
    def _worker_loop(self) -> None:
        while not self._shutdown.is_set():
            try:
                req = self._queue.get(timeout=0.2)
            except queue.Empty:
                continue

            self._abort.clear()

            try:
                self._process_request(req)
            except Exception as exc:
                log.error(f"TTS worker error processing request: {exc}")
            finally:
                self._queue.task_done()
                req.done_event.set()

    def _process_request(self, req: TTSRequest) -> None:
        text = req.text.strip()
        if not text:
            return

        # 1) Split long text into sentence-bounded chunks
        chunks = self._split_text(text)
        is_multi = len(chunks) > 1
        if is_multi:
            log.info(
                f"TTS [{self._voice(req.emotion)} | {req.emotion}]: "
                f"{text[:80]!r} … ({len(chunks)} chunks)"
            )
            with self._metrics_lock:
                self._metrics["chunks"] += len(chunks)
        else:
            log.info(
                f"TTS [{self._voice(req.emotion)} | {req.emotion}]: {text[:80]!r}"
            )

        # 2) Synthesise every chunk (with retry/backoff built in)
        chunk_paths: List[str] = []
        for i, chunk in enumerate(chunks):
            if self._abort.is_set():
                log.debug("TTS abort during multi-chunk synthesis")
                return
            path = self._synthesise(chunk, req.emotion)
            if path is None:
                log.warning(
                    f"Chunk {i + 1}/{len(chunks)} synthesis failed — "
                    "falling back to offline TTS"
                )
                self._fallback_speak(text)
                return
            chunk_paths.append(path)

        if self._abort.is_set():
            return

        # 3) Concatenate chunks for seamless playback
        combined_path: Optional[str] = None
        if is_multi:
            combined_path = self._concat_mp3(chunk_paths)
            if combined_path is None:
                log.error("MP3 concatenation failed — falling back")
                self._fallback_speak(text)
                return
            play_path = combined_path
        else:
            play_path = chunk_paths[0]

        # 4) Playback with lip-sync events
        self._speaking.set()
        self._broadcast(
            "tts_start",
            {"text": text, "emotion": req.emotion, "chunks": len(chunks)},
        )
        if req.on_start:
            try:
                req.on_start()
            except Exception:
                pass

        try:
            if audio_play is not None:
                audio_play(play_path)
            else:
                log.error("No audio_player.play() available — cannot play TTS")
        except Exception as exc:
            log.error(f"Audio playback error: {exc}")

        self._speaking.clear()
        self._broadcast("tts_end", {"text": text, "emotion": req.emotion})
        if req.on_end:
            try:
                req.on_end()
            except Exception:
                pass

        # 5) Cleanup combined temp file (cached chunks are left for reuse)
        if combined_path and os.path.exists(combined_path):
            try:
                os.unlink(combined_path)
            except OSError:
                pass

    # ── Public API ───────────────────────────────────────────────────────────
    def speak(self, text: str, emotion: str = "neutral", blocking: bool = False) -> None:
        """
        Enqueue *text* for synthesis and playback.

        Parameters
        ----------
        text : str
            The text to speak.
        emotion : str
            One of the configured emotion keys (default ``"neutral"``).
        blocking : bool
            If ``True``, block the caller until playback completes.
        """
        if not text or not text.strip():
            return

        req = TTSRequest(text=text, emotion=emotion, blocking=blocking)
        self._queue.put(req)

        if blocking:
            req.done_event.wait()

    def stop(self) -> None:
        """
        Clear the pending queue and abort the current utterance.
        The worker remains alive for future requests.
        """
        while True:
            try:
                self._queue.get_nowait()
                self._queue.task_done()
            except queue.Empty:
                break

        self._abort.set()

        if audio_stop is not None:
            try:
                audio_stop()
            except Exception as exc:
                log.warning(f"audio_player.stop() failed: {exc}")
        else:
            log.debug("audio_player.stop() unavailable — cannot interrupt playback")

        with self._metrics_lock:
            self._metrics["stopped"] += 1

        log.info("TTS stopped and queue cleared")

    def is_speaking(self) -> bool:
        """Return ``True`` if an utterance is currently being played."""
        return self._speaking.is_set()

    def prefetch(self, phrases: List[str], emotion: str = "neutral") -> None:
        """
        Pre-generate MP3s for *phrases* in the background so they are cached
        when ``speak()`` is called later.
        """
        if not CACHE_ENABLED:
            log.debug("Cache disabled — skipping prefetch")
            return

        def _prefetch_one(text: str) -> None:
            key = self._cache_key(text, emotion)
            if self._get_cached(key):
                return
            self._synthesise(text, emotion)

        for phrase in phrases:
            t = threading.Thread(
                target=_prefetch_one, args=(phrase,), daemon=True, name="TTSPrefetch"
            )
            t.start()

    def get_metrics(self) -> Dict[str, int]:
        """Return a snapshot of internal metrics."""
        with self._metrics_lock:
            return dict(self._metrics)

    # ── Lifecycle ────────────────────────────────────────────────────────────
    def _signal_handler(self, signum: int, _frame: Any) -> None:
        log.info(f"TTS received signal {signum}, shutting down…")
        self._shutdown.set()
        self.stop()
        self._cleanup_all()
        sys.exit(0)

    def shutdown(self) -> None:
        """Permanently stop the worker and clean up resources."""
        self._shutdown.set()
        self.stop()
        self._worker.join(timeout=3.0)
        self._cleanup_all()


# =============================================================================
# Module-level singleton
# =============================================================================
_engine: Optional[TTSEngine] = None


def _get_engine() -> TTSEngine:
    global _engine
    if _engine is None:
        _engine = TTSEngine()
    return _engine


def speak(text: str, emotion: str = "neutral", blocking: bool = False) -> None:
    """Synthesise and speak *text* with the given *emotion*."""
    _get_engine().speak(text, emotion, blocking)


def stop() -> None:
    """Stop the current utterance and clear the queue."""
    _get_engine().stop()


def is_speaking() -> bool:
    """Return ``True`` if Nexumi is currently speaking."""
    return _get_engine().is_speaking()


def prefetch(phrases: List[str], emotion: str = "neutral") -> None:
    """Pre-generate cache entries for common phrases."""
    _get_engine().prefetch(phrases, emotion)


def get_metrics() -> Dict[str, int]:
    """Return TTS metrics snapshot."""
    return _get_engine().get_metrics()


async def synthesise_stream(
    text: str, emotion: str = "neutral"
) -> AsyncGenerator[bytes, None]:
    """
    Yield raw MP3 audio chunks as they arrive from Edge TTS.
    This is a low-level API; the caller handles playback.
    """
    engine = _get_engine()
    async for chunk in engine.synthesise_stream(text, emotion):
        yield chunk


async def speak_streaming(
    text: str, emotion: str = "neutral"
) -> AsyncGenerator[bytes, None]:
    """
    High-level streaming helper that yields audio chunks and broadcasts
    WebSocket lip-sync events (``tts_start`` / ``tts_end``).
    """
    if not text or not text.strip():
        return
    engine = _get_engine()
    engine._speaking.set()
    engine._broadcast(
        "tts_start", {"text": text, "emotion": emotion, "streaming": True}
    )
    try:
        async for chunk in engine.synthesise_stream(text, emotion):
            yield chunk
    finally:
        engine._speaking.clear()
        engine._broadcast(
            "tts_end", {"text": text, "emotion": emotion, "streaming": True}
        )


def list_voices() -> None:
    """
    Utility: print all available edge-tts voices to stdout.
    Run directly: python -c "from src.core.tts import list_voices; list_voices()"
    """
    async def _list() -> None:
        try:
            import edge_tts
            voices = await edge_tts.list_voices()
            for v in voices:
                print(
                    f"{v['ShortName']:45s}  {v['Locale']:10s}  "
                    f"{v.get('Gender', '?'):7s}  {v.get('FriendlyName', '')}"
                )
        except ImportError:
            print("edge-tts not installed. Run: pip install edge-tts")

    asyncio.run(_list())


# =============================================================================
# Backward-compatible re-exports
# =============================================================================
__all__ = [
    "speak",
    "stop",
    "is_speaking",
    "prefetch",
    "get_metrics",
    "synthesise_stream",
    "speak_streaming",
    "list_voices",
    "TTSEngine",
    "TTSRequest",
]
