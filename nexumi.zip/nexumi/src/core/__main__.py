"""
src/core/__main__.py

Unified test harness for Nexumi core modules.
Run individual components in standalone mode for quick debugging and CI smoke‑tests.

Usage
-----
    python -m src.core                    # Default: interactive STT loop
    python -m src.core --mode stt         # Speech‑to‑text microphone test
    python -m src.core --mode brain       # Interactive text chat with the brain
    python -m src.core --mode wakeword    # Start the wake‑word listener
    python -m src.core --mode emotion     # Interactive emotion selector test
    python -m src.core --mode chat        # Full pipeline: STT → Brain → Emotion
    python -m src.core --config           # Dump merged settings.json and exit
    python -m src.core --debug            # Enable DEBUG level logging
"""

import argparse
import json
import os
import signal
import sys
import time
from pathlib import Path

# ── Ensure project root is on path ───────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("core.test_harness")
_settings = load_settings()


# =============================================================================
# ANSI helpers for pretty terminal output
# =============================================================================
class _Term:
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    BOLD = "\033[1m"
    RESET = "\033[0m"

    @classmethod
    def ok(cls, text: str) -> str:
        return f"{cls.GREEN}{text}{cls.RESET}"

    @classmethod
    def info(cls, text: str) -> str:
        return f"{cls.CYAN}{text}{cls.RESET}"

    @classmethod
    def warn(cls, text: str) -> str:
        return f"{cls.YELLOW}{text}{cls.RESET}"

    @classmethod
    def err(cls, text: str) -> str:
        return f"{cls.RED}{text}{cls.RESET}"

    @classmethod
    def bold(cls, text: str) -> str:
        return f"{cls.BOLD}{text}{cls.RESET}"


def _supports_color() -> bool:
    return sys.stdout.isatty() and os.environ.get("TERM") not in ("dumb", None)


if not _supports_color():
    for attr in dir(_Term):
        if not attr.startswith("_"):
            setattr(_Term, attr, lambda self, text: text)  # type: ignore


# =============================================================================
# CLI
# =============================================================================
def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m src.core",
        description="Nexumi core module test harness",
    )
    parser.add_argument(
        "--mode",
        choices=["stt", "brain", "wakeword", "emotion", "chat"],
        default="stt",
        help="Component to exercise (default: stt)",
    )
    parser.add_argument(
        "--config", action="store_true", help="Print loaded settings and exit"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable DEBUG logging"
    )
    parser.add_argument(
        "--max-turns",
        type=int,
        default=0,
        help="Max conversation turns for brain/chat modes (0 = unlimited)",
    )
    return parser


# =============================================================================
# Config dumper
# =============================================================================
def _dump_config() -> None:
    print(_Term.bold("─" * 50))
    print(_Term.bold("Loaded settings.json (merged with defaults)"))
    print(_Term.bold("─" * 50))
    print(json.dumps(_settings, indent=2, default=str))
    print(_Term.bold("─" * 50))


# =============================================================================
# Dependency checker
# =============================================================================
def _check_deps(mode: str) -> bool:
    """Return True if all expected packages for *mode* are importable."""
    required: dict[str, list[str]] = {
        "stt": ["speech_recognition", "pyaudio"],
        "brain": ["openai"],
        "wakeword": ["vosk", "pyaudio"],
        "emotion": [],
        "chat": ["speech_recognition", "pyaudio", "openai"],
    }
    missing: list[str] = []
    for pkg in required.get(mode, []):
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        log.error(
            f"Missing dependencies for --mode={mode}: {', '.join(missing)}\n"
            "Install them via: pip install -r requirements.txt"
        )
        return False
    return True


# =============================================================================
# Mode: STT
# =============================================================================
def _mode_stt(max_turns: int = 0) -> None:
    from src.core.stt import listen_once

    print(_Term.info("🎤  STT test mode — speak into your microphone"))
    print(_Term.warn("   Ctrl+C to exit\n"))

    turn = 0
    try:
        while True:
            if max_turns and turn >= max_turns:
                print(_Term.warn(f"Reached --max-turns={max_turns}, exiting."))
                break
            turn += 1

            print(_Term.bold("Listening…"), end=" ", flush=True)
            t0 = time.perf_counter()
            result = listen_once()
            elapsed = time.perf_counter() - t0

            if result:
                print(
                    f"\r{_Term.ok('✔')}  {_Term.bold(result!r)} "
                    f"({elapsed:.2f}s)"
                )
            else:
                print(
                    f"\r{_Term.warn('✘')}  (nothing heard) "
                    f"({elapsed:.2f}s)"
                )
    except KeyboardInterrupt:
        print(f"\n{_Term.warn('STT test stopped by user')}")


# =============================================================================
# Mode: Brain
# =============================================================================
def _mode_brain(max_turns: int = 0) -> None:
    from src.core.brain import get_brain

    brain = get_brain()
    if not brain.is_ready():
        print(
            _Term.err("Brain is not ready — check your OPENROUTER_API_KEY "
                      "and internet connection.")
        )
        return

    print(_Term.info("🧠  Brain test mode — type a message and press Enter"))
    print(_Term.warn("   Empty input or 'quit' to exit\n"))

    turn = 0
    try:
        while True:
            if max_turns and turn >= max_turns:
                print(_Term.warn(f"Reached --max-turns={max_turns}, exiting."))
                break
            turn += 1

            user_text = input(_Term.bold("You: ")).strip()
            if not user_text or user_text.lower() in ("quit", "exit", "q"):
                break

            t0 = time.perf_counter()
            reply = brain.respond(user_text)
            elapsed = time.perf_counter() - t0

            print(f"{_Term.info('Nexumi:')} {reply}")
            print(f"       {_Term.warn(f'({elapsed:.2f}s)')}\n")
    except (KeyboardInterrupt, EOFError):
        print(f"\n{_Term.warn('Brain test stopped by user')}")


# =============================================================================
# Mode: WakeWord
# =============================================================================
def _mode_wakeword() -> None:
    from src.core.wakeword import WakeWordListener, _build_arg_parser

    # Re-use wakeword's own CLI defaults but force headless test mode
    print(_Term.info("👂  Wake-word test mode"))
    print(_Term.warn("   Press Ctrl+C to stop\n"))

    # Build a dummy namespace so WakeWordListener can instantiate
    class _DummyArgs:
        keyword = None
        model = None
        device_index = None
        no_feedback = False
        log_level = "INFO"
        list_devices = False

    listener = WakeWordListener(_DummyArgs())
    try:
        listener.run()
    except KeyboardInterrupt:
        listener.shutdown()


# =============================================================================
# Mode: Emotion
# =============================================================================
def _mode_emotion(max_turns: int = 0) -> None:
    try:
        from src.integration.emotion_selector import select_emotion
    except ImportError:
        print(
            _Term.err(
                "emotion_selector not found. "
                "Create src/integration/emotion_selector.py or check your path."
            )
        )
        return

    print(_Term.info("😊  Emotion selector test mode"))
    print(_Term.warn("   Enter 'user_input | ai_response' pairs, or 'quit'\n"))

    turn = 0
    try:
        while True:
            if max_turns and turn >= max_turns:
                print(_Term.warn(f"Reached --max-turns={max_turns}, exiting."))
                break
            turn += 1

            raw = input(_Term.bold("Pair: ")).strip()
            if not raw or raw.lower() in ("quit", "exit", "q"):
                break

            if "|" not in raw:
                print(_Term.warn("   Format: hello there | Hi! How can I help?"))
                continue

            user_input, ai_response = raw.split("|", 1)
            emotion = select_emotion(user_input.strip(), ai_response.strip())
            print(f"   → Emotion: {_Term.ok(emotion)}\n")
    except (KeyboardInterrupt, EOFError):
        print(f"\n{_Term.warn('Emotion test stopped by user')}")


# =============================================================================
# Mode: Chat (full pipeline)
# =============================================================================
def _mode_chat(max_turns: int = 0) -> None:
    from src.core.stt import listen_once
    from src.core.brain import get_brain

    brain = get_brain()
    if not brain.is_ready():
        print(_Term.err("Brain not ready — aborting chat test."))
        return

    print(_Term.info("💬  Full pipeline test: STT → Brain → Emotion"))
    print(_Term.warn("   Speak after the beep (or Ctrl+C to exit)\n"))

    turn = 0
    try:
        while True:
            if max_turns and turn >= max_turns:
                print(_Term.warn(f"Reached --max-turns={max_turns}, exiting."))
                break
            turn += 1

            print(_Term.bold("🎤 Listening…"))
            user_text = listen_once()
            if not user_text:
                print(_Term.warn("(nothing heard — try again)\n"))
                continue

            print(f"{_Term.info('You:')} {user_text}")

            t0 = time.perf_counter()
            reply = brain.respond(user_text)
            elapsed = time.perf_counter() - t0

            print(f"{_Term.info('Nexumi:')} {reply}")
            print(f"       {_Term.warn(f'({elapsed:.2f}s)')}\n")
    except KeyboardInterrupt:
        print(f"\n{_Term.warn('Chat test stopped by user')}")


# =============================================================================
# Entry point
# =============================================================================
def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.debug:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)
        log.debug("DEBUG logging enabled")

    if args.config:
        _dump_config()
        return

    # Graceful SIGINT handling for all modes
    def _sigint_handler(signum, frame):
        print(f"\n{_Term.warn('Interrupted — shutting down…')}")
        sys.exit(0)

    signal.signal(signal.SIGINT, _sigint_handler)

    if not _check_deps(args.mode):
        sys.exit(1)

    # Dispatch
    dispatch = {
        "stt": _mode_stt,
        "brain": _mode_brain,
        "wakeword": _mode_wakeword,
        "emotion": _mode_emotion,
        "chat": _mode_chat,
    }
    fn = dispatch[args.mode]
    fn(max_turns=args.max_turns)


if __name__ == "__main__":
    main()
