"""
src/core/dispatcher.py

Intent dispatcher for Nexumi.

Routes classified intents from the router to the appropriate tool module,
or falls back to the AI brain for general chat and unsupported intents.

All tool functions are assumed to be synchronous and return a human-readable
string suitable for TTS and chat display.
"""

from typing import Any

from src.tools import desktop_control as dc
from src.tools import desktop
from src.tools import screenshot
from src.tools import websearch
from src.core.brain import get_brain
from src.utils.logger import get_logger
from src.utils.router import extract_all_params, route

log = get_logger("dispatcher")

# -----------------------------------------------------------------------------
# Brain singleton (lazy initialisation to avoid import-time side effects)
# -----------------------------------------------------------------------------
_brain_instance: Any | None = None


def _get_brain() -> Any:
    """Return the cached brain instance, creating it on first call."""
    global _brain_instance
    if _brain_instance is None:
        _brain_instance = get_brain()
    return _brain_instance


# -----------------------------------------------------------------------------
# Parameter helpers
# -----------------------------------------------------------------------------
def _require_str(params: dict[str, Any], key: str) -> str | None:
    """
    Safely fetch a string parameter.
    Returns the stripped value if present and non-empty, otherwise None.
    """
    value = params.get(key)
    if isinstance(value, str):
        value = value.strip()
    return value if value else None


# -----------------------------------------------------------------------------
# Public API
# -----------------------------------------------------------------------------
def dispatch(user_input: str) -> str:
    """
    Route user input to the appropriate tool or AI brain.

    Args:
        user_input: Raw text from the user (STT or chat panel).

    Returns:
        A human-readable response string ready for TTS and chat display.
    """
    if not isinstance(user_input, str) or not user_input.strip():
        log.warning("dispatch() received empty input")
        return "I didn't catch that. Could you say it again?"

    try:
        intent, confidence = route(user_input)
        params = extract_all_params(user_input, intent)

        # Sanitise log entry (exclude raw utterance to keep logs concise)
        log.info(
            "intent=%s confidence=%.2f params=%s",
            intent,
            confidence,
            {k: v for k, v in params.items() if k != "raw"},
        )

        # =====================================================================
        # 1. Application & Package Management
        # =====================================================================
        if intent == "app_launch":
            app = _require_str(params, "query")
            if not app:
                return "What application should I open?"
            return dc.launch_app(app)

        elif intent == "app_install":
            pkg = _require_str(params, "query")
            if not pkg:
                return "What package would you like me to install?"
            return dc.install_package(pkg)

        elif intent == "app_uninstall":
            pkg = _require_str(params, "query")
            if not pkg:
                return "What package should I uninstall?"
            return dc.uninstall_package(pkg)

        elif intent == "package_search":
            query = _require_str(params, "query")
            if not query:
                return "What package should I search for?"
            return dc.search_package(query)

        # =====================================================================
        # 2. File Operations
        # =====================================================================
        elif intent == "file_list":
            path = _require_str(params, "path") or _require_str(params, "query")
            if not path:
                return "Which directory should I list?"
            return dc.list_directory(path)

        elif intent == "file_delete":
            path = _require_str(params, "path") or _require_str(params, "query")
            if not path:
                return "What file or folder should I delete?"
            return dc.delete_file(path)

        elif intent == "file_copy":
            src = _require_str(params, "src")
            dest = _require_str(params, "dest")
            if not src or not dest:
                return "I need both a source and a destination to copy. Could you specify both?"
            return dc.copy_file(src, dest)

        elif intent == "file_move":
            src = _require_str(params, "src")
            dest = _require_str(params, "dest")
            if not src or not dest:
                return "I need both a source and a destination to move. Could you specify both?"
            return dc.move_file(src, dest)

        elif intent == "file_info":
            path = _require_str(params, "path") or _require_str(params, "query")
            if not path:
                return "What file should I get information about?"
            return dc.get_file_info(path)

        # =====================================================================
        # 3. Process Management
        # =====================================================================
        elif intent == "process_list":
            filter_str = params.get("query", "")
            if not isinstance(filter_str, str):
                filter_str = ""
            return dc.list_processes(filter_str=filter_str.strip())

        elif intent == "process_kill":
            target = _require_str(params, "query")
            if not target:
                return "Which process should I stop? Give me the name or PID."
            return dc.kill_process(target)

        # =====================================================================
        # 4. System Information
        # =====================================================================
        elif intent == "system_info":
            return dc.get_system_info()

        # =====================================================================
        # 5. Web Search
        # =====================================================================
        elif intent == "search":
            query = _require_str(params, "query")
            if not query:
                return "What should I search for?"
            return websearch.search(query)

        # =====================================================================
        # 6. Screenshot
        # =====================================================================
        elif intent == "screenshot":
            return screenshot.capture()

        # =====================================================================
        # 7. Desktop Automation (legacy basic controls)
        # =====================================================================
        elif intent == "desktop_click":
            target = _require_str(params, "query")
            if not target:
                return "What should I click on?"
            return desktop.click(target)

        elif intent == "desktop_type":
            text = _require_str(params, "query")
            if not text:
                return "What should I type?"
            return desktop.type_text(text)

        elif intent == "desktop_scroll":
            direction = params.get("query", "down")
            if not isinstance(direction, str):
                direction = "down"
            return desktop.scroll(direction.strip().lower())

        elif intent == "desktop_move":
            # extract_drag_coords returns {"from": (x, y), "to": (x, y)} merged into params
            from_coords = params.get("from")
            to_coords = params.get("to")
            if isinstance(from_coords, (list, tuple)) and isinstance(to_coords, (list, tuple)):
                return desktop.drag(from_coords, to_coords)
            # Fallback for simple mouse-move intents without drag coordinates
            x_val = params.get("x")
            y_val = params.get("y")
            if x_val is not None and y_val is not None:
                return desktop.move_mouse(int(x_val), int(y_val))
            return "I need coordinates to move the mouse. Where should I move it?"

        elif intent == "desktop_press":
            key = _require_str(params, "query")
            if not key:
                return "Which key should I press?"
            return desktop.press(key)

        # =====================================================================
        # 8. Memory
        # =====================================================================
        elif intent == "memory_store":
            fact = _require_str(params, "query")
            if not fact:
                return "What should I remember?"
            brain = _get_brain()
            brain.remember_fact(fact)
            return "Got it. I'll remember that."

        elif intent == "memory_query":
            brain = _get_brain()
            facts = brain.recall_facts()
            if facts:
                return f"Here's what I remember: {facts}"
            return "I don't have any memories stored yet."

        # =====================================================================
        # 9. Weather / Time / Date (no dedicated API → forward to brain)
        # =====================================================================
        elif intent in ("weather", "time", "date"):
            brain = _get_brain()
            return brain.respond(user_input)

        # =====================================================================
        # 10. Default: General Chat
        # =====================================================================
        else:
            brain = _get_brain()
            return brain.respond(user_input)

    except Exception as exc:
        log.error("dispatch failed for input=%r: %s", user_input, exc, exc_info=True)
        return "Sorry, something went wrong while handling that request. Please try again."
