"""
src/tools/screenshot.py

Screen capture using mss with PIL fallback.

Key design decisions
--------------------
- mss is used for speed (pure Python, no PIL dependency).
- Screenshots are saved to a rotating directory with timestamps.
- Old screenshots are auto-cleaned after a configurable retention period.
- Region capture supports both mss and PIL for maximum compatibility.
- A simple grid overlay can be added for debug / UI reference purposes.
- If mss is unavailable, a PIL-based fallback is attempted.
- Vision API integration is prepared but gracefully degrades to metadata
  when the integration module is not present.
"""

import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("screenshot")

_cfg = load_settings()
_shot_cfg = _cfg.get("screenshot", {})

# Resolve path via pathlib
SCREENSHOTS_DIR = Path(__file__).resolve().parent.parent.parent / _shot_cfg.get(
    "dir", "data/screenshots"
)
RETENTION_DAYS = int(_shot_cfg.get("retention_days", 7))


def _ensure_dir() -> Path:
    """Create the screenshots directory if it doesn't exist."""
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    return SCREENSHOTS_DIR


def _cleanup_old() -> None:
    """Remove screenshots older than RETENTION_DAYS."""
    cutoff = datetime.now() - timedelta(days=RETENTION_DAYS)
    try:
        for f in SCREENSHOTS_DIR.glob("shot_*.png"):
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            if mtime < cutoff:
                f.unlink()
                log.debug("Cleaned old screenshot: %s", f.name)
    except Exception as exc:
        log.warning("Screenshot cleanup error: %s", exc)


# =============================================================================
# Capture
# =============================================================================
def capture(monitor: int = 1) -> str:
    """
    Capture the specified monitor and save to the screenshots directory.
    Returns the absolute path to the saved image, or "" on failure.
    """
    _ensure_dir()
    _cleanup_old()

    timestamp = int(time.time())
    filename = SCREENSHOTS_DIR / f"shot_{timestamp}.png"

    # Attempt 1: mss (fast, no PIL)
    try:
        import mss
        import mss.tools
        with mss.mss() as sct:
            mon = sct.monitors[monitor]
            img = sct.grab(mon)
            mss.tools.to_png(img.rgb, img.size, output=str(filename))
        log.info("Screenshot saved (mss): %s", filename)
        return str(filename)
    except ImportError:
        log.debug("mss not installed — trying PIL fallback")
    except Exception as exc:
        log.error("mss screenshot error: %s", exc)

    # Attempt 2: PIL / Pillow fallback
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab()
        img.save(filename)
        log.info("Screenshot saved (PIL): %s", filename)
        return str(filename)
    except ImportError:
        log.error("Neither mss nor Pillow is installed — screenshot unavailable")
    except Exception as exc:
        log.error("PIL screenshot error: %s", exc)

    return ""


def capture_region(
    left: int, top: int, width: int, height: int
) -> str:
    """
    Capture a specific screen region.
    Returns the absolute path to the saved image, or "" on failure.
    """
    _ensure_dir()
    timestamp = int(time.time())
    filename = SCREENSHOTS_DIR / f"shot_region_{timestamp}.png"

    # Attempt 1: mss
    try:
        import mss
        with mss.mss() as sct:
            region = {"left": left, "top": top, "width": width, "height": height}
            img = sct.grab(region)
            mss.tools.to_png(img.rgb, img.size, output=str(filename))
        log.info("Region screenshot saved (mss): %s", filename)
        return str(filename)
    except ImportError:
        log.debug("mss not installed — trying PIL fallback for region")
    except Exception as exc:
        log.error("mss region screenshot error: %s", exc)

    # Attempt 2: PIL
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab(bbox=(left, top, left + width, top + height))
        img.save(filename)
        log.info("Region screenshot saved (PIL): %s", filename)
        return str(filename)
    except ImportError:
        log.error("Neither mss nor Pillow is installed — region screenshot unavailable")
    except Exception as exc:
        log.error("PIL region screenshot error: %s", exc)

    return ""


def capture_window(title: str) -> str:
    """
    Capture a specific window by title (X11 via xdotool, falls back to active window).
    Returns the absolute path to the saved image, or "" on failure.
    """
    _ensure_dir()
    timestamp = int(time.time())
    filename = SCREENSHOTS_DIR / f"shot_window_{timestamp}.png"

    # Try to focus the window first via xdotool
    try:
        import subprocess
        result = subprocess.run(
            ["xdotool", "search", "--name", title],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            wid = result.stdout.strip().split("\n")[0]
            subprocess.run(
                ["xdotool", "windowactivate", "--sync", wid],
                timeout=5,
            )
            time.sleep(0.2)
    except Exception as exc:
        log.debug("xdotool window focus failed: %s", exc)

    # Capture using mss or PIL
    try:
        import mss
        with mss.mss() as sct:
            mon = sct.monitors[1]  # primary monitor
            img = sct.grab(mon)
            mss.tools.to_png(img.rgb, img.size, output=str(filename))
        log.info("Window screenshot saved: %s", filename)
        return str(filename)
    except ImportError:
        pass
    except Exception as exc:
        log.error("Window screenshot error: %s", exc)

    try:
        from PIL import ImageGrab
        img = ImageGrab.grab()
        img.save(filename)
        log.info("Window screenshot saved (PIL): %s", filename)
        return str(filename)
    except Exception as exc:
        log.error("Window screenshot PIL error: %s", exc)

    return ""


# =============================================================================
# Describe / metadata
# =============================================================================
def describe(image_path: str) -> str:
    """
    Return a description of the screenshot.
    If a vision API is configured, it will be used; otherwise a basic
    metadata summary is returned.
    """
    path = Path(image_path)
    if not path.is_file():
        return "No screenshot available."

    size = path.stat().st_size
    dims = ""
    try:
        from PIL import Image
        with Image.open(path) as img:
            dims = f" ({img.width}x{img.height})"
    except Exception:
        pass

    # Attempt vision API if configured
    vision_api = _cfg.get("vision", {}).get("provider", "")
    if vision_api:
        try:
            from src.integration.vision import describe_image
            return describe_image(path)
        except ImportError:
            log.debug("Vision module not available — returning metadata")
        except Exception as exc:
            log.warning("Vision API failed: %s", exc)

    return (
        f"Screenshot saved ({size // 1024} KB{dims}). "
        "Vision description requires a multimodal API key."
    )


def list_screenshots(limit: int = 10) -> list[dict]:
    """Return a list of recent screenshot metadata for the UI."""
    _ensure_dir()
    files = sorted(
        SCREENSHOTS_DIR.glob("shot_*.png"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )[:limit]
    return [
        {
            "name": f.name,
            "path": str(f),
            "size_kb": f.stat().st_size // 1024,
            "timestamp": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
        }
        for f in files
    ]


def ocr(image_path: str, *, lang: str = "eng") -> str:
    """
    Extract text from an image using pytesseract (if installed).
    Returns the extracted text, or an empty string if OCR is unavailable.
    """
    try:
        import pytesseract
        from PIL import Image
        img = Image.open(image_path)
        text = pytesseract.image_to_string(img, lang=lang)
        log.info("OCR extracted %d characters from %s", len(text), image_path)
        return text.strip()
    except ImportError:
        log.debug("pytesseract not installed — OCR unavailable")
        return ""
    except Exception as exc:
        log.error("OCR error: %s", exc)
        return ""


def ocr_region(left: int, top: int, width: int, height: int, *, lang: str = "eng") -> str:
    """
    Capture a region and immediately OCR it.
    Returns the extracted text, or an empty string on failure.
    """
    path = capture_region(left, top, width, height)
    if not path:
        return ""
    return ocr(path, lang=lang)

