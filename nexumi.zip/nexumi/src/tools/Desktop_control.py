"""
src/tools/desktop_control.py

Advanced system control for Nexumi:
- Launch applications
- Install / uninstall packages (pacman, yay)
- File operations (list, delete, copy, move, create dir, info)
- Process management (list, kill)
- System information (RAM, CPU, disk, uptime)

All destructive operations require user confirmation.
"""

import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional, Tuple, Union

try:
    import psutil
except ImportError:
    psutil = None

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("desktop_control")

# ---------------------------------------------------------------------------
# Load configuration
# ---------------------------------------------------------------------------
_cfg = load_settings()
_dc_cfg = _cfg.get("desktop_control", {})

SAFE_MODE: bool = _dc_cfg.get("safe_mode", True)
CONFIRM_TIMEOUT: int = int(_dc_cfg.get("confirm_timeout_sec", 30))
DEFAULT_DIR: Path = Path(_dc_cfg.get("default_directory", str(Path.home())))
PACMAN_CMD: str = _dc_cfg.get("pacman_command", "sudo pacman")
YAY_CMD: str = _dc_cfg.get("yay_command", "yay")
ALLOW_DESTRUCTIVE: bool = _dc_cfg.get("allow_destructive", True)
LOG_OPS: bool = _dc_cfg.get("log_operations", True)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _confirm_action(action_description: str, timeout: int = CONFIRM_TIMEOUT) -> bool:
    """
    Ask the user for confirmation before destructive actions.
    Returns True if confirmed, False otherwise.
    """
    if not SAFE_MODE:
        return True
    if not ALLOW_DESTRUCTIVE:
        log.warning("Destructive action blocked: allow_destructive is false.")
        return False

    print(f"\n⚠️  {action_description}")
    print(f"   Confirm? (y/n) [timeout {timeout}s]: ", end="", flush=True)

    # Cross-platform input with timeout
    try:
        if sys.platform == "win32":
            import msvcrt
            start = time.time()
            while time.time() - start < timeout:
                if msvcrt.kbhit():
                    answer = msvcrt.getche().decode().strip().lower()
                    print()
                    return answer in ("y", "yes", "yeah", "yep", "sure")
                time.sleep(0.1)
            print("\n   Timeout – operation cancelled.")
            return False
        else:
            import select
            ready, _, _ = select.select([sys.stdin], [], [], timeout)
            if ready:
                answer = sys.stdin.readline().strip().lower()
                return answer in ("y", "yes", "yeah", "yep", "sure")
            else:
                print("\n   Timeout – operation cancelled.")
                return False
    except Exception as e:
        log.error(f"Confirmation prompt error: {e}")
        return False


def _log_operation(op: str, details: str) -> None:
    """Log operation if logging is enabled."""
    if LOG_OPS:
        log.info(f"[DESKTOP_CTRL] {op}: {details}")


def _resolve_path(path: Union[str, Path]) -> Path:
    """Resolve a path string to an absolute Path, expanding ~ and environment vars."""
    if path is None:
        return DEFAULT_DIR
    p = Path(os.path.expandvars(str(path))).expanduser()
    if not p.is_absolute():
        p = DEFAULT_DIR / p
    return p.resolve()


def _check_psutil() -> None:
    """Ensure psutil is available."""
    if psutil is None:
        raise RuntimeError("psutil is required but not installed. Run: pip install psutil")


# ---------------------------------------------------------------------------
# Application & package management
# ---------------------------------------------------------------------------

_APP_MAP = {
    "brave": "brave-browser",
    "firefox": "firefox",
    "chrome": "google-chrome-stable",
    "chromium": "chromium",
    "code": "code",
    "vscode": "code",
    "terminal": "xterm",
    "files": "thunar",
    "file manager": "thunar",
    "discord": "discord",
    "spotify": "spotify",
    "obs": "obs",
    "gimp": "gimp",
    "inkscape": "inkscape",
    "vlc": "vlc",
    "steam": "steam",
}


def launch_app(app_name: str) -> str:
    """Launch a GUI application by name."""
    cmd = _APP_MAP.get(app_name.lower(), app_name)

    try:
        # Use start_new_session to detach from Nexumi's process group
        subprocess.Popen(
            [cmd],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
        _log_operation("launch_app", f"Launched {app_name} (cmd={cmd})")
        return f"Launching {app_name}!"
    except FileNotFoundError:
        log.warning(f"Application not found: {cmd}")
        return f"Could not find {app_name}. Is it installed?"
    except Exception as e:
        log.error(f"launch_app error: {e}")
        return f"Failed to launch {app_name}: {e}"


def install_package(package: str) -> str:
    """Install a package using pacman or yay."""
    if not _confirm_action(f"Install package '{package}'?"):
        return "Installation cancelled."

    # Detect if yay is available for AUR support
    use_yay = False
    try:
        subprocess.run([YAY_CMD, "--version"], capture_output=True, check=True)
        use_yay = True
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass

    cmd = (
        [YAY_CMD, "-S", "--noconfirm", package]
        if use_yay
        else [*PACMAN_CMD.split(), "-S", "--noconfirm", package]
    )

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode == 0:
            _log_operation("install", f"Installed {package}")
            return f"Successfully installed {package}."
        else:
            error = result.stderr[:300] if result.stderr else result.stdout[:300]
            return f"Failed to install {package}: {error}"
    except subprocess.TimeoutExpired:
        return f"Installation of {package} timed out after 5 minutes."
    except Exception as e:
        log.error(f"install_package error: {e}")
        return f"Error installing {package}: {e}"


def uninstall_package(package: str) -> str:
    """Remove a package using pacman."""
    if not _confirm_action(f"Uninstall package '{package}'?"):
        return "Uninstallation cancelled."

    cmd = [*PACMAN_CMD.split(), "-Rns", "--noconfirm", package]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode == 0:
            _log_operation("uninstall", f"Removed {package}")
            return f"Successfully uninstalled {package}."
        else:
            error = result.stderr[:300] if result.stderr else "Unknown error"
            return f"Failed to uninstall {package}: {error}"
    except Exception as e:
        log.error(f"uninstall_package error: {e}")
        return f"Error uninstalling {package}: {e}"


def search_package(query: str) -> str:
    """Search for a package in the repositories."""
    cmd = [*PACMAN_CMD.split(), "-Ss", query]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode == 0 and result.stdout:
            lines = result.stdout.strip().split("\n")[:15]
            return "Found:\n" + "\n".join(lines)
        else:
            return f"No packages found matching '{query}'."
    except Exception as e:
        log.error(f"search_package error: {e}")
        return f"Search failed: {e}"


# ---------------------------------------------------------------------------
# File operations
# ---------------------------------------------------------------------------

def list_directory(path: Optional[str] = None, pattern: str = "*", max_items: int = 20) -> str:
    """List files/directories in a given path."""
    target = _resolve_path(path)
    if not target.exists():
        return f"Directory not found: {target}"
    if not target.is_dir():
        return f"Path is not a directory: {target}"

    try:
        items = sorted(target.glob(pattern))
        items = items[:max_items]
        if not items:
            return f"No items found in {target}."

        lines = []
        for item in items:
            icon = "📁" if item.is_dir() else "📄"
            size = ""
            if item.is_file():
                size_bytes = item.stat().st_size
                size = f" ({size_bytes:,} bytes)" if size_bytes < 1024**2 else f" ({size_bytes / 1024**2:.1f} MB)"
            lines.append(f"{icon} {item.name}{size}")

        header = f"Found {len(items)} items in {target}:"
        return header + "\n" + "\n".join(lines)
    except PermissionError:
        return f"Permission denied: {target}"
    except Exception as e:
        log.error(f"list_directory error: {e}")
        return f"Error listing directory: {e}"


def delete_file(path: str) -> str:
    """Delete a file or directory (destructive, requires confirmation)."""
    target = _resolve_path(path)
    if not target.exists():
        return f"File/directory not found: {target}"

    if target == Path.home() or target == Path("/"):
        return "Refusing to delete critical system path. Operation blocked."

    if not _confirm_action(f"Delete '{target}' permanently?"):
        return "Deletion cancelled."

    try:
        if target.is_file() or target.is_symlink():
            target.unlink()
        elif target.is_dir():
            shutil.rmtree(target)
        else:
            return f"Unknown file type for: {target}"
        _log_operation("delete", f"Deleted {target}")
        return f"Deleted {target}."
    except PermissionError:
        return f"Permission denied deleting: {target}"
    except Exception as e:
        log.error(f"delete_file error: {e}")
        return f"Failed to delete: {e}"


def copy_file(src: str, dest: str, overwrite: bool = False) -> str:
    """Copy a file or directory."""
    src_path = _resolve_path(src)
    dest_path = _resolve_path(dest)

    if not src_path.exists():
        return f"Source not found: {src_path}"

    if dest_path.exists() and not overwrite:
        if not _confirm_action(f"Overwrite existing '{dest_path}'?"):
            return "Copy cancelled."
        overwrite = True

    try:
        if src_path.is_file() or src_path.is_symlink():
            if dest_path.is_dir():
                dest_path = dest_path / src_path.name
            shutil.copy2(src_path, dest_path)
        elif src_path.is_dir():
            if dest_path.exists() and overwrite:
                shutil.copytree(src_path, dest_path, dirs_exist_ok=True)
            else:
                shutil.copytree(src_path, dest_path)
        else:
            return f"Unknown file type for source: {src_path}"

        _log_operation("copy", f"Copied {src_path} -> {dest_path}")
        return f"Copied to {dest_path}."
    except PermissionError:
        return f"Permission denied during copy."
    except Exception as e:
        log.error(f"copy_file error: {e}")
        return f"Copy failed: {e}"


def move_file(src: str, dest: str) -> str:
    """Move or rename a file/directory."""
    src_path = _resolve_path(src)
    dest_path = _resolve_path(dest)

    if not src_path.exists():
        return f"Source not found: {src_path}"

    if dest_path.exists():
        if not _confirm_action(f"Destination '{dest_path}' exists. Replace?"):
            return "Move cancelled."
        try:
            if dest_path.is_file() or dest_path.is_symlink():
                dest_path.unlink()
            elif dest_path.is_dir():
                shutil.rmtree(dest_path)
        except Exception as e:
            return f"Could not remove existing destination: {e}"

    try:
        # Ensure parent directory exists
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src_path), str(dest_path))
        _log_operation("move", f"Moved {src_path} -> {dest_path}")
        return f"Moved to {dest_path}."
    except PermissionError:
        return f"Permission denied during move."
    except Exception as e:
        log.error(f"move_file error: {e}")
        return f"Move failed: {e}"


def create_directory(path: str, parents: bool = True) -> str:
    """Create a new directory."""
    target = _resolve_path(path)
    try:
        target.mkdir(parents=parents, exist_ok=False)
        _log_operation("mkdir", f"Created {target}")
        return f"Directory created: {target}."
    except FileExistsError:
        return f"Directory already exists: {target}"
    except PermissionError:
        return f"Permission denied: cannot create {target}"
    except Exception as e:
        log.error(f"create_directory error: {e}")
        return f"Failed to create directory: {e}"


def get_file_info(path: str) -> str:
    """Return file/directory metadata."""
    target = _resolve_path(path)
    if not target.exists():
        return f"Path not found: {target}"

    try:
        stat = target.stat()
        info_lines = [
            f"Name: {target.name}",
            f"Full path: {target}",
            f"Type: {'Directory' if target.is_dir() else 'Symbolic Link' if target.is_symlink() else 'File'}",
            f"Size: {stat.st_size:,} bytes ({stat.st_size / 1024:.1f} KB)",
            f"Modified: {time.ctime(stat.st_mtime)}",
            f"Accessed: {time.ctime(stat.st_atime)}",
            f"Permissions: {oct(stat.st_mode)[-3:]}",
        ]
        return "\n".join(info_lines)
    except PermissionError:
        return f"Permission denied reading info for: {target}"
    except Exception as e:
        log.error(f"get_file_info error: {e}")
        return f"Error reading info: {e}"


# ---------------------------------------------------------------------------
# Process management
# ---------------------------------------------------------------------------

def list_processes(filter_str: str = "", limit: int = 10) -> str:
    """List running processes (name, PID, CPU%, memory%)."""
    _check_psutil()

    processes = []
    for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
        try:
            pinfo = proc.info
            if filter_str and filter_str.lower() not in pinfo["name"].lower():
                continue
            processes.append(pinfo)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    processes.sort(key=lambda p: p.get("cpu_percent", 0) or 0, reverse=True)
    processes = processes[:limit]

    if not processes:
        return "No matching processes found."

    lines = [
        f"{p['name']} (PID {p['pid']}) — CPU {p.get('cpu_percent', 0):.1f}% / MEM {p.get('memory_percent', 0):.1f}%"
        for p in processes
    ]
    return "\n".join(lines)


def kill_process(target: str) -> str:
    """
    Kill process by PID or by name (kills all matching names).
    Requires confirmation.
    """
    _check_psutil()

    # Try as PID first
    if target.isdigit():
        pid = int(target)
        try:
            proc = psutil.Process(pid)
            proc_name = proc.name()
            if not _confirm_action(f"Kill process {proc_name} (PID {pid})?"):
                return "Kill cancelled."
            proc.terminate()
            gone, alive = psutil.wait_procs([proc], timeout=5)
            if alive:
                for p in alive:
                    p.kill()
                return f"Force-killed {proc_name} (PID {pid})."
            _log_operation("kill", f"Terminated PID {pid} ({proc_name})")
            return f"Terminated {proc_name} (PID {pid})."
        except psutil.NoSuchProcess:
            return f"No process with PID {pid}."
        except psutil.AccessDenied:
            return f"Access denied killing PID {pid}. Try with elevated privileges."
        except Exception as e:
            log.error(f"kill_process (PID) error: {e}")
            return f"Failed to kill PID {pid}: {e}"
    else:
        # Kill by name
        killed = []
        skipped = []
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["name"].lower() == target.lower():
                    if _confirm_action(f"Kill process {proc.info['name']} (PID {proc.info['pid']})?"):
                        proc.terminate()
                        try:
                            proc.wait(timeout=3)
                        except psutil.TimeoutExpired:
                            proc.kill()
                        killed.append(proc.info["pid"])
                        _log_operation("kill", f"Terminated {proc.info['name']} PID {proc.info['pid']}")
                    else:
                        skipped.append(proc.info["pid"])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if killed:
            return f"Terminated {len(killed)} process(es) matching '{target}'."
        elif skipped:
            return f"Skipped {len(skipped)} process(es) matching '{target}' (user declined)."
        else:
            return f"No running process named '{target}' found."


# ---------------------------------------------------------------------------
# System information
# ---------------------------------------------------------------------------

def get_system_info() -> str:
    """Return CPU, RAM, disk, and uptime info."""
    _check_psutil()

    try:
        cpu = psutil.cpu_percent(interval=0.5)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        uptime_seconds = time.time() - psutil.boot_time()

        hours, remainder = divmod(int(uptime_seconds), 3600)
        minutes, seconds = divmod(remainder, 60)
        uptime_str = f"{hours}h {minutes}m {seconds}s"

        return (
            f"CPU Usage: {cpu}%\n"
            f"RAM: {ram.percent}% used ({ram.used // (1024**3)} / {ram.total // (1024**3)} GB)\n"
            f"Disk (/): {disk.percent}% used ({disk.free // (1024**3)} GB free of {disk.total // (1024**3)} GB)\n"
            f"Uptime: {uptime_str}"
        )
    except Exception as e:
        log.error(f"get_system_info error: {e}")
        return f"Could not retrieve system info: {e}"


# ---------------------------------------------------------------------------
# Testing entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=== Nexumi Desktop Control Test ===")
    print(get_system_info())
    print("\n--- Directory Listing ---")
    print(list_directory(str(Path.home()), max_items=5))
