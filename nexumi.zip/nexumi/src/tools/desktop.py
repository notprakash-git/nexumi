"""
src/tools/desktop.py

Desktop control tools using PyAutoGUI and xdotool.

Key design decisions
--------------------
- All PyAutoGUI calls are guarded by a runtime import check.
- xdotool is preferred on X11 for window/text-based actions; pyautogui
  is the fallback for coordinate-based actions.
- Every action returns a user-friendly string for TTS/chat display.
- Mouse and keyboard actions use small delays to avoid race conditions
  with window managers.
- Screenshots are taken before and after actions for debug logging (optional).
- get_mouse_position() returns current cursor coordinates for UI feedback.
- screenshot_region() delegates to screenshot.capture_region() for consistency.
"""

import re
import subprocess
import time
from pathlib import Path
from typing import Optional, Tuple

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("desktop")

_cfg = load_settings()
_desktop_cfg = _cfg.get("desktop", {})
CLICK_DELAY = float(_desktop_cfg.get("click_delay", 0.05))
TYPE_INTERVAL = float(_desktop_cfg.get("type_interval", 0.01))
SCROLL_AMOUNT = int(_desktop_cfg.get("scroll_amount", 3))

# Lazy import guard
try:
    import pyautogui
    pyautogui.FAILSAFE = True  # Move mouse to corner to abort
    _PYAUTO_OK = True
except ImportError:
    log.error("pyautogui not installed — desktop control unavailable")
    _PYAUTO_OK = False


def _check() -> bool:
    """Return True if pyautogui is available."""
    if not _PYAUTO_OK:
        log.error("pyautogui not available")
        return False
    return True


def _run_xdotool(args: list[str], timeout: float = 5.0) -> tuple[bool, str]:
    """Run an xdotool command and return (success, output_or_error)."""
    try:
        result = subprocess.run(
            ["xdotool", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            return True, result.stdout.strip()
        return False, result.stderr.strip()
    except FileNotFoundError:
        return False, "xdotool not installed"
    except subprocess.TimeoutExpired:
        return False, "xdotool timed out"
    except Exception as exc:
        return False, str(exc)


def _get_active_window_title() -> str:
    """Return the title of the currently focused window (X11 only)."""
    ok, out = _run_xdotool(["getactivewindow", "getwindowname"])
    return out if ok else ""


# =============================================================================
# Mouse position
# =============================================================================
def get_mouse_position() -> Tuple[int, int]:
    """Return the current mouse cursor coordinates (x, y)."""
    if not _check():
        return (0, 0)
    try:
        pos = pyautogui.position()
        log.debug("Mouse position: (%d, %d)", pos.x, pos.y)
        return (pos.x, pos.y)
    except Exception as exc:
        log.error("get_mouse_position error: %s", exc)
        return (0, 0)


def move_to(x: int, y: int, *, duration: float = 0.25) -> str:
    """Move the mouse cursor to the specified coordinates."""
    if not _check():
        return "Desktop control unavailable."
    try:
        pyautogui.moveTo(x, y, duration=duration)
        log.info("Moved mouse to (%d, %d)", x, y)
        return f"Mouse moved to ({x}, {y})."
    except Exception as exc:
        log.error("move_to error: %s", exc)
        return f"Couldn't move mouse: {exc}"


# =============================================================================
# Mouse actions
# =============================================================================
def click(x: int, y: int, *, button: str = "left", clicks: int = 1) -> str:
    """Click at screen coordinates."""
    if not _check():
        return "Desktop control unavailable."
    try:
        pyautogui.click(x, y, button=button, clicks=clicks)
        log.info("Clicked %s at (%d, %d)", button, x, y)
        return f"Clicked at ({x}, {y})."
    except Exception as exc:
        log.error("click error: %s", exc)
        return f"Couldn't click there: {exc}"


def click_text(target: str, *, partial_match: bool = True) -> str:
    """
    Try to find a UI element by window title and click/focus it.
    Uses xdotool on X11; falls back to pyautogui locate if available.
    """
    target = target.strip()
    if not target:
        return "No target specified."

    # Attempt 1: xdotool window search
    search_flag = "--name" if partial_match else "--classname"
    ok, out = _run_xdotool(["search", search_flag, target])
    if ok and out:
        wids = out.splitlines()
        for wid in wids:
            _run_xdotool(["windowactivate", "--sync", wid])
            time.sleep(CLICK_DELAY)
            _run_xdotool(["click", "1"])
            log.info("Clicked window '%s' (id=%s) via xdotool", target, wid)
            return f"Found and clicked '{target}'."

    # Attempt 2: pyautogui image locate (if the user has reference images)
    if _check():
        try:
            ref_dir = Path(__file__).resolve().parent.parent.parent / "data" / "desktop_refs"
            ref_img = ref_dir / f"{target}.png"
            if ref_img.is_file():
                loc = pyautogui.locateCenterOnScreen(str(ref_img), confidence=0.8)
                if loc:
                    pyautogui.click(loc.x, loc.y)
                    log.info("Clicked '%s' via image reference", target)
                    return f"Found and clicked '{target}' on screen."
        except Exception as exc:
            log.debug("pyautogui locate fallback failed: %s", exc)

    log.warning("Could not find '%s' on screen", target)
    return f"Could not find '{target}' on screen."


def scroll(amount: Optional[int] = None, *, direction: Optional[str] = None) -> str:
    """
    Scroll the mouse wheel.
    `amount` is in clicks (positive = up, negative = down).
    `direction` can be "up" or "down" as an alternative.
    """
    if not _check():
        return "Desktop control unavailable."

    if amount is None:
        if direction == "up":
            amount = SCROLL_AMOUNT
        elif direction == "down":
            amount = -SCROLL_AMOUNT
        else:
            amount = SCROLL_AMOUNT

    try:
        pyautogui.scroll(amount)
        dir_str = "up" if amount > 0 else "down"
        log.info("Scrolled %s by %d", dir_str, abs(amount))
        return f"Scrolled {dir_str}."
    except Exception as exc:
        log.error("scroll error: %s", exc)
        return f"Couldn't scroll: {exc}"


# =============================================================================
# Drag
# =============================================================================
def drag(start_x: int, start_y: int, end_x: int, end_y: int, *, duration: float = 0.5, button: str = "left") -> str:
    """
    Drag the mouse from (start_x, start_y) to (end_x, end_y).
    `duration` controls the speed of the drag (seconds).
    """
    if not _check():
        return "Desktop control unavailable."
    try:
        pyautogui.moveTo(start_x, start_y, duration=0.1)
        pyautogui.dragTo(end_x, end_y, duration=duration, button=button)
        log.info("Dragged %s from (%d, %d) to (%d, %d) in %.1fs", button, start_x, start_y, end_x, end_y, duration)
        return f"Dragged from ({start_x}, {start_y}) to ({end_x}, {end_y})."
    except Exception as exc:
        log.error("drag error: %s", exc)
        return f"Couldn't drag: {exc}"


# =============================================================================
# Keyboard actions
# =============================================================================
def type_text(text: str, interval: Optional[float] = None) -> str:
    """Type text at the current cursor position."""
    if not _check():
        return "Desktop control unavailable."
    try:
        pyautogui.typewrite(text, interval=interval if interval is not None else TYPE_INTERVAL)
        log.info("Typed: %r", text[:50])
        return "Text typed successfully."
    except Exception as exc:
        log.error("type_text error: %s", exc)
        return f"Couldn't type: {exc}"


def press_key(key: str, *, presses: int = 1) -> str:
    """Press a special key (e.g., 'enter', 'tab', 'esc', 'ctrl+c')."""
    if not _check():
        return "Desktop control unavailable."
    try:
        if "+" in key:
            parts = [p.strip() for p in key.split("+")]
            pyautogui.hotkey(*parts)
        else:
            pyautogui.press(key, presses=presses)
        log.info("Pressed key: %r", key)
        return f"Pressed {key}."
    except Exception as exc:
        log.error("press_key error: %s", exc)
        return f"Couldn't press {key}: {exc}"


# =============================================================================
# Window / application actions
# =============================================================================
def open_app(app_name: str) -> str:
    """Try to launch an application by name."""
    app_name_lower = app_name.lower().strip()
    if not app_name_lower:
        return "No application name provided."

    # Expandable app map — reads from settings.json if present
    app_map: dict[str, str] = _desktop_cfg.get("app_map", {})
    common_apps = {
        "firefox": "firefox",
        "chrome": "google-chrome-stable",
        "chromium": "chromium",
        "terminal": "xterm",
        "files": "thunar",
        "file manager": "thunar",
        "text editor": "gedit",
        "calculator": "gnome-calculator",
        "code": "code",
        "vscode": "code",
        "discord": "discord",
        "spotify": "spotify",
        "steam": "steam",
        **app_map,
    }
    cmd = common_apps.get(app_name_lower, app_name_lower)

    # Try xdg-open for URLs / files first
    if re.match(r"^https?://", app_name_lower):
        try:
            subprocess.Popen(
                ["xdg-open", app_name_lower],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            log.info("Opened URL via xdg-open: %s", app_name_lower)
            return f"Opening {app_name}!"
        except Exception as exc:
            log.warning("xdg-open failed: %s", exc)

    try:
        subprocess.Popen(
            [cmd],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log.info("Launched: %s", cmd)
        return f"Opening {app_name}!"
    except FileNotFoundError:
        log.warning("App not found: %s", cmd)
        return f"Hmm, I couldn't find '{app_name}'. Is it installed?"
    except Exception as exc:
        log.error("open_app error: %s", exc)
        return f"Failed to open {app_name}: {exc}"


def focus_window(title: str) -> str:
    """Focus a window by title (X11 via xdotool)."""
    ok, out = _run_xdotool(["search", "--name", title])
    if not ok or not out:
        return f"Could not find a window titled '{title}'."
    wid = out.splitlines()[0]
    _run_xdotool(["windowactivate", "--sync", wid])
    log.info("Focused window '%s' (id=%s)", title, wid)
    return f"Focused '{title}'."


def minimize_window() -> str:
    """Minimize the active window (X11)."""
    ok, out = _run_xdotool(["getactivewindow"])
    if not ok:
        return "Could not identify the active window."
    _run_xdotool(["windowminimize", out])
    log.info("Minimized active window")
    return "Minimized the active window."


def close_window() -> str:
    """Close the active window (X11 Alt+F4 equivalent via xdotool)."""
    ok, out = _run_xdotool(["getactivewindow"])
    if not ok:
        return "Could not identify the active window."
    _run_xdotool(["windowclose", out])
    log.info("Closed active window")
    return "Closed the active window."
