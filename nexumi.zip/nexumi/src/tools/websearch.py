"""
src/tools/websearch.py

Web search using DuckDuckGo HTML scraping with robust fallback chain.

Key design decisions
--------------------
- Primary: DuckDuckGo HTML endpoint (no API key needed).
- Fallback 1: Brave Search API (higher quality, requires key).
- Fallback 2: SearXNG instance (privacy meta-search, self-hostable).
- All network calls use a shared requests Session with retries and timeouts.
- HTML parsing is resilient — missing elements don't crash the scraper.
- Results are cached in-memory for 5 minutes to avoid redundant requests.
- TTS-friendly formatting: concise, numbered, with domain-only URLs.
- DDG instant answers for quick factual queries (e.g. "what is 2+2").
- Exponential backoff on 403/429 errors to handle temporary blocks.
"""

import random
import re
import time
from typing import Dict, List, Optional
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("websearch")

_cfg = load_settings()
_search_cfg = _cfg.get("websearch", {})

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/122.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Accept-Encoding": "gzip, deflate",
    "DNT": "1",
    "Connection": "keep-alive",
}
DDG_URL = "https://html.duckduckgo.com/html/"
DDG_API_URL = "https://api.duckduckgo.com/"
BRAVE_API_URL = "https://api.search.brave.com/res/v1/web/search"

# In-memory cache: query -> (timestamp, results)
_CACHE: dict[str, tuple[float, List[Dict[str, str]]]] = {}
_CACHE_TTL = float(_search_cfg.get("cache_ttl_sec", 300))
_MAX_RESULTS = int(_search_cfg.get("max_results", 3))
_TIMEOUT = int(_search_cfg.get("timeout_sec", 10))
_MAX_RETRIES = int(_search_cfg.get("max_retries", 3))

_session = requests.Session()
_session.headers.update(HEADERS)


def _get_cache(query: str) -> Optional[List[Dict[str, str]]]:
    """Return cached results if still fresh."""
    entry = _CACHE.get(query)
    if entry is None:
        return None
    ts, results = entry
    if time.monotonic() - ts > _CACHE_TTL:
        del _CACHE[query]
        return None
    log.debug("Cache hit for query: %r", query)
    return results


def _set_cache(query: str, results: List[Dict[str, str]]) -> None:
    _CACHE[query] = (time.monotonic(), results)


def _extract_domain(url: str) -> str:
    """Return a clean domain string for display."""
    try:
        parsed = urlparse(url)
        netloc = parsed.netloc
        if netloc.startswith("www."):
            netloc = netloc[4:]
        return netloc
    except Exception:
        return url[:40]


def _retry_request(
    method: str,
    url: str,
    **kwargs
) -> requests.Response:
    """Make a request with exponential backoff on 403/429/5xx."""
    for attempt in range(_MAX_RETRIES):
        try:
            resp = _session.request(method, url, timeout=_TIMEOUT, **kwargs)
            if resp.status_code in (403, 429, 502, 503, 504):
                wait = (2 ** attempt) + random.uniform(0, 1)
                log.warning("Rate limit / error %d, retrying in %.1fs", resp.status_code, wait)
                time.sleep(wait)
                continue
            resp.raise_for_status()
            return resp
        except requests.RequestException as exc:
            if attempt == _MAX_RETRIES - 1:
                raise
            wait = (2 ** attempt) + random.uniform(0, 1)
            log.warning("Request error, retrying in %.1fs: %s", wait, exc)
            time.sleep(wait)
    raise requests.RequestException(f"Failed after {_MAX_RETRIES} retries")


# =============================================================================
# DuckDuckGo scraper
# =============================================================================
def _search_ddg(query: str, max_results: int) -> List[Dict[str, str]]:
    """Scrape DuckDuckGo HTML results."""
    log.info("Searching DuckDuckGo: %r", query)
    results: List[Dict[str, str]] = []
    try:
        resp = _retry_request(
            "POST",
            DDG_URL,
            data={"q": query, "b": "", "kl": "us-en"},
        )
        soup = BeautifulSoup(resp.text, "lxml")

        for result in soup.select(".result")[:max_results]:
            title_el = result.select_one(".result__title a")
            snippet_el = result.select_one(".result__snippet")
            url_el = result.select_one(".result__url")

            if not title_el:
                continue

            raw_url = url_el.get_text(strip=True) if url_el else ""
            if raw_url.startswith("/"):
                raw_url = f"https://duckduckgo.com{raw_url}"

            results.append({
                "title": title_el.get_text(strip=True),
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
                "url": raw_url,
                "domain": _extract_domain(raw_url),
                "source": "ddg",
            })
    except requests.RequestException as exc:
        log.error("DDG search request failed: %s", exc)
    except Exception as exc:
        log.error("DDG search parse error: %s", exc)

    log.info("DDG found %d results", len(results))
    return results


# =============================================================================
# DuckDuckGo Instant Answer
# =============================================================================
def _search_ddg_instant(query: str) -> Optional[str]:
    """Get DuckDuckGo instant answer (e.g. 'what is the capital of France')."""
    try:
        resp = _retry_request(
            "GET",
            DDG_API_URL,
            params={"q": query, "format": "json", "no_html": 1, "no_redirect": 1},
        )
        data = resp.json()
        answer = data.get("AbstractText", "")
        if answer:
            log.info("DDG instant answer: %r", answer[:80])
            return answer
    except Exception as exc:
        log.debug("DDG instant answer failed: %s", exc)
    return None


# =============================================================================
# Brave Search API
# =============================================================================
def _search_brave(query: str, max_results: int) -> List[Dict[str, str]]:
    """Search via Brave Search API (requires API key)."""
    api_key = _cfg.get("api_keys", {}).get("brave_search")
    if not api_key:
        log.debug("Brave Search API key not configured")
        return []

    log.info("Searching Brave: %r", query)
    results: List[Dict[str, str]] = []
    try:
        resp = _retry_request(
            "GET",
            BRAVE_API_URL,
            headers={"X-Subscription-Token": api_key},
            params={"q": query, "count": max_results, "offset": 0},
        )
        data = resp.json()
        for item in data.get("web", {}).get("results", [])[:max_results]:
            results.append({
                "title": item.get("title", ""),
                "snippet": item.get("description", ""),
                "url": item.get("url", ""),
                "domain": _extract_domain(item.get("url", "")),
                "source": "brave",
            })
    except requests.RequestException as exc:
        log.error("Brave search request failed: %s", exc)
    except Exception as exc:
        log.error("Brave search parse error: %s", exc)

    log.info("Brave found %d results", len(results))
    return results


# =============================================================================
# SearXNG fallback
# =============================================================================
def _search_searxng(query: str, max_results: int) -> List[Dict[str, str]]:
    """Search via configured SearXNG instance (self-hostable meta-search)."""
    instance = _search_cfg.get("searxng_instance", "")
    if not instance:
        return []

    log.info("Searching SearXNG: %r", query)
    results: List[Dict[str, str]] = []
    try:
        resp = _retry_request(
            "GET",
            f"{instance.rstrip('/')}/search",
            params={"q": query, "format": "json", "language": "en"},
        )
        data = resp.json()
        for item in data.get("results", [])[:max_results]:
            results.append({
                "title": item.get("title", ""),
                "snippet": item.get("content", ""),
                "url": item.get("url", ""),
                "domain": _extract_domain(item.get("url", "")),
                "source": "searxng",
            })
    except requests.RequestException as exc:
        log.error("SearXNG search request failed: %s", exc)
    except Exception as exc:
        log.error("SearXNG search parse error: %s", exc)

    log.info("SearXNG found %d results", len(results))
    return results


# =============================================================================
# Public API
# =============================================================================
def search(query: str, max_results: Optional[int] = None) -> List[Dict[str, str]]:
    """
    Search the web and return a list of {title, snippet, url, domain, source} dicts.
    Uses DuckDuckGo by default; falls back to Brave API or SearXNG if configured.
    Results are cached for 5 minutes.
    """
    if not query or not query.strip():
        return []

    query = query.strip()
    limit = max_results if max_results is not None else _MAX_RESULTS

    # Check cache
    cached = _get_cache(query)
    if cached is not None:
        return cached[:limit]

    # Try instant answer first for quick factual queries
    instant = _search_ddg_instant(query)
    if instant:
        results = [{
            "title": "Instant Answer",
            "snippet": instant,
            "url": "",
            "domain": "duckduckgo.com",
            "source": "ddg_instant",
        }]
        _set_cache(query, results)
        return results[:limit]

    # Primary: DuckDuckGo
    results = _search_ddg(query, limit)

    # Fallback 1: Brave if DDG returned nothing and key is present
    if not results:
        results = _search_brave(query, limit)

    # Fallback 2: SearXNG if still nothing
    if not results:
        results = _search_searxng(query, limit)

    _set_cache(query, results)
    return results[:limit]


def format_results(results: List[Dict[str, str]], *, verbose: bool = False) -> str:
    """
    Format search results into a human-readable string for TTS/chat.
    `verbose=True` includes full URLs; default uses domain-only for brevity.
    """
    if not results:
        return "I couldn't find anything on that. Maybe try different keywords?"

    lines = []
    for i, r in enumerate(results, 1):
        title = r.get("title", "Untitled")
        snippet = r.get("snippet", "")
        url = r.get("url", "") if verbose else r.get("domain", "")
        lines.append(f"{i}. {title}: {snippet} ({url})")

    return " | ".join(lines)


def quick_answer(query: str) -> str:
    """
    Attempt to get a DuckDuckGo instant answer (e.g. 'what is the capital of France').
    Returns "" if no instant answer is available.
    """
    answer = _search_ddg_instant(query)
    return answer or ""
