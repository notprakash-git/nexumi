"""
src/integration/expression_mapper.py

Maps Nexumi emotion names to VRM blend shapes with smooth transitions,
priority stacking, configurable emotion mapping, and optional WebSocket
integration.

Public API
----------
``get_blend_shapes(emotion) -> Dict[str, float]``
    Backward-compatible. Returns the **target** blend shapes for *emotion*
    (no transition interpolation). Use ``get_current_blend_shapes()`` for
    the actively interpolated values.

``set_expression(emotion, duration=0.5, priority=1, curve="linear")``
    Request a transition to *emotion*. Higher-priority expressions override
    lower-priority ones. When the high-priority expression expires, the
    mapper reverts to the next highest pending expression (or neutral).

``reset_to_neutral(duration=0.2, priority=0)``
    Convenience shortcut.

``get_current_blend_shapes() -> Dict[str, float]``
    Poll this from the 3D render loop to get the interpolated blend-shape
    weights for the current frame.

``get_current_expression() -> str``
    Returns the currently active emotion name.

``is_animating() -> bool``
    ``True`` if a transition is still in progress.

``update(delta_time)``
    Advance the animation system by *delta_time* seconds. Call this from
    the render loop (or a background thread if you prefer). If using
    ``auto_update=True`` (default), a background thread handles this.

``preload()``
    Eagerly load all expression JSONs and the emotion mapping config.

``validate_expressions() -> List[str]``
    Check every JSON file for malformed data and return a list of issues.

Configuration (settings.json)
-----------------------------
.. code-block:: json

    {
      "expression_mapper": {
        "expressions_dir": "assets/3d_model/expressions",
        "emotion_mapping_file": "assets/3d_model/expressions/emotion_mapping.json",
        "default_neutral_shapes": {
          "happy": 0.0, "sad": 0.0, "anger": 0.0, "joy": 0.0,
          "eye_close": 0.0, "mouth_smile": 0.0
        },
        "auto_update": true,
        "update_rate_hz": 60,
        "websocket": {
          "enabled": true
        },
        "metrics": {
          "enabled": true,
          "path": "logs/expression_metrics.jsonl"
        }
      }
    }

``emotion_mapping.json`` (optional)
-----------------------------------
.. code-block:: json

    {
      "happy":    ["joy", "mouth_smile"],
      "sad":      ["sorrow", "mouth_frown"],
      "excited":  ["joy", "mouth_smile", "eye_wide"],
      "angry":    ["anger", "brow_down"],
      "flirty":   ["joy", "mouth_smile", "eye_blink_left"],
      "sleepy":   ["eye_close", "mouth_frown"],
      "neutral":  []
    }

WebSocket commands
------------------
Incoming
    ``{"type": "set_expression", "emotion": "happy", "duration": 0.5, "priority": 2}``

Outgoing
    ``{"type": "expression_changed", "emotion": "happy", "priority": 2}``
"""

from __future__ import annotations

import json
import math
import os
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Tuple

from src.utils.logger import get_logger
from src.utils.settings import load_settings

# ── WebSocket hub (optional) ───────────────────────────────────────────────
try:
    from src.ui.websocket_server import get_websocket_hub
except ImportError:
    class _WebSocketHubStub:
        def broadcast(self, payload: Dict[str, Any]) -> None:
            pass

    _ws_hub_stub = _WebSocketHubStub()

    def get_websocket_hub() -> _WebSocketHubStub:  # type: ignore[misc]
        return _ws_hub_stub

log = get_logger("expression_mapper")

# ── Settings ─────────────────────────────────────────────────────────────────
_CFG = load_settings().get("expression_mapper", {})

EXPRESSIONS_DIR = Path(__file__).resolve().parents[2] / _CFG.get(
    "expressions_dir", "assets/3d_model/expressions"
)
MAPPING_FILE = Path(__file__).resolve().parents[2] / _CFG.get(
    "emotion_mapping_file", "assets/3d_model/expressions/emotion_mapping.json"
)

_DEFAULT_NEUTRAL = _CFG.get(
    "default_neutral_shapes",
    {
        "happy": 0.0,
        "sad": 0.0,
        "anger": 0.0,
        "joy": 0.0,
        "eye_close": 0.0,
        "mouth_smile": 0.0,
    },
)

_AUTO_UPDATE = _CFG.get("auto_update", True)
_UPDATE_RATE_HZ = _CFG.get("update_rate_hz", 60)
_UPDATE_INTERVAL = 1.0 / _UPDATE_RATE_HZ

_WS_ENABLED = _CFG.get("websocket", {}).get("enabled", True)

_METRICS_ENABLED = _CFG.get("metrics", {}).get("enabled", True)
_METRICS_PATH = _CFG.get("metrics", {}).get("path", "logs/expression_metrics.jsonl")


# =============================================================================
# Animation curves
# =============================================================================
def _ease_linear(t: float) -> float:
    return t


def _ease_in_out(t: float) -> float:
    return t * t * (3.0 - 2.0 * t)  # smoothstep


def _ease_in(t: float) -> float:
    return t * t


def _ease_out(t: float) -> float:
    return 1.0 - (1.0 - t) * (1.0 - t)


_CURVES: Dict[str, Callable[[float], float]] = {
    "linear": _ease_linear,
    "ease_in_out": _ease_in_out,
    "ease_in": _ease_in,
    "ease_out": _ease_out,
}


# =============================================================================
# Metrics
# =============================================================================
class ExpressionMetrics:
    def __init__(self, enabled: bool, path: str, max_bytes: int = 5 * 1024 * 1024):
        self.enabled = enabled
        self.path = Path(path)
        self.max_bytes = max_bytes
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, record: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        with self._lock:
            if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                self._rotate()
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")

    def _rotate(self) -> None:
        for i in range(2, 0, -1):
            old = self.path.with_suffix(f".jsonl.{i}")
            new = self.path.with_suffix(f".jsonl.{i + 1}")
            if old.exists():
                old.rename(new)
        if self.path.exists():
            self.path.rename(self.path.with_suffix(".jsonl.1"))


# =============================================================================
# Data structures
# =============================================================================
@dataclass(order=True)
class ExpressionRequest:
    """
    A queued expression with priority and expiration.

    Higher priority values sort first. If priorities are equal, earlier
    requests win (FIFO).
    """
    priority: int
    seq: int = field(compare=True)
    emotion: str = field(compare=False)
    duration: float = field(compare=False, default=0.0)
    curve: str = field(compare=False, default="linear")
    start_time: float = field(compare=False, default_factory=time.perf_counter)
    source: str = field(compare=False, default="manual")  # "manual" | "websocket"


# =============================================================================
# ExpressionMapper
# =============================================================================
class ExpressionMapper:
    """
    Advanced VRM blend-shape expression manager.

    Responsibilities
    ----------------
    - Load and validate expression JSON files.
    - Maintain a priority queue of expression requests.
    - Interpolate blend-shape weights over time using configurable curves.
    - Broadcast WebSocket events and log metrics.
    - Thread-safe state updates.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()

        # Expression data
        self._expressions: Dict[str, Dict[str, float]] = {}
        self._emotion_mapping: Dict[str, List[str]] = {}
        self._neutral_shapes: Dict[str, float] = dict(_DEFAULT_NEUTRAL)

        # Animation state
        self._current_shapes: Dict[str, float] = dict(self._neutral_shapes)
        self._target_shapes: Dict[str, float] = dict(self._neutral_shapes)
        self._from_shapes: Dict[str, float] = dict(self._neutral_shapes)
        self._current_emotion = "neutral"
        self._transition_start = 0.0
        self._transition_duration = 0.0
        self._transition_curve: Callable[[float], float] = _ease_linear
        self._animating = False

        # Priority queue
        self._queue: Deque[ExpressionRequest] = deque()
        self._seq_counter = 0
        self._active_request: Optional[ExpressionRequest] = None

        # Metrics
        self.metrics = ExpressionMetrics(_METRICS_ENABLED, _METRICS_PATH)

        # Background update thread (optional)
        self._update_thread: Optional[threading.Thread] = None
        self._shutdown = threading.Event()

        # Pre-load
        self.preload()

        # Start auto-updater
        if _AUTO_UPDATE:
            self._start_auto_update()

        # WebSocket listener
        if _WS_ENABLED:
            self._start_ws_listener()

    # ── Loading & validation ─────────────────────────────────────────────────
    def preload(self) -> None:
        """Eagerly load all expression JSONs and the mapping config."""
        # Mapping file
        if MAPPING_FILE.exists():
            try:
                with open(MAPPING_FILE, "r", encoding="utf-8") as f:
                    self._emotion_mapping = json.load(f)
                log.info(f"Loaded emotion mapping: {MAPPING_FILE}")
            except Exception as exc:
                log.warning(f"Failed to load emotion mapping: {exc}")
                self._emotion_mapping = {}

        # Expression JSONs
        supported = ["happy", "sad", "excited", "angry", "flirty", "sleepy", "neutral"]
        for emotion in supported:
            self._load_expression(emotion)

    def _load_expression(self, emotion: str) -> Dict[str, float]:
        if emotion in self._expressions:
            return self._expressions[emotion]

        path = EXPRESSIONS_DIR / f"{emotion}.json"
        if not path.is_file():
            log.warning(f"No expression file for: {emotion}")
            self._expressions[emotion] = {}
            return {}

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            shapes = data.get("blend_shapes", {})
            # Validate
            valid: Dict[str, float] = {}
            for k, v in shapes.items():
                if not isinstance(v, (int, float)):
                    log.warning(f"Non-numeric blend shape '{k}' in {emotion}.json — skipped")
                    continue
                if not 0.0 <= float(v) <= 1.0:
                    log.warning(f"Blend shape '{k}' out of range [0,1] in {emotion}.json — clamped")
                valid[k] = max(0.0, min(1.0, float(v)))

            # Merge with emotion_mapping.json if available
            mapped = self._emotion_mapping.get(emotion, [])
            for shape_name in mapped:
                if shape_name not in valid:
                    # If the mapping lists a shape not in the JSON, default to 1.0
                    valid[shape_name] = 1.0

            self._expressions[emotion] = valid
            log.debug(f"Loaded expression '{emotion}' with {len(valid)} blend shapes")
            return valid

        except Exception as exc:
            log.error(f"Failed to load {emotion}.json: {exc}")
            self._expressions[emotion] = {}
            return {}

    def validate_expressions(self) -> List[str]:
        """
        Check every expression JSON for malformed data.

        Returns a list of human-readable issue strings (empty if all clean).
        """
        issues: List[str] = []
        supported = ["happy", "sad", "excited", "angry", "flirty", "sleepy", "neutral"]

        for emotion in supported:
            path = EXPRESSIONS_DIR / f"{emotion}.json"
            if not path.exists():
                issues.append(f"MISSING: {path.name}")
                continue

            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except json.JSONDecodeError as exc:
                issues.append(f"MALFORMED JSON: {path.name} — {exc}")
                continue
            except Exception as exc:
                issues.append(f"UNREADABLE: {path.name} — {exc}")
                continue

            shapes = data.get("blend_shapes")
            if shapes is None:
                issues.append(f"MISSING KEY 'blend_shapes': {path.name}")
                continue
            if not isinstance(shapes, dict):
                issues.append(f"WRONG TYPE 'blend_shapes': {path.name} (expected dict)")
                continue

            for k, v in shapes.items():
                if not isinstance(v, (int, float)):
                    issues.append(f"NON-NUMERIC '{k}'={v!r}: {path.name}")
                elif not 0.0 <= float(v) <= 1.0:
                    issues.append(f"OUT OF RANGE '{k}'={v}: {path.name}")

        if not issues:
            log.info("All expression files validated successfully")
        else:
            log.warning(f"Expression validation found {len(issues)} issue(s)")
        return issues

    # ── Target shape resolution ──────────────────────────────────────────────
    def _resolve_target(self, emotion: str) -> Dict[str, float]:
        """Return the target blend shapes for *emotion* (cached)."""
        if emotion not in self._expressions:
            self._load_expression(emotion)

        shapes = self._expressions.get(emotion, {})
        if emotion == "neutral" and not shapes:
            return dict(self._neutral_shapes)
        return dict(shapes)

    # ── Animation core ───────────────────────────────────────────────────────
    def _start_transition(
        self,
        emotion: str,
        duration: float,
        curve: Callable[[float], float],
    ) -> None:
        self._from_shapes = dict(self._current_shapes)
        self._target_shapes = self._resolve_target(emotion)
        self._current_emotion = emotion
        self._transition_start = time.perf_counter()
        self._transition_duration = max(0.0, duration)
        self._transition_curve = curve
        self._animating = duration > 0.0

        # Ensure all keys exist in current so interpolation is complete
        all_keys = set(self._from_shapes) | set(self._target_shapes)
        for k in all_keys:
            self._from_shapes.setdefault(k, 0.0)
            self._target_shapes.setdefault(k, 0.0)
            self._current_shapes.setdefault(k, 0.0)

    def update(self, delta_time: Optional[float] = None) -> None:
        """
        Advance the animation system.

        Parameters
        ----------
        delta_time : float, optional
            Seconds since last update. If ``None``, computed internally.
            Only needed when calling manually; the auto-update thread ignores this.
        """
        with self._lock:
            now = time.perf_counter()

            # 1) Check if the active request has expired
            if self._active_request is not None:
                elapsed = now - self._active_request.start_time
                if elapsed >= self._active_request.duration:
                    # Expired — pop and activate next highest priority
                    self._active_request = None
                    self._promote_next_request()

            # 2) Interpolate blend shapes
            if not self._animating:
                return

            raw_t = 0.0
            if self._transition_duration > 0.0:
                raw_t = (now - self._transition_start) / self._transition_duration
            t = max(0.0, min(1.0, raw_t))
            eased = self._transition_curve(t)

            for key in self._current_shapes:
                src = self._from_shapes.get(key, 0.0)
                dst = self._target_shapes.get(key, 0.0)
                self._current_shapes[key] = src + (dst - src) * eased

            if t >= 1.0:
                self._animating = False

    def _promote_next_request(self) -> None:
        """Activate the highest-priority pending request, or revert to neutral."""
        if not self._queue:
            self._start_transition("neutral", 0.3, _ease_in_out)
            self._current_emotion = "neutral"
            return

        # Sort by priority desc, then seq asc (FIFO for same priority)
        sorted_reqs = sorted(self._queue, key=lambda r: (-r.priority, r.seq))
        chosen = sorted_reqs[0]
        self._queue.remove(chosen)

        self._active_request = chosen
        curve_fn = _CURVES.get(chosen.curve, _ease_linear)
        self._start_transition(chosen.emotion, chosen.duration, curve_fn)

        self._broadcast(
            "expression_changed",
            {
                "emotion": chosen.emotion,
                "priority": chosen.priority,
                "duration": chosen.duration,
                "source": chosen.source,
            },
        )

        self.metrics.log(
            {
                "timestamp": datetime.now().isoformat(),
                "event": "expression_changed",
                "emotion": chosen.emotion,
                "priority": chosen.priority,
                "duration": chosen.duration,
                "source": chosen.source,
            }
        )

        log.info(
            f"Expression promoted: {chosen.emotion} "
            f"(priority={chosen.priority}, duration={chosen.duration}s)"
        )

    # ── Public API ───────────────────────────────────────────────────────────
    def set_expression(
        self,
        emotion: str,
        duration: float = 0.5,
        priority: int = 1,
        curve: str = "linear",
        source: str = "manual",
    ) -> None:
        """
        Request a transition to *emotion*.

        If *priority* exceeds the currently active expression, it takes effect
        immediately. Otherwise it is queued and will activate once higher-
        priority expressions expire.
        """
        emotion = emotion.lower().strip()
        if emotion not in self._expressions and emotion != "neutral":
            log.warning(f"Unknown emotion '{emotion}' — loading on demand")
            self._load_expression(emotion)

        with self._lock:
            self._seq_counter += 1
            req = ExpressionRequest(
                priority=priority,
                seq=self._seq_counter,
                emotion=emotion,
                duration=duration,
                curve=curve,
                start_time=time.perf_counter(),
                source=source,
            )

            # If no active request, or higher priority than active, switch now
            if self._active_request is None or priority > self._active_request.priority:
                if self._active_request is not None:
                    # Push current back to queue (it was interrupted)
                    self._queue.append(self._active_request)
                self._active_request = req
                curve_fn = _CURVES.get(curve, _ease_linear)
                self._start_transition(emotion, duration, curve_fn)

                self._broadcast(
                    "expression_changed",
                    {
                        "emotion": emotion,
                        "priority": priority,
                        "duration": duration,
                        "source": source,
                    },
                )

                self.metrics.log(
                    {
                        "timestamp": datetime.now().isoformat(),
                        "event": "expression_set",
                        "emotion": emotion,
                        "priority": priority,
                        "duration": duration,
                        "source": source,
                    }
                )

                log.info(
                    f"Expression set: {emotion} "
                    f"(priority={priority}, duration={duration}s, curve={curve})"
                )
            else:
                # Queue for later
                self._queue.append(req)
                log.debug(
                    f"Expression queued: {emotion} "
                    f"(priority={priority}, {len(self._queue)} pending)"
                )

    def reset_to_neutral(self, duration: float = 0.2, priority: int = 0) -> None:
        """Convenience method to revert to neutral."""
        self.set_expression("neutral", duration=duration, priority=priority)

    def get_current_blend_shapes(self) -> Dict[str, float]:
        """Return the interpolated blend-shape weights for the current frame."""
        with self._lock:
            return dict(self._current_shapes)

    def get_current_expression(self) -> str:
        """Return the name of the currently active emotion."""
        with self._lock:
            return self._current_emotion

    def is_animating(self) -> bool:
        """Return ``True`` if a transition is still in progress."""
        with self._lock:
            return self._animating

    # ── Backward-compatible API ──────────────────────────────────────────────
    def get_blend_shapes(self, emotion: str) -> Dict[str, float]:
        """
        Return the **target** blend shapes for *emotion* (no interpolation).

        This is the legacy API. For real-time rendering, use
        ``get_current_blend_shapes()`` instead.
        """
        emotion = emotion.lower().strip()
        if emotion not in self._expressions and emotion != "neutral":
            log.debug(f"Unknown emotion '{emotion}', using neutral")
            emotion = "neutral"
        return self._resolve_target(emotion)

    def list_emotions(self) -> List[str]:
        """Return the list of supported emotion names."""
        return list(self._expressions.keys())

    # ── WebSocket integration ────────────────────────────────────────────────
    def _start_ws_listener(self) -> None:
        """Register a callback on the WebSocket hub for remote expression commands."""
        try:
            hub = get_websocket_hub()
            # If the hub supports registering callbacks, do so; otherwise poll
            if hasattr(hub, "register_handler"):
                hub.register_handler("set_expression", self._on_ws_set_expression)
        except Exception as exc:
            log.debug(f"Could not register WS listener: {exc}")

    def _on_ws_set_expression(self, payload: Dict[str, Any]) -> None:
        emotion = payload.get("emotion", "neutral")
        duration = payload.get("duration", 0.5)
        priority = payload.get("priority", 1)
        curve = payload.get("curve", "linear")
        self.set_expression(emotion, duration, priority, curve, source="websocket")

    def _broadcast(self, msg_type: str, payload: Dict[str, Any]) -> None:
        if not _WS_ENABLED:
            return
        try:
            hub = get_websocket_hub()
            hub.broadcast({"type": msg_type, **payload})
        except Exception as exc:
            log.debug(f"Expression WS broadcast failed: {exc}")

    # ── Auto-update thread ───────────────────────────────────────────────────
    def _start_auto_update(self) -> None:
        def _loop() -> None:
            while not self._shutdown.is_set():
                self.update()
                time.sleep(_UPDATE_INTERVAL)

        self._update_thread = threading.Thread(target=_loop, daemon=True, name="ExprMapperUpdate")
        self._update_thread.start()
        log.debug(f"Expression auto-update started ({_UPDATE_RATE_HZ} Hz)")

    def shutdown(self) -> None:
        """Stop the auto-update thread and clear state."""
        self._shutdown.set()
        if self._update_thread:
            self._update_thread.join(timeout=1.0)
        with self._lock:
            self._queue.clear()
            self._current_shapes = dict(self._neutral_shapes)
            self._animating = False


# =============================================================================
# Module-level singleton
# =============================================================================
_mapper: Optional[ExpressionMapper] = None
_mapper_lock = threading.Lock()


def _get_mapper() -> ExpressionMapper:
    global _mapper
    if _mapper is None:
        with _mapper_lock:
            if _mapper is None:
                _mapper = ExpressionMapper()
    return _mapper


# ── Backward-compatible module-level functions ───────────────────────────────
def get_blend_shapes(emotion: str) -> Dict[str, float]:
    """
    Return the target blend shapes for *emotion* (legacy API).

    For real-time animated values, use ``ExpressionMapper.get_current_blend_shapes()``.
    """
    return _get_mapper().get_blend_shapes(emotion)


def list_emotions() -> List[str]:
    """Return supported emotion names."""
    return _get_mapper().list_emotions()


# ── New public functions ─────────────────────────────────────────────────────
def set_expression(
    emotion: str,
    duration: float = 0.5,
    priority: int = 1,
    curve: str = "linear",
) -> None:
    """Trigger an expression transition."""
    _get_mapper().set_expression(emotion, duration, priority, curve)


def reset_to_neutral(duration: float = 0.2, priority: int = 0) -> None:
    """Revert to neutral expression."""
    _get_mapper().reset_to_neutral(duration, priority)


def get_current_blend_shapes() -> Dict[str, float]:
    """Get interpolated blend-shape weights for the current frame."""
    return _get_mapper().get_current_blend_shapes()


def get_current_expression() -> str:
    """Get the currently active emotion name."""
    return _get_mapper().get_current_expression()


def is_animating() -> bool:
    """Check if a transition is in progress."""
    return _get_mapper().is_animating()


def update(delta_time: Optional[float] = None) -> None:
    """Manually advance the animation system."""
    _get_mapper().update(delta_time)


def preload() -> None:
    """Eagerly load all expression data."""
    _get_mapper().preload()


def validate_expressions() -> List[str]:
    """Validate all expression JSON files and return issues."""
    return _get_mapper().validate_expressions()


__all__ = [
    "get_blend_shapes",
    "list_emotions",
    "set_expression",
    "reset_to_neutral",
    "get_current_blend_shapes",
    "get_current_expression",
    "is_animating",
    "update",
    "preload",
    "validate_expressions",
    "ExpressionMapper",
    "ExpressionRequest",
]
