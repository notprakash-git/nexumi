"""
src/integration/emotion_selector.py

Determines Nexumi's emotional state from user/AI text using a hybrid pipeline:
keyword rules → negation/modifier analysis → optional local sentiment model
→ LLM fallback (for low-confidence cases) → user bias → history smoothing.

Public API
----------
``select_emotion(user_text="", ai_text="") -> Tuple[str, float]``
    Thread-safe entry point. Returns ``(emotion_name, confidence)``.

``get_selector() -> EmotionSelector``
    Returns the singleton instance (useful for tests or manual history
    manipulation).

Configuration (settings.json)
-----------------------------
.. code-block:: json

    {
      "emotion_selector": {
        "default_emotion": "happy",
        "history_size": 5,
        "transition_smoothing": 0.3,
        "keyword_confidence_threshold": 0.6,
        "llm_fallback": {
          "enabled": true,
          "confidence_threshold": 0.6,
          "model": "google/gemma-4-31b-it:free",
          "cache_ttl_seconds": 300
        },
        "sentiment_model": {
          "enabled": false,
          "model_name": "distilbert-base-uncased-finetuned-sst-2-english"
        },
        "rules": {
          "happy": {
            "keywords": ["love","adore","happy","joy","great","amazing","hehe","yay"],
            "confidence_bump": 0.7
          },
          "sad": {
            "keywords": ["sad","sorry","disappoint","cry","unhappy","tears"],
            "confidence_bump": 0.7
          },
          "excited": {
            "keywords": ["excited","awesome","fantastic","wow","omg","perfect"],
            "confidence_bump": 0.8
          },
          "angry": {
            "keywords": ["angry","hate","stupid","annoying","frustrat","ugh"],
            "confidence_bump": 0.8
          },
          "flirty": {
            "keywords": ["cute","pretty","beautiful","flirt","wink","blush","kiss"],
            "confidence_bump": 0.6
          },
          "sleepy": {
            "keywords": ["tired","sleep","sleepy","exhausted","yawn","bed","night"],
            "confidence_bump": 0.7
          }
        },
        "negation_words": ["not","don't","never","isn't","wasn't","didn't","no","none","nobody","nothing","neither","nowhere","hardly","barely","scarcely"],
        "intensifiers": ["very","extremely","incredibly","absolutely","totally","completely","really","so","super","ultra","mega"],
        "diminishers": ["slightly","kind of","sort of","a bit","a little","somewhat","rather","pretty","fairly","quite"],
        "metrics": {
          "enabled": true,
          "path": "logs/emotion_metrics.jsonl"
        },
        "websocket": {
          "enabled": true
        }
      }
    }

``user_profile.json`` (optional)
--------------------------------
.. code-block:: json

    {
      "emotion_bias": {
        "flirty": 0.15,
        "happy": 0.05
      },
      "preferred_base_emotion": "neutral"
    }

Optional dependencies
---------------------
- ``transformers`` + ``torch`` – enables the local sentiment-analysis pipeline.
- ``openai`` – required for the LLM fallback (already needed by ``brain.py``).
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from collections import deque
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.utils.logger import get_logger
from src.utils.settings import load_settings

# ── WebSocket hub (optional) ───────────────────────────────────────────────
try:
    from src.ui.websocket_server import get_websocket_hub
except ImportError:
    class _WebSocketHubStub:
        def broadcast(self, payload: Dict[str, Any]) -> None:
            pass

    _ws_hub_stub = _WebSocketHubStub()

    def get_websocket_hub() -> _WebSocketHubStub:  # type: ignore[misc]
        return _ws_hub_stub

# ── Optional: transformers sentiment pipeline ──────────────────────────────
try:
    from transformers import pipeline as _transformers_pipeline

    _TRANSFORMERS_OK = True
except ImportError:
    _transformers_pipeline = None  # type: ignore[misc,assignment]
    _TRANSFORMERS_OK = False

# ── Optional: openai SDK (for LLM fallback) ───────────────────────────────
try:
    from openai import OpenAI

    _OPENAI_OK = True
except ImportError:
    OpenAI = None  # type: ignore[misc,assignment]
    _OPENAI_OK = False

log = get_logger("emotion_selector")

# ── OpenRouter config (shared with brain.py) ─────────────────────────────
_ENV_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../../config/api_keys.env")
)
try:
    from dotenv import load_dotenv
    load_dotenv(_ENV_PATH)
except Exception:
    pass

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL = "google/gemma-4-31b-it:free"


# =============================================================================
# Enums
# =============================================================================
class Emotion(Enum):
    HAPPY = "happy"
    SAD = "sad"
    EXCITED = "excited"
    ANGRY = "angry"
    FLIRTY = "flirty"
    SLEEPY = "sleepy"
    NEUTRAL = "neutral"


ALL_EMOTIONS = [e.value for e in Emotion]


# =============================================================================
# Metrics
# =============================================================================
class EmotionMetrics:
    def __init__(self, enabled: bool, path: str, max_bytes: int = 5 * 1024 * 1024):
        self.enabled = enabled
        self.path = Path(path)
        self.max_bytes = max_bytes
        self._lock = threading.Lock()
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def log(self, record: Dict[str, Any]) -> None:
        if not self.enabled:
            return
        with self._lock:
            if self.path.exists() and self.path.stat().st_size > self.max_bytes:
                self._rotate()
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")

    def _rotate(self) -> None:
        for i in range(2, 0, -1):
            old = self.path.with_suffix(f".jsonl.{i}")
            new = self.path.with_suffix(f".jsonl.{i + 1}")
            if old.exists():
                old.rename(new)
        if self.path.exists():
            self.path.rename(self.path.with_suffix(".jsonl.1"))


# =============================================================================
# EmotionSelector
# =============================================================================
class EmotionSelector:
    """
    Hybrid emotion classifier for Nexumi.

    Pipeline (in order)
    -------------------
    1. **Keyword scoring** – configurable rules from ``settings.json``.
       Supports multi-word phrases (e.g. "miss you", "can't wait").
    2. **Negation / modifier analysis** – flips or scales keyword scores.
    3. **Local sentiment model** (optional) – ``transformers`` pipeline.
    4. **LLM fallback** – OpenRouter call when confidence is still low.
    5. **User bias** – per-emotion offsets from ``user_profile.json``.
    6. **Preferred base emotion** – overrides the hard-coded default when no
       strong signal is detected.
    7. **History smoothing** – rolling window prevents wild swings.
    8. **Broadcast** – WebSocket message to update the 3D avatar.
    """

    def __init__(self) -> None:
        self.cfg = load_settings().get("emotion_selector", {})

        self.default_emotion = self.cfg.get("default_emotion", "happy")
        self.history_size = self.cfg.get("history_size", 5)
        self.smoothing = self.cfg.get("transition_smoothing", 0.3)
        self.keyword_threshold = self.cfg.get("keyword_confidence_threshold", 0.6)

        # LLM fallback config
        llm_cfg = self.cfg.get("llm_fallback", {})
        self.llm_enabled = llm_cfg.get("enabled", True) and _OPENAI_OK
        self.llm_threshold = llm_cfg.get("confidence_threshold", 0.6)
        self.llm_model = llm_cfg.get("model", OPENROUTER_MODEL)
        self.llm_cache_ttl = llm_cfg.get("cache_ttl_seconds", 300)
        self._llm_cache: Dict[str, Tuple[str, float, float]] = {}  # key -> (emotion, confidence, expiry)
        self._llm_cache_lock = threading.Lock()

        # Sentiment model config
        sent_cfg = self.cfg.get("sentiment_model", {})
        self.sentiment_enabled = sent_cfg.get("enabled", False) and _TRANSFORMERS_OK
        self.sentiment_model_name = sent_cfg.get(
            "model_name", "distilbert-base-uncased-finetuned-sst-2-english"
        )
        self._sentiment_pipe: Any = None

        # Rules
        self.rules = self._load_rules()
        self.negation_words = set(
            self.cfg.get(
                "negation_words",
                ["not", "don't", "never", "isn't", "wasn't", "didn't", "no", "none",
                 "nobody", "nothing", "neither", "nowhere", "hardly", "barely", "scarcely"],
            )
        )
        self.intensifiers = set(
            self.cfg.get(
                "intensifiers",
                ["very", "extremely", "incredibly", "absolutely", "totally", "completely",
                 "really", "so", "super", "ultra", "mega"],
            )
        )
        self.diminishers = set(
            self.cfg.get(
                "diminishers",
                ["slightly", "kind of", "sort of", "a bit", "a little", "somewhat",
                 "rather", "pretty", "fairly", "quite"],
            )
        )

        # History, bias, and preferred base emotion
        self._history: deque[str] = deque(maxlen=self.history_size)
        self._history_lock = threading.Lock()
        self._user_bias, self._preferred_base = self._load_user_profile()

        # Thread-safe method lock (created once, reused forever)
        self._method_lock = threading.Lock()

        # Metrics
        m_cfg = self.cfg.get("metrics", {})
        self.metrics = EmotionMetrics(
            enabled=m_cfg.get("enabled", True),
            path=m_cfg.get("path", "logs/emotion_metrics.jsonl"),
        )

        # WebSocket
        self._ws_enabled = self.cfg.get("websocket", {}).get("enabled", True)

        # Lazy LLM client
        self._llm_client: Optional[Any] = None

    # ── Config / profile loaders ─────────────────────────────────────────────
    def _load_rules(self) -> Dict[str, Dict[str, Any]]:
        raw = self.cfg.get("rules", {})
        if not raw:
            return {
                "happy": {
                    "keywords": ["love", "adore", "miss you", "thank", "happy", "joy",
                                 "great", "amazing", "wonderful", "hehe", "yay", "woo", "glad"],
                    "confidence_bump": 0.7,
                },
                "sad": {
                    "keywords": ["sad", "sorry", "disappoint", "miss", "wish", "hope",
                                 "tears", "cry", "unhappy", "unfortunate", "failed"],
                    "confidence_bump": 0.7,
                },
                "excited": {
                    "keywords": ["excited", "can't wait", "awesome", "fantastic",
                                 "incredible", "wow", "omg", "really", "best", "perfect"],
                    "confidence_bump": 0.8,
                },
                "angry": {
                    "keywords": ["angry", "hate", "stupid", "annoying", "frustrat",
                                 "ugh", "why", "worst", "terrible", "awful", "shut up"],
                    "confidence_bump": 0.8,
                },
                "flirty": {
                    "keywords": ["cute", "pretty", "beautiful", "flirt", "wink",
                                 "blush", "sweet", "kiss", "hug", "squeeze"],
                    "confidence_bump": 0.6,
                },
                "sleepy": {
                    "keywords": ["tired", "sleep", "sleepy", "exhausted", "drowsy",
                                 "yawn", "rest", "bed", "night", "bored"],
                    "confidence_bump": 0.7,
                },
            }
        return raw

    def _load_user_profile(self) -> Tuple[Dict[str, float], Optional[str]]:
        path = Path(__file__).resolve().parents[2] / "config" / "user_profile.json"
        if not path.exists():
            return {}, None
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            bias = data.get("emotion_bias", {})
            base = data.get("preferred_base_emotion")
            return bias, base
        except Exception as exc:
            log.warning(f"Failed to load user_profile.json: {exc}")
            return {}, None

    # ── Lazy sentiment pipeline ────────────────────────────────────────────
    def _get_sentiment_pipe(self) -> Any:
        if self._sentiment_pipe is None and self.sentiment_enabled:
            try:
                self._sentiment_pipe = _transformers_pipeline(
                    "sentiment-analysis",
                    model=self.sentiment_model_name,
                )
                log.info(f"Loaded sentiment model: {self.sentiment_model_name}")
            except Exception as exc:
                log.warning(f"Sentiment model load failed: {exc}")
                self.sentiment_enabled = False
        return self._sentiment_pipe

    # ── Lazy LLM client ──────────────────────────────────────────────────────
    def _get_llm_client(self) -> Optional[Any]:
        if self._llm_client is not None:
            return self._llm_client
        if not _OPENAI_OK:
            return None
        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        if not api_key or api_key == "your_openrouter_api_key_here":
            log.warning("OPENROUTER_API_KEY missing — LLM fallback disabled")
            self.llm_enabled = False
            return None
        try:
            self._llm_client = OpenAI(
                base_url=OPENROUTER_BASE_URL,
                api_key=api_key,
                default_headers={
                    "HTTP-Referer": "https://nexumi.local",
                    "X-Title": "Nexumi Emotion Selector",
                },
            )
            return self._llm_client
        except Exception as exc:
            log.warning(f"LLM client init failed: {exc}")
            self.llm_enabled = False
            return None

    # ── Keyword matching helpers ─────────────────────────────────────────────
    @staticmethod
    def _compile_keyword_pattern(keyword: str) -> re.Pattern[str]:
        """
        Build a regex that matches *keyword* as a whole phrase.

        - Single words use ``\b`` word boundaries.
        - Multi-word phrases use ``(?:^|\s)`` / ``(?:\s|$)`` so spaces are
          treated as delimiters instead of word characters.
        """
        lowered = keyword.lower().strip()
        if " " in lowered:
            # Multi-word: anchor to start of string, whitespace, or punctuation
            escaped = re.escape(lowered)
            pattern = rf"(?:^|[\s\W]){escaped}(?:[\s\W]|$)"
        else:
            # Single word: standard word boundary
            pattern = rf"\b{re.escape(lowered)}\b"
        return re.compile(pattern, re.IGNORECASE)

    def _keyword_score(self, text: str) -> Tuple[str, float, str]:
        t = text.lower()
        scores: Dict[str, float] = {e: 0.0 for e in ALL_EMOTIONS}

        for emotion, rule in self.rules.items():
            bump = rule.get("confidence_bump", 0.5)
            for kw in rule.get("keywords", []):
                pattern = self._compile_keyword_pattern(kw)
                for match in pattern.finditer(text):
                    # Context window: 60 chars before match start
                    ctx_start = max(0, match.start() - 60)
                    context = t[ctx_start:match.start()]
                    words = context.split()

                    modifier = 1.0
                    if any(n in words[-5:] for n in self.negation_words):
                        modifier = -0.5
                    if any(i in words[-3:] for i in self.intensifiers):
                        modifier *= 1.3
                    elif any(d in words[-3:] for d in self.diminishers):
                        modifier *= 0.6

                    scores[emotion] += bump * modifier

        best = max(scores, key=lambda e: scores[e])
        best_score = scores[best]

        fallback = self._preferred_base or self.default_emotion
        if best_score < 0.3:
            return fallback, 0.5, "keyword_default"
        return best, min(best_score, 1.0), "keyword"

    # ── Local sentiment model ────────────────────────────────────────────────
    def _sentiment_score(self, text: str) -> Tuple[str, float, str]:
        pipe = self._get_sentiment_pipe()
        if pipe is None:
            return self.default_emotion, 0.0, "sentiment_unavailable"

        try:
            result = pipe(text[:512])[0]
            label = result.get("label", "NEUTRAL").upper()
            score = result.get("score", 0.5)

            if label == "POSITIVE":
                emotion = "excited" if score > 0.9 else "happy"
            elif label == "NEGATIVE":
                emotion = "angry" if "angry" in text.lower() or "hate" in text.lower() else "sad"
            else:
                emotion = "neutral"

            confidence = score
            return emotion, confidence, "sentiment"
        except Exception as exc:
            log.warning(f"Sentiment inference error: {exc}")
            return self.default_emotion, 0.0, "sentiment_error"

    # ── LLM fallback ─────────────────────────────────────────────────────────
    def _llm_classify(self, text: str) -> Tuple[str, float, str]:
        if not self.llm_enabled:
            return self.default_emotion, 0.5, "llm_disabled"

        cache_key = hashlib.sha256(text.encode("utf-8")).hexdigest()
        with self._llm_cache_lock:
            cached = self._llm_cache.get(cache_key)
            if cached:
                emotion, confidence, expiry = cached
                if time.time() < expiry:
                    log.debug(f"LLM emotion cache hit for key {cache_key[:16]}…")
                    return emotion, confidence, "llm_cached"
                else:
                    del self._llm_cache[cache_key]

        client = self._get_llm_client()
        if client is None:
            return self.default_emotion, 0.5, "llm_no_client"

        system_prompt = (
            "You are a sentiment-analysis expert. "
            "Analyse the following conversation and return the single most likely "
            "emotion for an AI companion named Nexumi. "
            "Choose exactly one from: happy, sad, excited, angry, flirty, sleepy, neutral. "
            "Output ONLY the emotion name, nothing else."
        )

        try:
            completion = client.chat.completions.create(
                model=self.llm_model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text[:2000]},
                ],
                temperature=0.0,
                max_tokens=10,
            )
            raw = completion.choices[0].message.content.strip().lower()
            raw = re.sub(r"[^\w]", "", raw)
            emotion = raw if raw in ALL_EMOTIONS else self.default_emotion
            confidence = 0.85

            with self._llm_cache_lock:
                self._llm_cache[cache_key] = (emotion, confidence, time.time() + self.llm_cache_ttl)

            log.info(f"LLM emotion fallback: {emotion} (confidence={confidence})")
            return emotion, confidence, "llm"
        except Exception as exc:
            log.warning(f"LLM emotion classification failed: {exc}")
            return self.default_emotion, 0.5, "llm_error"

    # ── User bias ────────────────────────────────────────────────────────────
    def _apply_bias(self, emotion: str, confidence: float) -> Tuple[str, float]:
        if not self._user_bias:
            return emotion, confidence

        scores: Dict[str, float] = {e: 0.0 for e in ALL_EMOTIONS}
        scores[emotion] = confidence

        for e, offset in self._user_bias.items():
            if e in scores:
                scores[e] += offset

        best = max(scores, key=lambda e: scores[e])
        return best, min(scores[best], 1.0)

    # ── History smoothing ────────────────────────────────────────────────────
    def _smooth_transition(self, emotion: str, confidence: float) -> Tuple[str, float]:
        if self.smoothing <= 0.0:
            return emotion, confidence

        with self._history_lock:
            if not self._history:
                return emotion, confidence

            counts: Dict[str, int] = {}
            for e in self._history:
                counts[e] = counts.get(e, 0) + 1

            history_dominant = max(counts, key=lambda e: counts[e])
            if emotion != history_dominant:
                confidence *= (1.0 - self.smoothing)
                if confidence < 0.35:
                    emotion = history_dominant
                    confidence = 0.5

        return emotion, confidence

    # ── WebSocket broadcast ──────────────────────────────────────────────────
    def _broadcast(self, emotion: str, confidence: float, method: str) -> None:
        if not self._ws_enabled:
            return
        try:
            hub = get_websocket_hub()
            hub.broadcast(
                {
                    "type": "emotion",
                    "emotion": emotion,
                    "confidence": round(confidence, 2),
                    "method": method,
                }
            )
        except Exception as exc:
            log.debug(f"Emotion WebSocket broadcast failed: {exc}")

    # ── Public entry point ───────────────────────────────────────────────────
    def select_emotion(self, user_text: str = "", ai_text: str = "") -> Tuple[str, float]:
        """
        Thread-safe hybrid emotion classification.

        Returns
        -------
        Tuple[str, float]
            ``(emotion_name, confidence)`` where confidence is in ``[0, 1]``.
        """
        with self._method_lock:  # persistent lock — created once in __init__
            t0 = time.perf_counter()
            combined = f"{user_text} {ai_text}".strip()

            # 1) Keyword scoring
            emotion, confidence, method = self._keyword_score(combined)

            # 2) Optional local sentiment model
            if self.sentiment_enabled and confidence < 0.75:
                sent_emotion, sent_conf, sent_method = self._sentiment_score(combined)
                emotion, confidence = self._blend(emotion, confidence, sent_emotion, sent_conf, 0.6)
                method = f"{method}+{sent_method}"

            # 3) LLM fallback if still below threshold
            if confidence < self.llm_threshold:
                llm_emotion, llm_conf, llm_method = self._llm_classify(combined)
                emotion, confidence = llm_emotion, llm_conf
                method = llm_method

            # 4) User bias
            emotion, confidence = self._apply_bias(emotion, confidence)

            # 5) History smoothing
            emotion, confidence = self._smooth_transition(emotion, confidence)

            # 6) Update history
            with self._history_lock:
                self._history.append(emotion)

            # 7) Broadcast
            self._broadcast(emotion, confidence, method)

            # 8) Metrics
            latency_ms = int((time.perf_counter() - t0) * 1000)
            self.metrics.log(
                {
                    "timestamp": datetime.now().isoformat(),
                    "method": method,
                    "emotion": emotion,
                    "confidence": round(confidence, 3),
                    "latency_ms": latency_ms,
                    "user_text_preview": user_text[:80],
                    "ai_text_preview": ai_text[:80],
                }
            )

            log.debug(f"Emotion selected: {emotion} (confidence={confidence:.2f}, method={method})")
            return emotion, confidence

    @staticmethod
    def _blend(
        e1: str, c1: float, e2: str, c2: float, weight1: float
    ) -> Tuple[str, float]:
        """Blend two emotion candidates. If emotions match, boost confidence."""
        if e1 == e2:
            return e1, min(c1 + c2 * (1 - weight1), 1.0)
        s1 = c1 * weight1
        s2 = c2 * (1 - weight1)
        return (e1, c1) if s1 >= s2 else (e2, c2)


# =============================================================================
# Module-level singleton
# =============================================================================
_selector: Optional[EmotionSelector] = None
_selector_lock = threading.Lock()


def get_selector() -> EmotionSelector:
    global _selector
    if _selector is None:
        with _selector_lock:
            if _selector is None:
                _selector = EmotionSelector()
    return _selector


def select_emotion(user_text: str = "", ai_text: str = "") -> Tuple[str, float]:
    """
    Determine the best emotion from the combination of user input and AI response.

    Parameters
    ----------
    user_text : str
        The user's message (or STT result).
    ai_text : str
        The AI's planned response text (optional; usually empty when called
        from the wakeword/STT pipeline before the brain generates a reply).

    Returns
    -------
    Tuple[str, float]
        ``(emotion_name, confidence)`` — emotion is one of the ``Emotion`` enum
        values, confidence is in ``[0, 1]``.
    """
    return get_selector().select_emotion(user_text, ai_text)


__all__ = [
    "select_emotion",
    "get_selector",
    "Emotion",
    "EmotionSelector",
    "EmotionMetrics",
]
