"""
src/integration/hime_controller.py

Controller for Nexumi's 3D avatar display.

Replaces the missing Hime Display with a self-contained PyQt6 + Three.js
VRM viewer launched as a subprocess. All expression commands are sent via
the shared WebSocket hub (port 8765) so the viewer receives them
automatically — no direct HTTP API needed.

Public API
----------
``start_viewer() -> bool``
    Launch the 3D viewer (subprocess). Returns ``True`` on success.

``stop_viewer()``
    Terminate the viewer subprocess.

``apply_expression(emotion, duration=3.0)``
    Broadcast an emotion to the WebSocket hub. The viewer (and any other
    clients) will pick it up. Cancels any pending reset timer so overlapping
    calls don't prematurely revert to neutral.

``reset_expression()``
    Broadcast neutral expression.

``set_blend_shape(shape_name, weight)``
    Legacy API. Broadcasts a single blend-shape override.
"""

import json
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from src.utils.logger import get_logger
from src.utils.settings import load_settings
from src.integration.expression_mapper import get_blend_shapes

log = get_logger("hime_controller")

_settings = load_settings()
_hime_cfg = _settings.get("hime_display", {})

VRM_PATH = Path(__file__).resolve().parents[2] / "assets" / "3d_model" / "nexumi.vrm"

_viewer_process: Optional[subprocess.Popen] = None
_viewer_available = False
_reset_timer: Optional[threading.Timer] = None

# Metrics
_METRICS_ENABLED = _hime_cfg.get("metrics", {}).get("enabled", True)
_METRICS_PATH = _hime_cfg.get("metrics", {}).get("path", "logs/hime_metrics.jsonl")


def _log_metrics(record: Dict[str, Any]) -> None:
    if not _METRICS_ENABLED:
        return
    try:
        path = Path(_METRICS_PATH)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
    except Exception as exc:
        log.debug(f"Metrics write failed: {exc}")


def _notify_ws(emotion: str, shapes: Dict[str, float]) -> None:
    """
    Broadcast expression update via the shared WebSocket hub.
    Retries once after a short delay if the hub is not yet available.
    """
    try:
        from src.ui.websocket_server import get_websocket_hub
        hub = get_websocket_hub()
        hub.broadcast(
            {
                "type": "emotion",
                "emotion": emotion,
                "blend_shapes": shapes,
            }
        )
    except Exception as exc:
        log.debug(f"WebSocket broadcast failed (will retry once): {exc}")
        time.sleep(0.2)
        try:
            from src.ui.websocket_server import get_websocket_hub
            hub = get_websocket_hub()
            hub.broadcast(
                {
                    "type": "emotion",
                    "emotion": emotion,
                    "blend_shapes": shapes,
                }
            )
        except Exception as exc2:
            log.warning(f"WebSocket broadcast failed permanently: {exc2}")


def start_viewer() -> bool:
    """
    Launch the VRM viewer.

    1. Check that the VRM model exists.
    2. Launch ``src.ui.vrm_viewer`` as a subprocess.
    3. Mark viewer as available.
    """
    global _viewer_process, _viewer_available

    if not VRM_PATH.is_file():
        log.warning(f"VRM model not found: {VRM_PATH}")
        _viewer_available = False
        return False

    if _viewer_process is not None and _viewer_process.poll() is None:
        log.info("Viewer already running")
        _viewer_available = True
        return True

    try:
        from src.ui.vrm_viewer import start_viewer_subprocess
        _viewer_process = start_viewer_subprocess()
        time.sleep(2)  # Allow time for HTTP server + window init
        _viewer_available = True
        log.info(f"VRM viewer launched (PID {_viewer_process.pid})")
        return True
    except Exception as exc:
        log.error(f"Failed to start VRM viewer: {exc}")
        _viewer_available = False
        return False


def stop_viewer() -> None:
    """Terminate the viewer subprocess and clear availability flag."""
    global _viewer_process, _viewer_available
    if _viewer_process:
        try:
            _viewer_process.terminate()
            _viewer_process.wait(timeout=3)
        except Exception:
            _viewer_process.kill()
        _viewer_process = None
    _viewer_available = False
    log.info("VRM viewer stopped")


def apply_expression(emotion: str, duration: float = 3.0) -> None:
    """
    Broadcast an emotion expression to all WebSocket listeners (including
    the VRM viewer). After *duration* seconds, automatically reset to neutral.

    If called again before the previous duration expires, the pending reset
    is cancelled and replaced with the new one.
    """
    global _reset_timer

    shapes = get_blend_shapes(emotion)
    log.info(f"Applying expression: {emotion} → {shapes}")

    _notify_ws(emotion, shapes)

    _log_metrics(
        {
            "timestamp": datetime.now().isoformat(),
            "event": "apply_expression",
            "emotion": emotion,
            "duration": duration,
            "blend_shapes": shapes,
        }
    )

    # Cancel any previous pending reset
    if _reset_timer is not None:
        _reset_timer.cancel()
        _reset_timer = None

    if duration > 0:
        _reset_timer = threading.Timer(duration, reset_expression)
        _reset_timer.daemon = True
        _reset_timer.start()


def reset_expression() -> None:
    """Broadcast neutral expression to all listeners."""
    global _reset_timer
    _reset_timer = None  # Clear reference so GC can clean up

    neutral = get_blend_shapes("neutral")
    _notify_ws("neutral", neutral)
    _log_metrics(
        {
            "timestamp": datetime.now().isoformat(),
            "event": "reset_expression",
            "emotion": "neutral",
        }
    )


# ── Backward-compatible aliases ────────────────────────────────────────────
def start_hime() -> bool:
    """Legacy alias for ``start_viewer()``."""
    return start_viewer()


def stop_hime() -> None:
    """Legacy alias for ``stop_viewer()``."""
    stop_viewer()


def set_blend_shape(shape_name: str, weight: float) -> None:
    """
    Legacy API. Broadcasts a single blend-shape override via WebSocket.
    The emotion field is set to the shape name for clarity in logs.
    """
    _notify_ws(shape_name, {shape_name: weight})
    _log_metrics(
        {
            "timestamp": datetime.now().isoformat(),
            "event": "set_blend_shape",
            "shape": shape_name,
            "weight": weight,
        }
    )
