"""
src/__main__.py

Nexumi entry point: python -m src

Responsibilities
----------------
1. Ensure the project root is on sys.path for absolute imports.
2. Parse CLI arguments (--debug, --no-tray, --help).
3. Configure logging level before any heavy imports.
4. Probe the WebSocket hub and warn if it is unreachable.
5. Start the PyQt6 application, desktop mate window, and optional tray.
6. Wire cross-component signals (mood changes → tray tooltip updates).
7. Ensure graceful shutdown: close all windows, stop background threads,
   flush metrics, and save window geometry.

The WebSocket server (src/ui/websocket_server.py) should be running
before this entry point is invoked. If not, a warning is logged and
Nexumi will retry connections automatically.
"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

# ── Ensure project root is on sys.path ───────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

from PyQt6.QtWidgets import QApplication

from src.ui.desktop_mate import DesktopMate
from src.ui.tray_icon import NexumiTray
from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("__main__")


def _check_ws_hub(host: str, port: int, timeout: float = 2.0) -> None:
    """
    Fire-and-forget probe that warns if the WebSocket hub is unreachable.
    This helps users who forgot to start the backend first.
    """

    async def _probe() -> None:
        import websockets
        uri = f"ws://{host}:{port}"
        try:
            async with websockets.connect(uri, open_timeout=timeout):
                log.info("WebSocket hub is reachable (%s)", uri)
        except Exception:
            log.warning(
                "WebSocket hub not detected at %s. "
                "Ensure the backend (websocket_server / hime_controller) is running.",
                uri,
            )

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_probe())
    except Exception as exc:
        log.debug("WS hub probe failed: %s", exc)
    finally:
        loop.close()


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="python -m src",
        description="Nexumi Desktop Companion — AI Assistant",
        epilog="Tip: Start the WebSocket server first with `python -m src.ui.websocket_server`",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable DEBUG level logging (very verbose)",
    )
    parser.add_argument(
        "--no-tray",
        action="store_true",
        help="Launch without the system tray icon (useful for testing / debugging)",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to an alternative settings.json file",
    )
    parser.add_argument(
        "--no-ws-check",
        action="store_true",
        help="Skip the WebSocket hub reachability probe on startup",
    )
    return parser.parse_args()


def main() -> None:
    """Application entry point."""
    args = _parse_args()

    if args.debug:
        # Targeted debug: only Nexumi modules, not all third-party libraries
        for name in ("__main__", "src", "src.ui", "src.core", "src.tools", "src.utils"):
            logging.getLogger(name).setLevel(logging.DEBUG)
        logging.getLogger("websockets").setLevel(logging.INFO)  # keep WS lib quiet
        log.debug("Debug logging enabled for Nexumi modules")

    app = QApplication(sys.argv)
    app.setApplicationName("Nexumi")
    app.setApplicationVersion("1.0.0")
    app.setQuitOnLastWindowClosed(False)

    cfg = load_settings(config_path=args.config)
    ws_cfg = cfg.get("websocket", {})

    if not args.no_ws_check:
        _check_ws_hub(ws_cfg.get("host", "localhost"), ws_cfg.get("port", 8765))

    # minimise-to-tray is only meaningful when the tray is active
    mate = DesktopMate(minimize_to_tray=not args.no_tray)

    tray: NexumiTray | None = None
    if not args.no_tray:
        tray = NexumiTray(
            on_show_hide=mate.toggle_visibility,
            on_open_chat=mate.open_chat,
            on_open_data=mate.open_data,
            on_mode=mate.send_mode,
            on_toggle_top=mate.toggle_always_on_top,
            on_reload_config=mate.reload_config,
            on_reload_viewer=mate.reload_viewer,
            on_quit=app.quit,
        )
        # Forward mood changes to the tray tooltip / icon
        mate.mood_changed.connect(
            lambda mood: tray.set_tooltip(mood) if tray else None
        )

    mate.show()

    def _on_quit() -> None:
        """Graceful shutdown hook — called when QApplication is about to quit."""
        log.info("Shutting down Nexumi...")
        mate.shutdown()
        if tray is not None:
            tray.shutdown()
        # Brief grace period for daemon threads to finish I/O
        import time
        time.sleep(0.15)

    app.aboutToQuit.connect(_on_quit)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
