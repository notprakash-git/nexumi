"""
src/ui/vrm_viewer.py

Embedded 3D VRM viewer for Nexumi using PyQt6 + QWebEngineView + Three.js.

Architecture
------------
1. Starts a local HTTP server on a configurable port to serve:
   - ``web/3d_viewer.html`` (the Three.js application)
   - ``assets/3d_model/nexumi.vrm`` (the VRM model)
   - Any other static assets under ``web/`` or ``assets/``
2. Creates a frameless, transparent, always-on-top PyQt6 window.
3. Loads the local HTML page into a QWebEngineView.
4. Handles window dragging via mouse events.
5. Connects to the shared WebSocket hub to receive emotion updates.
6. Configurable via ``settings.json`` under the ``vrm_viewer`` section.

Run standalone:  python -m src.ui.vrm_viewer
Run from hime_controller:  start_viewer_subprocess() launches this as a subprocess.
"""

import argparse
import os
import signal
import socket
import subprocess
import sys
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional

# ── Ensure project root on path ────────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(_PROJECT_ROOT))

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("vrm_viewer")

# ── Load configuration ─────────────────────────────────────────────────────
_SETTINGS = load_settings().get("vrm_viewer", {})

# Window
_WINDOW_WIDTH = _SETTINGS.get("window_width", 400)
_WINDOW_HEIGHT = _SETTINGS.get("window_height", 600)
_WINDOW_X = _SETTINGS.get("window_x", 100)
_WINDOW_Y = _SETTINGS.get("window_y", 100)
_OPACITY = _SETTINGS.get("opacity", 1.0)
_ALWAYS_ON_TOP = _SETTINGS.get("always_on_top", True)
_TRANSPARENT = _SETTINGS.get("transparent", True)
_DRAGGABLE = _SETTINGS.get("draggable", True)

# HTTP server
_HTTP_CFG = _SETTINGS.get("http_server", {})
_BIND_ADDRESS = _HTTP_CFG.get("bind_address", "127.0.0.1")
_HTTP_PORT = _HTTP_CFG.get("port", 0)

# WebSocket
_WS_HOST = _SETTINGS.get("websocket_host", "localhost")
_WS_PORT = _SETTINGS.get("websocket_port", 8765)

# VRM model
_VRM_MODEL_PATH = _SETTINGS.get("vrm_model_path", "assets/3d_model/nexumi.vrm")

# Camera
_CAMERA_CFG = _SETTINGS.get("camera", {})
_CAMERA_FOV = _CAMERA_CFG.get("fov", 30)
_CAMERA_POS_X = _CAMERA_CFG.get("position_x", 0)
_CAMERA_POS_Y = _CAMERA_CFG.get("position_y", 1.4)
_CAMERA_POS_Z = _CAMERA_CFG.get("position_z", 2.5)

# Lighting
_LIGHT_CFG = _SETTINGS.get("lighting", {})
_AMBIENT_INTENSITY = _LIGHT_CFG.get("ambient_intensity", 0.6)
_DIR_INTENSITY = _LIGHT_CFG.get("directional_intensity", 0.8)
_DIR_POS_X = _LIGHT_CFG.get("directional_position_x", 1)
_DIR_POS_Y = _LIGHT_CFG.get("directional_position_y", 2)
_DIR_POS_Z = _LIGHT_CFG.get("directional_position_z", 2)

# Animation
_ANIM_CFG = _SETTINGS.get("animation", {})
_IDLE_BREATHING = _ANIM_CFG.get("idle_breathing", True)
_BLINK_INTERVAL = _ANIM_CFG.get("blink_interval_ms", 4000)

# ── Paths ──────────────────────────────────────────────────────────────────
_WEB_DIR = _PROJECT_ROOT / "web"
_ASSETS_DIR = _PROJECT_ROOT / "assets"
_VRM_PATH = _PROJECT_ROOT / _VRM_MODEL_PATH

# ── Global server reference ────────────────────────────────────────────────
_http_server: Optional[ThreadingHTTPServer] = None
_server_port: int = 0


# =============================================================================
# Local HTTP server (serves web/ and assets/)
# =============================================================================
class _CORSRequestHandler(SimpleHTTPRequestHandler):
    """
    Custom handler that:
    - Serves files from ``web/`` (default) and ``assets/`` (via /assets/ prefix)
    - Adds CORS headers so Chromium (QWebEngineView) can load the VRM
    - Suppresses default request logging
    """

    def __init__(self, *args, **kwargs):
        # SimpleHTTPRequestHandler.__init__ signature is (request, client_address, server)
        # It does NOT accept a 'directory' kwarg. We set self.directory after super().
        super().__init__(*args, **kwargs)
        self.directory = str(_WEB_DIR)

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(200)
        self.end_headers()

    def translate_path(self, path: str) -> str:
        """
        Map ``/assets/...`` to the ``assets/`` directory and everything else
        to ``web/`` (via self.directory set in __init__).
        """
        if path.startswith("/assets/"):
            relative = path[len("/assets/") :]
            return str(_ASSETS_DIR / relative)
        return super().translate_path(path)

    def log_message(self, format: str, *args: Any) -> None:
        # Suppress noisy HTTP logs unless debug mode
        pass


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((_BIND_ADDRESS, 0))
        return int(s.getsockname()[1])


def _start_http_server(port: Optional[int] = None) -> int:
    global _http_server, _server_port
    chosen_port = port or _HTTP_PORT or _find_free_port()
    _http_server = ThreadingHTTPServer((_BIND_ADDRESS, chosen_port), _CORSRequestHandler)
    thread = threading.Thread(target=_http_server.serve_forever, daemon=True, name="VRMHTTPServer")
    thread.start()
    log.info(f"Local HTTP server started on http://{_BIND_ADDRESS}:{chosen_port}")
    _server_port = chosen_port
    return chosen_port


def _stop_http_server() -> None:
    global _http_server
    if _http_server:
        _http_server.shutdown()
        _http_server = None
        log.info("Local HTTP server stopped")


# =============================================================================
# PyQt6 VRM Viewer Window
# =============================================================================
class VRMViewerWindow:
    """
    Frameless, transparent, always-on-top PyQt6 window containing a
    QWebEngineView that renders the Three.js VRM viewer.
    """

    def __init__(self, http_port: int) -> None:
        self.http_port = http_port
        self._app: Optional[Any] = None
        self._window: Optional[Any] = None
        self._web_view: Optional[Any] = None
        self._drag_pos: Optional[Any] = None

    def _build_html(self) -> str:
        """
        Generate the Three.js VRM viewer HTML with all configuration values
        injected from settings.json.
        """
        vrm_url = f"http://{_BIND_ADDRESS}:{self.http_port}/{_VRM_MODEL_PATH}"

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Nexumi VRM Viewer</title>
<style>
  body, html {{ margin: 0; padding: 0; overflow: hidden; background: transparent; }}
  #canvas-container {{ width: 100vw; height: 100vh; }}
  #status {{ position: fixed; top: 8px; left: 8px; color: #fff; font-family: sans-serif;
             font-size: 12px; text-shadow: 0 1px 2px rgba(0,0,0,0.8); pointer-events: none; }}
  #error {{ position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%);
            color: #ff6b6b; font-family: sans-serif; font-size: 16px; text-align: center;
            display: none; }}
</style>
</head>
<body>
<div id="canvas-container"></div>
<div id="status">Loading…</div>
<div id="error">
  <div>⚠️ VRM model not found</div>
  <div style="font-size:12px;color:#ccc;">Expected: {_VRM_MODEL_PATH}</div>
  <div style="font-size:12px;color:#888;margin-top:8px;">Right-click → Reload to retry</div>
</div>

<script type="importmap">
{{
  "imports": {{
    "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
    "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/",
    "@pixiv/three-vrm": "https://unpkg.com/@pixiv/three-vrm@2.1.1/lib/three-vrm.module.js"
  }}
}}
</script>

<script type="module">
import * as THREE from 'three';
import {{ GLTFLoader }} from 'three/addons/loaders/GLTFLoader.js';
import {{ VRMLoaderPlugin, VRMUtils }} from '@pixiv/three-vrm';

const container = document.getElementById('canvas-container');
const statusEl = document.getElementById('status');
const errorEl = document.getElementById('error');

// Configuration from Python
const CONFIG = {{
  camera: {{
    fov: {_CAMERA_FOV},
    posX: {_CAMERA_POS_X},
    posY: {_CAMERA_POS_Y},
    posZ: {_CAMERA_POS_Z}
  }},
  lighting: {{
    ambientIntensity: {_AMBIENT_INTENSITY},
    dirIntensity: {_DIR_INTENSITY},
    dirPosX: {_DIR_POS_X},
    dirPosY: {_DIR_POS_Y},
    dirPosZ: {_DIR_POS_Z}
  }},
  animation: {{
    idleBreathing: {_IDLE_BREATHING},
    blinkInterval: {_BLINK_INTERVAL}
  }},
  vrmUrl: '{vrm_url}',
  wsUri: 'ws://{_WS_HOST}:{_WS_PORT}'
}};

// Scene setup
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(
  CONFIG.camera.fov,
  window.innerWidth / window.innerHeight,
  0.1, 20
);
camera.position.set(CONFIG.camera.posX, CONFIG.camera.posY, CONFIG.camera.posZ);

const renderer = new THREE.WebGLRenderer({{ alpha: true, antialias: true }});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
container.appendChild(renderer.domElement);

// Lighting
const ambient = new THREE.AmbientLight(0xffffff, CONFIG.lighting.ambientIntensity);
scene.add(ambient);
const dirLight = new THREE.DirectionalLight(0xffffff, CONFIG.lighting.dirIntensity);
dirLight.position.set(CONFIG.lighting.dirPosX, CONFIG.lighting.dirPosY, CONFIG.lighting.dirPosZ);
scene.add(dirLight);

let currentVrm = null;
let blendShapeProxy = null;
let blinkTimer = null;
let breathingId = null;

// Load VRM
const loader = new GLTFLoader();
loader.register(parser => new VRMLoaderPlugin(parser));

function loadVrm() {{
  loader.load(CONFIG.vrmUrl, (gltf) => {{
    const vrm = gltf.userData.vrm;
    VRMUtils.removeUnnecessaryVertices(vrm.scene);
    VRMUtils.removeUnnecessaryJoints(vrm.scene);
    scene.add(vrm.scene);
    currentVrm = vrm;
    blendShapeProxy = vrm.expressionManager;
    statusEl.textContent = 'Connected';
    statusEl.style.display = 'block';
    errorEl.style.display = 'none';
    console.log('VRM loaded:', vrm.meta.name);

    if (CONFIG.animation.idleBreathing) {{
      startIdleBreathing();
    }}
    if (CONFIG.animation.blinkInterval > 0) {{
      startBlinking();
    }}
  }}, undefined, (err) => {{
    console.error('VRM load error:', err);
    statusEl.style.display = 'none';
    errorEl.style.display = 'block';
  }});
}}

loadVrm();

// Animation loop
const clock = new THREE.Clock();
function animate() {{
  requestAnimationFrame(animate);
  const delta = clock.getDelta();
  if (currentVrm) {{
    currentVrm.update(delta);
  }}
  renderer.render(scene, camera);
}}
animate();

// Resize handler
window.addEventListener('resize', () => {{
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}});

// Idle breathing — subtle chest expansion (y-axis translation + slight rotation)
function startIdleBreathing() {{
  const baseY = currentVrm ? currentVrm.scene.position.y : 0;
  function breathe() {{
    if (!currentVrm) return;
    breathingId = requestAnimationFrame(breathe);
    const t = performance.now() * 0.001;
    currentVrm.scene.position.y = baseY + Math.sin(t * 1.5) * 0.008;
    currentVrm.scene.rotation.x = Math.sin(t * 1.2) * 0.01;
  }}
  breathe();
}}

// Blinking — requestAnimationFrame-based to avoid setTimeout accumulation
function startBlinking() {{
  let lastBlink = 0;
  let nextInterval = CONFIG.animation.blinkInterval;
  function blinkLoop(now) {{
    if (!blendShapeProxy) {{
      blinkTimer = requestAnimationFrame(blinkLoop);
      return;
    }}
    if (now - lastBlink > nextInterval) {{
      lastBlink = now;
      nextInterval = CONFIG.animation.blinkInterval + Math.random() * 1000;
      blendShapeProxy.setValue('blink', 1.0);
      blendShapeProxy.update();
      setTimeout(() => {{
        if (blendShapeProxy) {{
          blendShapeProxy.setValue('blink', 0.0);
          blendShapeProxy.update();
        }}
      }}, 150);
    }}
    blinkTimer = requestAnimationFrame(blinkLoop);
  }}
  blinkTimer = requestAnimationFrame(blinkLoop);
}}

// WebSocket connection
let ws = null;
let reconnectTimer = null;

function connectWS() {{
  ws = new WebSocket(CONFIG.wsUri);

  ws.onopen = () => {{
    console.log('WS connected to', CONFIG.wsUri);
    statusEl.textContent = 'Live';
    statusEl.style.color = '#69db7c';
  }};

  ws.onmessage = (event) => {{
    try {{
      const msg = JSON.parse(event.data);
      if (msg.type === 'emotion' && blendShapeProxy && msg.blend_shapes) {{
        for (const [name, weight] of Object.entries(msg.blend_shapes)) {{
          blendShapeProxy.setValue(name, weight);
        }}
        blendShapeProxy.update();
        console.log('Expression applied:', msg.emotion);
      }}
      if (msg.type === 'tts_start') {{
        if (blendShapeProxy) blendShapeProxy.setValue('aa', 0.6);
      }}
      if (msg.type === 'tts_end') {{
        if (blendShapeProxy) blendShapeProxy.setValue('aa', 0.0);
      }}
    }} catch (e) {{
      console.error('WS message error:', e);
    }}
  }};

  ws.onclose = () => {{
    console.warn('WS disconnected — retrying in 2s');
    statusEl.textContent = 'Reconnecting…';
    statusEl.style.color = '#ffd43b';
    reconnectTimer = setTimeout(connectWS, 2000);
  }};

  ws.onerror = (err) => {{
    console.error('WS error:', err);
  }};
}}

connectWS();

// Right-click reload handler
window.addEventListener('contextmenu', (e) => {{
  e.preventDefault();
  if (confirm('Reload VRM model?')) {{
    if (currentVrm) {{
      scene.remove(currentVrm.scene);
      currentVrm = null;
      blendShapeProxy = null;
      if (breathingId) cancelAnimationFrame(breathingId);
      if (blinkTimer) cancelAnimationFrame(blinkTimer);
    }}
    statusEl.textContent = 'Reloading…';
    statusEl.style.display = 'block';
    errorEl.style.display = 'none';
    loadVrm();
  }}
}});

// Cleanup
window.addEventListener('beforeunload', () => {{
  if (reconnectTimer) clearTimeout(reconnectTimer);
  if (blinkTimer) cancelAnimationFrame(blinkTimer);
  if (breathingId) cancelAnimationFrame(breathingId);
  if (ws) ws.close();
}});
</script>
</body>
</html>"""

    def _ensure_html(self) -> None:
        """Create ``web/3d_viewer.html`` if it doesn't exist."""
        _WEB_DIR.mkdir(parents=True, exist_ok=True)
        html_path = _WEB_DIR / "3d_viewer.html"
        if not html_path.exists():
            log.info("Generating default 3d_viewer.html from settings")
            with open(html_path, "w", encoding="utf-8") as f:
                f.write(self._build_html())

    def show(self) -> None:
        try:
            from PyQt6.QtCore import QUrl, Qt
            from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout
            from PyQt6.QtWebEngineWidgets import QWebEngineView
        except ImportError as exc:
            log.error(f"PyQt6 or PyQt6-WebEngine not installed: {exc}")
            log.error("Install with: pip install PyQt6 PyQt6-WebEngine")
            sys.exit(1)

        self._ensure_html()

        self._app = QApplication(sys.argv)

        # Build window flags from configuration
        flags = Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
        if _ALWAYS_ON_TOP:
            flags |= Qt.WindowType.WindowStaysOnTopHint

        self._window = QWidget()
        self._window.setWindowFlags(flags)

        if _TRANSPARENT:
            self._window.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self._window.setGeometry(_WINDOW_X, _WINDOW_Y, _WINDOW_WIDTH, _WINDOW_HEIGHT)
        self._window.setWindowOpacity(_OPACITY)

        # Web view fills the window
        layout = QVBoxLayout(self._window)
        layout.setContentsMargins(0, 0, 0, 0)
        self._web_view = QWebEngineView()
        self._web_view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._web_view.page().setBackgroundColor(Qt.GlobalColor.transparent)
        layout.addWidget(self._web_view)

        url = QUrl(f"http://{_BIND_ADDRESS}:{self.http_port}/3d_viewer.html")
        self._web_view.setUrl(url)

        # Dragging support (configurable)
        if _DRAGGABLE:
            self._window.mousePressEvent = self._on_mouse_press
            self._window.mouseMoveEvent = self._on_mouse_move

        self._window.show()
        log.info(
            f"VRM viewer window shown at ({_WINDOW_X}, {_WINDOW_Y}) "
            f"{_WINDOW_WIDTH}x{_WINDOW_HEIGHT} "
            f"(always_on_top={_ALWAYS_ON_TOP}, transparent={_TRANSPARENT}, "
            f"draggable={_DRAGGABLE})"
        )

        # Graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        sys.exit(self._app.exec())

    def _on_mouse_press(self, event: Any) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint() - self._window.frameGeometry().topLeft()
            event.accept()

    def _on_mouse_move(self, event: Any) -> None:
        if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos is not None:
            self._window.move(event.globalPosition().toPoint() - self._drag_pos)
            event.accept()

    def _signal_handler(self, signum: int, _frame: Any) -> None:
        log.info(f"VRM viewer received signal {signum}, exiting…")
        self._cleanup()
        sys.exit(0)

    def _cleanup(self) -> None:
        _stop_http_server()
        if self._app:
            self._app.quit()


# =============================================================================
# Entry points
# =============================================================================
def start_viewer_subprocess() -> subprocess.Popen:
    """Launch the viewer as a detached subprocess (used by hime_controller)."""
    python = sys.executable
    cmd = [python, "-m", "src.ui.vrm_viewer", "--subprocess"]
    log.info(f"Launching VRM viewer subprocess: {' '.join(cmd)}")
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def run_standalone() -> None:
    """Main entry point when run directly."""
    parser = argparse.ArgumentParser(description="Nexumi VRM Viewer")
    parser.add_argument("--port", type=int, default=0, help="HTTP server port (0 = auto)")
    parser.add_argument("--subprocess", action="store_true", help="Internal flag")
    args = parser.parse_args()

    port = _start_http_server(args.port if args.port else None)
    viewer = VRMViewerWindow(port)
    viewer.show()


if __name__ == "__main__":
    run_standalone()
