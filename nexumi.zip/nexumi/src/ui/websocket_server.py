"""
src/ui/websocket_server.py

Central WebSocket hub — all Nexumi components connect here.

Message flow
------------
  wake_word_detected  ->  STT  ->  router  ->  handler  ->  TTS + emotion
  user_text / user_speech         (same pipeline, no STT step)
  ping                ->  pong
  menu_action         ->  mood change + ack broadcast
  request_metrics     ->  metrics snapshot (admin only)

All downstream imports (brain, tts, hime_controller, etc.) are done
lazily inside the pipeline so that:
  a) The server starts instantly — no 30-second LLM load at boot.
  b) Missing optional dependencies (e.g. hime) do not crash the server.

Requires: websockets==12.x, python-dotenv
Python  : 3.10+
Run as  : python -m src.ui.websocket_server
"""

import asyncio
import json
import os
import signal
import sys
import time
import traceback
import weakref
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ── Make sure project root is on sys.path when run directly ───────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import websockets
from websockets.server import ServerConnection
from dotenv import load_dotenv

from src.utils.logger import get_logger
from src.utils.settings import load_settings

_env_path = Path(__file__).resolve().parent.parent.parent / "config" / "api_keys.env"
load_dotenv(_env_path)

log = get_logger("ws_server")

# ── Config ────────────────────────────────────────────────────────────────────
try:
    _cfg = load_settings()
except RuntimeError as e:
    print(f"[FATAL] {e}", file=sys.stderr)
    sys.exit(1)

_ws_cfg = _cfg.get("websocket_server", {})
HOST            = _ws_cfg.get("host", "localhost")
PORT            = int(_ws_cfg.get("port", 8765))
HEALTH_PORT     = int(_ws_cfg.get("health_port", 8766))
MAX_MSG_SIZE    = int(_ws_cfg.get("max_message_size", 65536))
PING_INTERVAL   = int(_ws_cfg.get("ping_interval", 20))
PING_TIMEOUT    = int(_ws_cfg.get("ping_timeout", 30))
STT_TIMEOUT     = int(_ws_cfg.get("stt_timeout", 5))
TTS_TIMEOUT     = int(_ws_cfg.get("tts_timeout", 10))
BRAIN_TIMEOUT   = int(_ws_cfg.get("brain_timeout", 15))

_metrics_cfg    = _ws_cfg.get("metrics", {})
METRICS_ENABLED = _metrics_cfg.get("enabled", True)
METRICS_INTERVAL= int(_metrics_cfg.get("interval_sec", 60))
METRICS_PATH    = _metrics_cfg.get("path", "logs/ws_metrics.jsonl")

_rate_cfg       = _ws_cfg.get("rate_limit", {})
RATE_ENABLED    = _rate_cfg.get("enabled", True)
RATE_MSGS       = int(_rate_cfg.get("messages", 30))
RATE_WINDOW     = float(_rate_cfg.get("window_sec", 10.0))
RATE_BURST      = int(_rate_cfg.get("burst", 5))

# ── State ─────────────────────────────────────────────────────────────────────
_clients: set[ServerConnection] = set()
_shutdown_event = asyncio.Event()
_shutdown_once = False
_active_tasks: weakref.WeakSet = weakref.WeakSet()


# =============================================================================
# Rate limiter (token bucket per connection)
# =============================================================================
class _RateLimiter:
    """Async-safe token bucket."""

    def __init__(self, rate: float, per: float, burst: int) -> None:
        self._rate = float(rate)
        self._per = float(per)
        self._max_tokens = float(burst)
        self._tokens = float(burst)
        self._last = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> bool:
        if not RATE_ENABLED:
            return True
        async with self._lock:
            now = time.monotonic()
            delta = now - self._last
            self._tokens += delta * (self._rate / self._per)
            if self._tokens > self._max_tokens:
                self._tokens = self._max_tokens
            self._last = now
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            return False


# =============================================================================
# Metrics
# =============================================================================
class Metrics:
    """Lightweight async-safe metrics collector with bounded memory."""

    def __init__(
        self,
        enabled: bool,
        interval_sec: int,
        path: str,
        rotate_bytes: int = 5 * 1024 * 1024,
    ) -> None:
        self._enabled = enabled
        self._interval_sec = interval_sec
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._rotate_bytes = rotate_bytes

        self._current_clients = 0
        self._peak_clients = 0
        self._msg_counts: defaultdict[str, int] = defaultdict(int)
        self._latencies: defaultdict[str, list[float]] = defaultdict(list)
        self._error_counts: defaultdict[str, int] = defaultdict(int)

        self._flush_task: asyncio.Task | None = None

    # ── Recording ───────────────────────────────────────────────────────────
    def record_connection(self) -> None:
        if not self._enabled:
            return
        self._current_clients += 1
        if self._current_clients > self._peak_clients:
            self._peak_clients = self._current_clients

    def record_disconnection(self) -> None:
        if not self._enabled:
            return
        self._current_clients = max(0, self._current_clients - 1)

    def record_msg_type(self, msg_type: str) -> None:
        if not self._enabled:
            return
        self._msg_counts[msg_type] += 1

    def record_latency(self, stage: str, duration: float) -> None:
        if not self._enabled:
            return
        self._latencies[stage].append(duration)

    def record_error(self, intent: str) -> None:
        if not self._enabled:
            return
        self._error_counts[intent] += 1

    # ── Snapshot ────────────────────────────────────────────────────────────
    def snapshot(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "clients": {
                "current": self._current_clients,
                "peak": self._peak_clients,
            },
            "messages": dict(self._msg_counts),
            "errors": dict(self._error_counts),
            "latencies": {},
        }
        for stage, values in self._latencies.items():
            if values:
                result["latencies"][stage] = {
                    "count": len(values),
                    "avg_ms": round(sum(values) / len(values) * 1000, 2),
                    "max_ms": round(max(values) * 1000, 2),
                }
        return result

    # ── Lifecycle ───────────────────────────────────────────────────────────
    async def start(self) -> None:
        if not self._enabled:
            return
        self._flush_task = asyncio.create_task(self._flush_loop())

    async def stop(self) -> None:
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
        await self._flush()

    async def _flush_loop(self) -> None:
        while True:
            await asyncio.sleep(self._interval_sec)
            await self._flush()

    async def _flush(self) -> None:
        if not self._enabled:
            return
        snap = self.snapshot()
        line = json.dumps(snap, default=str)
        try:
            if self._path.exists() and self._path.stat().st_size > self._rotate_bytes:
                archive = self._path.with_suffix(
                    f".jsonl.{datetime.now(timezone.utc):%Y%m%d_%H%M%S}"
                )
                self._path.rename(archive)
            with open(self._path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            # Reset latencies to prevent unbounded memory growth
            self._latencies.clear()
        except Exception as exc:
            log.error("Metrics flush failed: %s", exc)


# Global metrics instance (populated in main)
metrics = Metrics(False, 60, "logs/ws_metrics.jsonl")


# =============================================================================
# Broadcast
# =============================================================================
async def _broadcast(message: dict) -> None:
    """Send a JSON message to every connected client. Skips dead connections."""
    if not _clients:
        return
    payload = json.dumps(message)
    results = await asyncio.gather(
        *[c.send(payload) for c in list(_clients)],
        return_exceptions=True,
    )
    for result in results:
        if isinstance(result, Exception):
            log.debug("Broadcast send error (client already gone): %s", result)


# =============================================================================
# Task helpers
# =============================================================================
def _spawn(coro) -> asyncio.Task:
    """Create a tracked task that is automatically removed when done."""
    task = asyncio.create_task(coro)
    _active_tasks.add(task)

    def _remove(t: asyncio.Task) -> None:
        _active_tasks.discard(t)

    task.add_done_callback(_remove)
    return task


# =============================================================================
# Pipeline: wake word detected
# =============================================================================
async def _handle_wake_word() -> None:
    """Run STT then hand off to the main pipeline."""
    metrics.record_msg_type("wake_word_detected")
    log.info("Wake word detected — starting STT")
    await _broadcast({"type": "status", "message": "Listening..."})

    loop = asyncio.get_running_loop()
    t0 = time.monotonic()
    try:
        from src.core.stt import listen_once
        text = await asyncio.wait_for(
            loop.run_in_executor(None, listen_once),
            timeout=STT_TIMEOUT,
        )
        metrics.record_latency("stt", time.monotonic() - t0)
    except asyncio.TimeoutError:
        log.warning("STT timed out after %ds", STT_TIMEOUT)
        await _broadcast({"type": "status", "message": "Listening timed out."})
        metrics.record_error("stt_timeout")
        return
    except Exception as exc:
        log.error("STT error: %s", exc)
        await _broadcast({"type": "status", "message": "STT error — check logs."})
        metrics.record_error("stt")
        return

    if not text:
        log.info("STT returned nothing")
        await _broadcast({"type": "status", "message": "I did not catch that."})
        return

    await _process_text(text)


# =============================================================================
# Pipeline: route → respond → speak → express
# =============================================================================
async def _process_text(text: str) -> None:
    """
    Full response pipeline.
    Every stage is individually try/excepted so a failure in one stage
    (e.g. TTS network down) does not prevent the text response reaching
    the chat panel.
    """
    metrics.record_msg_type("process_text")
    log.info("User: %r", text)
    await _broadcast({"type": "user_message", "text": text})

    loop = asyncio.get_running_loop()

    # ── Routing ─────────────────────────────────────────────────────────
    t0 = time.monotonic()
    from src.utils.router import route
    intent = route(text)
    metrics.record_latency("routing", time.monotonic() - t0)
    log.info("Intent: %s", intent)

    # ── Brain / Tools ─────────────────────────────────────────────────────
    t0 = time.monotonic()
    try:
        response = await asyncio.wait_for(
            _dispatch(intent, text, loop),
            timeout=BRAIN_TIMEOUT,
        )
        metrics.record_latency("brain", time.monotonic() - t0)
    except asyncio.TimeoutError:
        log.warning("Brain dispatch timed out after %ds", BRAIN_TIMEOUT)
        response = "I am taking too long to think. Could you try again?"
        metrics.record_error("brain_timeout")
    except Exception as exc:
        log.error("Brain dispatch error: %s", exc)
        response = "Something went wrong on my end. Check the logs."
        metrics.record_error("brain")

    if not response:
        response = "I am not sure what to do with that. Could you rephrase?"

    log.info("Nexumi: %r", response[:100])

    # ── Emotion ─────────────────────────────────────────────────────────
    emotion = "neutral"
    try:
        from src.integration.emotion_selector import select_emotion
        emotion, _ = select_emotion(user_text=text, ai_text=response)
    except Exception as exc:
        log.warning("Emotion selector error: %s", exc)

    # ── TTS ───────────────────────────────────────────────────────────────
    t0 = time.monotonic()
    try:
        from src.core.tts import speak
        await asyncio.wait_for(
            loop.run_in_executor(None, lambda: speak(response, emotion=emotion)),
            timeout=TTS_TIMEOUT,
        )
        metrics.record_latency("tts", time.monotonic() - t0)
    except asyncio.TimeoutError:
        log.warning("TTS timed out after %ds", TTS_TIMEOUT)
        metrics.record_error("tts_timeout")
    except Exception as exc:
        log.error("TTS error: %s", exc)
        metrics.record_error("tts")

    # ── Expression (non-fatal — 3D model may not be set up yet) ─────────
    t0 = time.monotonic()
    try:
        from src.integration.hime_controller import apply_expression
        await asyncio.wait_for(
            loop.run_in_executor(
                None, lambda: apply_expression(emotion, duration=4.0)
            ),
            timeout=5.0,
        )
        metrics.record_latency("expression", time.monotonic() - t0)
    except Exception as exc:
        log.debug("Expression error (non-fatal): %s", exc)

    # ── Broadcast final response to all UIs ─────────────────────────────
    await _broadcast({
        "type": "ai_message",
        "text": response,
        "emotion": emotion,
    })


async def _dispatch(intent: str, text: str, loop: asyncio.AbstractEventLoop) -> str:
    """
    Call the correct handler for the given intent.
    Returns a plain-text response string.
    All handlers are individually guarded so one failing doesn't crash the server.
    """
    try:
        if intent == "search":
            from src.tools.websearch import search, format_results
            from src.utils.router import extract_search_query
            query = extract_search_query(text)
            results = await loop.run_in_executor(None, lambda: search(query))
            return format_results(results)

        elif intent == "desktop_open":
            from src.tools.desktop import open_app
            import re
            m = re.search(r"\b(?:open|launch|start)\s+(.+)", text, re.IGNORECASE)
            app = m.group(1).strip() if m else text
            return await loop.run_in_executor(None, lambda: open_app(app))

        elif intent == "desktop_click":
            from src.tools.desktop import click_text
            import re
            m = re.search(r"\bclick (?:on |the )?(.+)", text, re.IGNORECASE)
            target = m.group(1).strip() if m else text
            return await loop.run_in_executor(None, lambda: click_text(target))

        elif intent == "desktop_type":
            from src.tools.desktop import type_text
            import re
            m = re.search(r"\btype\s+(?:out\s+|in\s+|this\s+)?(.+)", text, re.IGNORECASE)
            content = m.group(1).strip() if m else text
            return await loop.run_in_executor(None, lambda: type_text(content))

        elif intent == "desktop_scroll":
            from src.tools.desktop import scroll
            amount = -3 if "down" in text.lower() else 3
            return await loop.run_in_executor(None, lambda: scroll(amount))

        elif intent == "screenshot":
            from src.tools.screenshot import capture, describe
            path = await loop.run_in_executor(None, capture)
            return describe(path)

        elif intent == "memory_store":
            from src.core.brain import get_brain
            from src.utils.router import extract_fact
            fact = extract_fact(text)
            await loop.run_in_executor(None, lambda: get_brain().remember_fact(fact))
            await _broadcast({"type": "memory_updated"})
            return f"Got it, I will remember that: '{fact}'."

        elif intent == "memory_query":
            from src.core.brain import get_brain
            facts = await loop.run_in_executor(None, get_brain().recall_facts)
            if facts:
                items = "; ".join(f["fact_text"] for f in facts[:5])
                return f"Here is what I know about you: {items}."
            return "I do not have any memories stored yet. Tell me something about yourself."

        else:  # chat
            from src.core.brain import get_brain
            return await loop.run_in_executor(
                None, lambda: get_brain().respond(text)
            )

    except Exception:
        log.error("Dispatch error for intent '%s':\n%s", intent, traceback.format_exc())
        metrics.record_error(intent)
        return "Something went wrong on my end. Check the logs."


# =============================================================================
# Health check (simple HTTP)
# =============================================================================
async def _health_handler(
    reader: asyncio.StreamReader, writer: asyncio.StreamWriter
) -> None:
    """Minimal HTTP/1.1 health endpoint."""
    try:
        data = await reader.read(1024)
        if not data:
            return
        body = json.dumps({"status": "ok", "clients": metrics._current_clients})
        response = (
            f"HTTP/1.1 200 OK\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Connection: close\r\n"
            f"\r\n"
            f"{body}"
        )
        writer.write(response.encode())
        await writer.drain()
    except Exception as exc:
        log.debug("Health handler error: %s", exc)
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass


# =============================================================================
# WebSocket connection handler
# =============================================================================
async def handler(websocket: ServerConnection) -> None:
    addr = websocket.remote_address
    _clients.add(websocket)
    metrics.record_connection()
    limiter = _RateLimiter(RATE_MSGS, RATE_WINDOW, RATE_BURST)
    log.info("Client connected: %s  (total: %d)", addr, len(_clients))

    try:
        async for raw in websocket:
            # ── Rate limit ─────────────────────────────────────────────
            if not await limiter.acquire():
                log.warning("Rate limit exceeded from %s", addr)
                await websocket.send(
                    json.dumps({"type": "error", "message": "Rate limit exceeded"})
                )
                continue

            # ── Parse ──────────────────────────────────────────────────
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                log.warning("Invalid JSON from %s: %s", addr, str(raw)[:80])
                continue

            msg_type = msg.get("type", "")
            log.debug("Message [%s] from %s", msg_type, addr)
            metrics.record_msg_type(msg_type)

            # ── Dispatch message types ─────────────────────────────────
            if msg_type == "wake_word_detected":
                _spawn(_handle_wake_word())

            elif msg_type in ("user_text", "user_speech"):
                text = msg.get("text", "").strip()
                if text:
                    _spawn(_process_text(text))
                else:
                    log.warning("Empty text in %s message", msg_type)

            elif msg_type == "menu_action":
                action = msg.get("action", "")
                try:
                    from src.core.brain import get_brain
                    brain = get_brain()
                    if action == "mode_normal":
                        brain.set_mood("normal")
                        log.info("Mood set to: normal")
                    elif action == "mode_flirty":
                        brain.set_mood("flirty")
                        log.info("Mood set to: flirty")
                except Exception as exc:
                    log.error("menu_action error: %s", exc)
                await _broadcast({"type": "menu_ack", "action": action})

            elif msg_type == "ping":
                await websocket.send(json.dumps({"type": "pong"}))

            elif msg_type == "request_metrics":
                await websocket.send(
                    json.dumps({"type": "metrics", "data": metrics.snapshot()})
                )

            else:
                log.debug("Unknown message type: %r", msg_type)

    except websockets.exceptions.ConnectionClosedOK:
        pass
    except websockets.exceptions.ConnectionClosedError as exc:
        log.debug("Connection closed with error from %s: %s", addr, exc)
    except Exception:
        log.error("Unhandled error in handler for %s:\n%s", addr, traceback.format_exc())
    finally:
        _clients.discard(websocket)
        metrics.record_disconnection()
        log.info("Client disconnected: %s  (total: %d)", addr, len(_clients))


# =============================================================================
# Graceful shutdown
# =============================================================================
async def _shutdown(
    ws_server,
    health_server,
) -> None:
    """Close connections, flush metrics, cancel in-flight tasks, and exit."""
    global _shutdown_once
    if _shutdown_once:
        return
    _shutdown_once = True
    log.info("Shutdown initiated — closing servers...")

    # 1. Stop accepting new WS connections
    ws_server.close()
    await ws_server.wait_closed()

    # 2. Stop health server
    health_server.close()
    await health_server.wait_closed()

    # 3. Notify clients
    if _clients:
        await _broadcast({"type": "goodbye", "message": "Server shutting down"})
        await asyncio.sleep(0.5)
        for c in list(_clients):
            try:
                await c.close()
            except Exception as exc:
                log.debug("Error closing client during shutdown: %s", exc)

    # 4. Cancel in-flight tasks
    pending = [t for t in _active_tasks if not t.done()]
    if pending:
        log.info("Cancelling %d in-flight task(s)...", len(pending))
        for task in pending:
            task.cancel()
        done, still_pending = await asyncio.wait(pending, timeout=5.0)
        if still_pending:
            log.warning(
                "%d task(s) did not finish in time — forcing exit",
                len(still_pending),
            )

    # 5. Flush metrics
    await metrics.stop()

    log.info("Shutdown complete")


# =============================================================================
# Entry point
# =============================================================================
async def main() -> None:
    global metrics
    metrics = Metrics(
        enabled=METRICS_ENABLED,
        interval_sec=METRICS_INTERVAL,
        path=METRICS_PATH,
    )
    await metrics.start()

    log.info("WebSocket server starting on ws://%s:%d", HOST, PORT)
    log.info("Health check on http://%s:%d", HOST, HEALTH_PORT)

    ws_server = await websockets.serve(
        handler,
        HOST,
        PORT,
        max_size=MAX_MSG_SIZE,
        ping_interval=PING_INTERVAL,
        ping_timeout=PING_TIMEOUT,
    )

    health_server = await asyncio.start_server(
        _health_handler,
        HOST,
        HEALTH_PORT,
    )

    # Signal handling
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _shutdown_event.set)
        except NotImplementedError:
            log.debug("Signal %s not supported on this platform", sig.name)

    log.info("Server ready — waiting for connections")

    # Wait for shutdown signal
    await _shutdown_event.wait()
    await _shutdown(ws_server, health_server)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("WebSocket server stopped by user")
