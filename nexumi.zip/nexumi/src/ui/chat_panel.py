"""
src/ui/chat_panel.py

Chat history window — PyQt6.

Key design decisions
--------------------
- Signals defined on a dedicated _ChatBus QObject — thread-safe queued delivery
- Single persistent asyncio loop on a daemon thread for the WS listener.
  The loop uses ``asyncio.wait_for(ws.recv(), timeout=1.0)`` so a ``closeEvent``
  can shut it down within ~1 s instead of hanging on ``async for``.
- Outgoing messages are fire-and-forget coroutines scheduled on the same loop.
- History saves happen on the GUI thread (file I/O is fast enough for JSON).
- Scroll-to-bottom only happens when the user is already at the bottom.
- Typing indicators: user typing debounces a WS ``typing`` message; a 2 s
  response timer shows a "thinking" label if Nexumi is slow to answer.
- Search re-renders the visible history with highlighted matches.
"""

import asyncio
import json
import re
import threading
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import Qt, pyqtSignal, QObject, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QTextEdit, QLineEdit, QPushButton,
    QMessageBox, QFileDialog,
)
from PyQt6.QtGui import QFont

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("chat_panel")
_cfg = load_settings()
_ws_cfg = _cfg.get("websocket", {})

WS_URI = f"ws://{_ws_cfg.get('host', 'localhost')}:{_ws_cfg.get('port', 8765)}"
HISTORY_FILE = Path(__file__).resolve().parent.parent.parent / "data" / "chat_history.json"

# ── Stylesheet ────────────────────────────────────────────────────────────────
_SS = """
    QWidget {
        background: #0b061e; color: #eac8ff;
        font-family: 'Noto Sans', sans-serif;
    }
    QTextEdit {
        background: #130930; border: 1px solid #3d1870;
        border-radius: 8px; padding: 8px; font-size: 12px;
        selection-background-color: #4a1890;
    }
    QLineEdit {
        background: #130930; border: 1px solid #5a28a0;
        border-radius: 8px; padding: 8px 12px;
        color: #eac8ff; font-size: 12px;
    }
    QLineEdit:focus { border-color: #8848d0; }
    QPushButton {
        background: #5a28a0; color: #fff;
        border-radius: 8px; padding: 8px 18px;
        font-size: 12px; font-weight: bold;
    }
    QPushButton:hover    { background: #7038c0; }
    QPushButton:pressed  { background: #3d1880; }
    QPushButton#clear    { background: #2a1050; color: #a080d0; }
    QPushButton#clear:hover { background: #3d1870; }
"""


# =============================================================================
# Signal bus
# =============================================================================
class _ChatBus(QObject):
    """Thread-safe signal bus for cross-thread communication."""

    msg_received = pyqtSignal(str, str)   # (role, text)
    mood_changed = pyqtSignal(str)        # action string


# =============================================================================
# ChatPanel
# =============================================================================
class ChatPanel(QWidget):
    """Persistent chat history window with WebSocket integration."""

    def __init__(self) -> None:
        super().__init__()
        self._history: list[dict] = self._load_history()
        self._bus = _ChatBus()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._stop_event = asyncio.Event()

        # Typing / response timers
        self._typing_debounce = QTimer(self)
        self._typing_debounce.setSingleShot(True)
        self._typing_debounce.timeout.connect(self._send_typing_ws)

        self._response_timer = QTimer(self)
        self._response_timer.setSingleShot(True)
        self._response_timer.timeout.connect(self._show_thinking)

        self._bus.msg_received.connect(self._append_message)
        self._bus.mood_changed.connect(self._on_mood_changed)

        self._build_ui()
        self._start_listener()
        self._render_history()

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        self.setWindowTitle("Nexumi — Chat")
        self.setMinimumSize(460, 640)
        self.setStyleSheet(_SS)

        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        layout.setContentsMargins(12, 12, 12, 12)

        # Title row
        title_row = QHBoxLayout()
        title = QLabel("Nexumi Chat")
        title.setFont(QFont("Noto Sans", 14, QFont.Weight.Bold))
        title.setStyleSheet("color:#ff9ec4;")
        title_row.addWidget(title)
        title_row.addStretch()
        self._mood_label = QLabel("Normal mode")
        self._mood_label.setStyleSheet("color:#8858b8; font-size:11px;")
        title_row.addWidget(self._mood_label)
        layout.addLayout(title_row)

        # Search
        self._search = QLineEdit()
        self._search.setPlaceholderText("Search messages…")
        self._search.textChanged.connect(self._on_search)
        layout.addWidget(self._search)

        # Chat view
        self._view = QTextEdit()
        self._view.setReadOnly(True)
        self._view.setFont(QFont("Noto Sans", 11))
        layout.addWidget(self._view, stretch=1)

        # Thinking indicator
        self._thinking_label = QLabel("")
        self._thinking_label.setStyleSheet("color:#ff9ec4; font-size:11px; font-style:italic;")
        self._thinking_label.hide()
        layout.addWidget(self._thinking_label)

        # Input row
        row = QHBoxLayout()
        row.setSpacing(6)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Type a message and press Enter…")
        self._input.returnPressed.connect(self._send)
        self._input.textChanged.connect(self._on_input_changed)
        row.addWidget(self._input, stretch=1)

        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self._send)
        row.addWidget(send_btn)

        export_btn = QPushButton("Export")
        export_btn.clicked.connect(self._export_history)
        row.addWidget(export_btn)

        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("clear")
        clear_btn.clicked.connect(self._clear_view)
        row.addWidget(clear_btn)

        clear_hist_btn = QPushButton("Clear History")
        clear_hist_btn.setObjectName("clear")
        clear_hist_btn.clicked.connect(self._clear_history)
        row.addWidget(clear_hist_btn)

        layout.addLayout(row)

    # ── WS listener (persistent loop with graceful shutdown) ─────────────────
    def _start_listener(self) -> None:
        self._loop = asyncio.new_event_loop()
        threading.Thread(
            target=self._run_loop,
            daemon=True, name="Chat-WsListener",
        ).start()

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._listen())

    async def _listen(self) -> None:
        import websockets
        while not self._stop_event.is_set():
            try:
                async with websockets.connect(WS_URI, open_timeout=5) as ws:
                    log.info("ChatPanel WS connected")
                    while not self._stop_event.is_set():
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                        except asyncio.TimeoutError:
                            continue
                        except websockets.exceptions.ConnectionClosed:
                            break
                        self._dispatch(raw)
            except Exception as exc:
                if not self._stop_event.is_set():
                    log.debug("ChatPanel WS: %r — retry in 3s", exc)
                    await asyncio.sleep(3)

    def _dispatch(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
            kind = msg.get("type", "")
        except json.JSONDecodeError:
            return

        if kind == "ai_message":
            self._bus.msg_received.emit("nexumi", msg.get("text", ""))
        elif kind == "menu_ack":
            self._bus.mood_changed.emit(msg.get("action", ""))

    # ── Outgoing messages ───────────────────────────────────────────────────
    def _send(self) -> None:
        text = self._input.text().strip()
        if not text:
            return
        self._input.clear()
        self._append_message("user", text)
        self._response_timer.start(2000)
        self._thinking_label.hide()

        async def _push() -> None:
            import websockets
            try:
                async with websockets.connect(WS_URI, open_timeout=3) as ws:
                    await ws.send(
                        json.dumps({"type": "user_text", "text": text})
                    )
            except Exception as exc:
                log.error("ChatPanel send failed: %s", exc)

        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(_push(), self._loop)
        else:
            log.warning("ChatPanel loop not running — message dropped")

    def _on_input_changed(self, text: str) -> None:
        if text.strip():
            self._typing_debounce.start(400)

    def _send_typing_ws(self) -> None:
        async def _push() -> None:
            import websockets
            try:
                async with websockets.connect(WS_URI, open_timeout=3) as ws:
                    await ws.send(json.dumps({"type": "typing"}))
            except Exception as exc:
                log.debug("Typing indicator send failed: %s", exc)

        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(_push(), self._loop)

    def _show_thinking(self) -> None:
        self._thinking_label.setText("Nexumi is thinking…")
        self._thinking_label.show()

    # ── Message display ─────────────────────────────────────────────────────
    def _append_message(
        self,
        role: str,
        text: str,
        *,
        save: bool = True,
        highlight: str = "",
    ) -> None:
        colour = "#ff9ec4" if role == "nexumi" else "#90c8ff"
        name = "Nexumi" if role == "nexumi" else "You"
        ts = datetime.now().strftime("%H:%M")

        safe_text = escape(text)
        if highlight:
            pat = re.escape(highlight)
            safe_text = re.sub(
                f"({pat})",
                r'<span style="background:#4a1890;">\1</span>',
                safe_text,
                flags=re.IGNORECASE,
            )

        html = (
            f'<p style="margin:5px 0;">'
            f'<span style="color:{colour};font-weight:600;">[{ts}] {name}</span>'
            f'<span style="color:#6a4090;"> &rsaquo; </span>'
            f'<span style="color:#e0c0ff;">{safe_text}</span>'
            f'</p>'
        )

        sb = self._view.verticalScrollBar()
        at_bottom = sb.value() >= sb.maximum() - 4
        self._view.append(html)
        if at_bottom:
            sb.setValue(sb.maximum())

        if save:
            self._history.append({"role": role, "text": text, "ts": ts})
            self._save_history()

        if role == "nexumi":
            self._response_timer.stop()
            self._thinking_label.hide()

    def _render_history(self) -> None:
        self._view.clear()
        for entry in self._history[-60:]:
            self._append_message(entry["role"], entry["text"], save=False)

    def _on_search(self, text: str) -> None:
        query = text.strip().lower()
        self._view.clear()
        for entry in self._history[-60:]:
            if not query or query in entry["text"].lower():
                self._append_message(
                    entry["role"], entry["text"], save=False, highlight=query
                )

    def _clear_view(self) -> None:
        self._view.clear()

    def _clear_history(self) -> None:
        reply = QMessageBox.question(
            self,
            "Clear History",
            "Permanently delete all chat history?\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        self._history.clear()
        self._view.clear()
        try:
            if HISTORY_FILE.exists():
                HISTORY_FILE.unlink()
            log.info("Chat history file deleted")
        except Exception as exc:
            log.error("Failed to delete history file: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    def _export_history(self) -> None:
        path, filt = QFileDialog.getSaveFileName(
            self,
            "Export Chat History",
            "chat_history.json",
            "JSON (*.json);;Plain Text (*.txt)",
        )
        if not path:
            return
        try:
            if filt == "Plain Text (*.txt)" or path.endswith(".txt"):
                lines = []
                for entry in self._history:
                    role = "Nexumi" if entry["role"] == "nexumi" else "You"
                    lines.append(f"[{entry['ts']}] {role}: {entry['text']}")
                Path(path).write_text("\n".join(lines), encoding="utf-8")
            else:
                Path(path).write_text(
                    json.dumps(self._history, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
            log.info("Exported chat history to %s", path)
        except Exception as exc:
            log.error("Export failed: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    # ── Mood label ──────────────────────────────────────────────────────────
    def _on_mood_changed(self, action: str) -> None:
        label = "Flirty mode" if "flirty" in action else "Normal mode"
        self._mood_label.setText(label)

    # ── History persistence ───────────────────────────────────────────────────
    def _load_history(self) -> list[dict]:
        try:
            if HISTORY_FILE.exists():
                return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except Exception as exc:
            log.warning("History load failed: %s", exc)
        return []

    def _save_history(self) -> None:
        HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = HISTORY_FILE.with_suffix(".tmp")
        try:
            tmp.write_text(
                json.dumps(self._history[-200:], indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            tmp.replace(HISTORY_FILE)
        except Exception as exc:
            log.error("History save failed: %s", exc)
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass

    # ── Cleanup ─────────────────────────────────────────────────────────────
    def closeEvent(self, event) -> None:
        """Gracefully stop the background WS loop before closing."""
        log.debug("ChatPanel closing — stopping WS listener")
        self._stop_event.set()
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        event.accept()
