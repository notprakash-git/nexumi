"""
src/ui/tray_icon.py

System tray icon — PyQt6.

Key design decisions
--------------------
- QAction parent is the QMenu, not None — avoids Qt ownership warnings.
- NexumiTray takes callbacks instead of a DesktopMate reference — no
  tight coupling between tray and window internals.
- Icons are cached per colour to avoid repainting every time mood changes.
- Notification helper for showing tray balloons (used by TTS/brain errors).
- Tooltip updates dynamically based on mood.
- Submenu for quick actions (reload config, restart viewer).
- Toggle-always-on-top action in the tray menu.
- Startup notification shown once after the tray is initialised.
"""

import sys
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtWidgets import QSystemTrayIcon, QMenu, QApplication
from PyQt6.QtGui import (
    QIcon, QPixmap, QColor,
    QPainter, QBrush, QRadialGradient,
)
from PyQt6.QtCore import Qt, QSize

from src.utils.logger import get_logger

log = get_logger("tray_icon")

_SS_MENU = """
    QMenu {
        background: #100620; color: #ddb0ff;
        border: 1px solid #5a1880; border-radius: 6px;
        padding: 4px 0; font-family: 'Noto Sans', sans-serif; font-size: 12px;
    }
    QMenu::item { padding: 7px 28px 7px 14px; border-radius: 4px; }
    QMenu::item:selected { background: #2c0a55; color: #ff9ec4; }
    QMenu::separator { height: 1px; background: #38106a; margin: 3px 8px; }
"""

# ── Icon cache ────────────────────────────────────────────────────────────────
_ICON_CACHE: dict[str, QIcon] = {}


def _make_icon(colour: str = "#ff9ec4", size: int = 32) -> QIcon:
    """
    Draw a glowing circle as the tray icon.
    Results are cached per colour to avoid repainting.
    """
    key = f"{colour}:{size}"
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]

    pix = QPixmap(QSize(size, size))
    pix.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pix)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    grad = QRadialGradient(size / 2, size / 2, size / 2)
    grad.setColorAt(0.0, QColor(colour))
    grad.setColorAt(0.55, QColor(colour).darker(140))
    grad.setColorAt(1.0, QColor(0, 0, 0, 0))

    painter.setBrush(QBrush(grad))
    painter.setPen(Qt.PenStyle.NoPen)
    painter.drawEllipse(2, 2, size - 4, size - 4)
    painter.end()

    icon = QIcon(pix)
    _ICON_CACHE[key] = icon
    return icon


# =============================================================================
# NexumiTray
# =============================================================================
class NexumiTray:
    """
    System tray icon and menu.

    Parameters
    ----------
    on_show_hide   : callable — toggle main window visibility
    on_open_chat   : callable — open / raise chat panel
    on_open_data   : callable — open / raise memory panel
    on_mode        : callable(str) — called with "normal" or "flirty"
    on_toggle_top  : callable — toggle always-on-top
    on_reload_config : callable — reload settings.json
    on_reload_viewer : callable — rebuild the 3D viewer widget
    on_quit        : callable — called when Exit is clicked
    """

    def __init__(
        self,
        on_show_hide: Optional[Callable] = None,
        on_open_chat: Optional[Callable] = None,
        on_open_data: Optional[Callable] = None,
        on_mode: Optional[Callable] = None,
        on_toggle_top: Optional[Callable] = None,
        on_reload_config: Optional[Callable] = None,
        on_reload_viewer: Optional[Callable] = None,
        on_quit: Optional[Callable] = None,
    ) -> None:
        self._on_show_hide = on_show_hide or (lambda: None)
        self._on_open_chat = on_open_chat or (lambda: None)
        self._on_open_data = on_open_data or (lambda: None)
        self._on_mode = on_mode or (lambda m: None)
        self._on_toggle_top = on_toggle_top or (lambda: None)
        self._on_reload_config = on_reload_config or (lambda: None)
        self._on_reload_viewer = on_reload_viewer or (lambda: None)
        self._on_quit = on_quit or QApplication.quit

        self._tray = QSystemTrayIcon(_make_icon())
        self._tray.setToolTip("Nexumi — AI Companion")
        self._tray.setContextMenu(self._build_menu())
        self._tray.activated.connect(self._on_activated)
        self._tray.show()

        self._startup_notify()
        log.info("System tray icon initialised")

    # ── Menu ──────────────────────────────────────────────────────────────────
    def _build_menu(self) -> QMenu:
        menu = QMenu()
        menu.setStyleSheet(_SS_MENU)

        def add(label: str, slot: Callable) -> None:
            from PyQt6.QtGui import QAction

            a = QAction(label, menu)  # menu is parent — no ownership warning
            a.triggered.connect(slot)
            menu.addAction(a)

        add("Show / Hide", self._on_show_hide)
        add("Open Chat", self._on_open_chat)
        add("Memory", self._on_open_data)
        menu.addSeparator()

        # Quick actions submenu
        quick = QMenu("Quick Actions", menu)
        quick.setStyleSheet(_SS_MENU)

        def add_sub(parent: QMenu, label: str, slot: Callable) -> None:
            from PyQt6.QtGui import QAction

            a = QAction(label, parent)
            a.triggered.connect(slot)
            parent.addAction(a)

        add_sub(quick, "Reload Config", self._on_reload_config)
        add_sub(quick, "Restart 3D Viewer", self._on_reload_viewer)
        add_sub(quick, "Toggle Always on Top", self._on_toggle_top)
        menu.addMenu(quick)
        menu.addSeparator()

        add("Normal Mode", lambda: self._on_mode("normal"))
        add("Flirty Mode", lambda: self._on_mode("flirty"))
        menu.addSeparator()
        add("Exit", self._on_quit)

        return menu

    # ── Single-click activates show/hide ────────────────────────────────────
    def _on_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self._on_show_hide()

    # ── Public helpers ────────────────────────────────────────────────────────
    def notify(
        self,
        title: str,
        message: str,
        icon: QSystemTrayIcon.MessageIcon = QSystemTrayIcon.MessageIcon.Information,
        duration_ms: int = 4000,
    ) -> None:
        """Show a system tray balloon notification."""
        if QSystemTrayIcon.isSystemTrayAvailable():
            self._tray.showMessage(title, message, icon, duration_ms)
            log.debug("Tray notification: %r — %r", title, message)

    def set_icon_mood(self, mood: str) -> None:
        """Switch tray icon colour to reflect current mood."""
        colour = "#ff9ec4" if mood == "normal" else "#ff5ca8"
        self._tray.setIcon(_make_icon(colour))

    def set_tooltip(self, mood: str) -> None:
        """Update the tray tooltip to show Nexumi's current mood."""
        self._tray.setToolTip(f"Nexumi — {mood.capitalize()}")

    def _startup_notify(self) -> None:
        """Show a brief "ready" balloon after the tray icon appears."""
        QTimer.singleShot(800, lambda: self.notify(
            "Nexumi",
            "Your AI companion is ready",
            QSystemTrayIcon.MessageIcon.Information,
            3000,
        ))

    def shutdown(self) -> None:
        """Hide the tray icon before application exit."""
        log.debug("Tray shutting down")
        self._tray.hide()
