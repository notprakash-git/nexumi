"""
src/ui/__main__.py
Launch the desktop mate UI directly: python -m src.ui
"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path

# Ensure project root is on sys.path for absolute imports
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(_PROJECT_ROOT))

from PyQt6.QtWidgets import QApplication

from src.ui.desktop_mate import DesktopMate
from src.ui.tray_icon import NexumiTray
from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("ui_main")


def _check_ws_hub(host: str, port: int, timeout: float = 2.0) -> None:
    """Fire-and-forget probe that warns if the WebSocket hub is unreachable."""

    async def _probe() -> None:
        import websockets
        uri = f"ws://{host}:{port}"
        try:
            async with websockets.connect(uri, open_timeout=timeout):
                log.info("WebSocket hub is reachable (%s)", uri)
        except Exception:
            log.warning(
                "WebSocket hub not detected at %s. "
                "Ensure the backend (websocket_server / hime_controller) is running.",
                uri,
            )

    try:
        asyncio.run(_probe())
    except Exception as exc:
        log.debug("WS hub probe failed: %s", exc)


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="python -m src.ui",
        description="Nexumi Desktop Companion — PyQt6 UI",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable DEBUG level logging",
    )
    parser.add_argument(
        "--no-tray",
        action="store_true",
        help="Launch without the system tray icon (useful for testing)",
    )
    return parser.parse_args()


def main() -> None:
    """Application entry point."""
    args = _parse_args()

    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
        log.debug("Debug logging enabled")

    app = QApplication(sys.argv)
    app.setApplicationName("Nexumi")
    app.setQuitOnLastWindowClosed(False)

    cfg = load_settings()
    ws_cfg = cfg.get("websocket", {})
    _check_ws_hub(ws_cfg.get("host", "localhost"), ws_cfg.get("port", 8765))

    # minimise-to-tray is only meaningful when the tray is active
    mate = DesktopMate(minimize_to_tray=not args.no_tray)

    tray: NexumiTray | None = None
    if not args.no_tray:
        tray = NexumiTray(
            on_show_hide=mate.toggle_visibility,
            on_open_chat=mate.open_chat,
            on_open_data=mate.open_data,
            on_mode=mate.send_mode,
            on_toggle_top=mate.toggle_always_on_top,
            on_reload_config=mate.reload_config,
            on_reload_viewer=mate.reload_viewer,
            on_quit=app.quit,
        )
        # Forward mood changes to the tray tooltip / icon
        mate.mood_changed.connect(
            lambda mood: tray.set_tooltip(mood) if tray else None
        )

    mate.show()

    def _on_quit() -> None:
        """Graceful shutdown hook."""
        log.info("Shutting down Nexumi UI…")
        mate.shutdown()
        if tray is not None:
            tray.shutdown()
        # Brief grace period for daemon threads to finish I/O
        import time

        time.sleep(0.15)

    app.aboutToQuit.connect(_on_quit)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
