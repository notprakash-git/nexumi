"""
src/ui/data_panel.py

SQLite memory viewer — PyQt6.

Key design decisions
--------------------
- DB_PATH resolved with pathlib.Path — no brittle relative traversal.
- refresh() only rebuilds changed rows when the row count matches,
  preventing button flicker on every auto-refresh.
- Delete confirms with the fact text in the dialog, not just an ID.
- Category filter combo lets you view facts by category.
- Search box filters facts client-side without a DB round-trip.
- Inline editing: double-click a fact cell to edit; changes are persisted
  immediately to the DB.
- Bulk delete: select multiple rows (Ctrl/Shift) and delete in one action.
- Auto-refresh timer polls the DB at a configurable interval.
- Category management dialog supports add, rename, and delete (with cascade).
- Undo notification appears for 10 s after a single fact deletion.
- All DB calls wrapped in helpers that log errors and return safe defaults.
"""

import sqlite3
from pathlib import Path
from typing import Callable, Optional

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QTableWidget, QTableWidgetItem, QPushButton,
    QInputDialog, QMessageBox, QHeaderView,
    QAbstractItemView, QLineEdit, QComboBox,
    QDialog, QDialogButtonBox, QListWidget, QListWidgetItem,
)
from PyQt6.QtGui import QFont

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("data_panel")
_cfg = load_settings()

DB_PATH = Path(__file__).resolve().parent.parent.parent / _cfg.get(
    "memory", {}
).get("db_path", "data/memory.db")
_REFRESH_INTERVAL_MS = _cfg.get("memory", {}).get("refresh_interval_sec", 30) * 1000

# ── Stylesheet ────────────────────────────────────────────────────────────────
_SS = """
    QWidget {
        background: #0b061e; color: #eac8ff;
        font-family: 'Noto Sans', sans-serif;
    }
    QTableWidget {
        background: #130930; border: 1px solid #3d1870;
        gridline-color: #1e0d40; color: #eac8ff;
        selection-background-color: #2c0a55;
        font-size: 12px;
    }
    QHeaderView::section {
        background: #220850; color: #ff9ec4;
        padding: 7px 8px; font-weight: bold;
        border: none; border-right: 1px solid #3d1870;
    }
    QLineEdit {
        background: #130930; border: 1px solid #5a28a0;
        border-radius: 6px; padding: 6px 10px; color: #eac8ff;
    }
    QLineEdit:focus { border-color: #8848d0; }
    QComboBox {
        background: #130930; border: 1px solid #5a28a0;
        border-radius: 6px; padding: 5px 10px; color: #eac8ff;
        min-width: 110px;
    }
    QComboBox::drop-down { border: none; }
    QComboBox QAbstractItemView {
        background: #130930; color: #eac8ff;
        selection-background-color: #2c0a55;
    }
    QPushButton {
        background: #5a28a0; color: #fff;
        border-radius: 6px; padding: 6px 14px;
        font-size: 12px; font-weight: bold;
    }
    QPushButton:hover   { background: #7038c0; }
    QPushButton:pressed { background: #3d1880; }
    QPushButton#del_btn {
        background: #6b1a1a; color: #ffaaaa;
        padding: 3px 10px; font-size: 11px;
    }
    QPushButton#del_btn:hover { background: #8b2020; }
    QPushButton#undo_btn {
        background: #1a4a1a; color: #aaffaa;
        padding: 3px 10px; font-size: 11px;
    }
    QPushButton#undo_btn:hover { background: #206020; }
"""

# Table column indices
_COL_ID = 0
_COL_FACT = 1
_COL_CAT = 2
_COL_DATE = 3
_COL_DEL = 4


# =============================================================================
# Category management dialog
# =============================================================================
class _CategoryDialog(QDialog):
    """Dialog to add, rename, and delete categories."""

    def __init__(
        self,
        parent: QWidget,
        db_path: Path,
        on_changed: Callable[[], None],
    ) -> None:
        super().__init__(parent)
        self._db_path = db_path
        self._on_changed = on_changed
        self.setWindowTitle("Manage Categories")
        self.setMinimumSize(320, 300)
        self.setStyleSheet(_SS)
        self._build_ui()
        self._load()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Double-click a category to rename it."))

        self._list = QListWidget()
        self._list.itemDoubleClicked.connect(self._rename)
        layout.addWidget(self._list)

        row = QHBoxLayout()
        self._input = QLineEdit()
        self._input.setPlaceholderText("New category name…")
        row.addWidget(self._input)

        add_btn = QPushButton("Add")
        add_btn.clicked.connect(self._add)
        row.addWidget(add_btn)
        layout.addLayout(row)

        del_btn = QPushButton("Delete Category (and its facts)")
        del_btn.setObjectName("del_btn")
        del_btn.clicked.connect(self._delete)
        layout.addWidget(del_btn)

        btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)

    def _load(self) -> None:
        self._list.clear()
        try:
            with sqlite3.connect(self._db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT category FROM facts ORDER BY category"
                ).fetchall()
                for (cat,) in rows:
                    self._list.addItem(cat)
        except Exception as exc:
            log.error("Failed to load categories: %s", exc)

    def _add(self) -> None:
        cat = self._input.text().strip()
        if not cat:
            return
        items = [self._list.item(i).text() for i in range(self._list.count())]
        if cat in items:
            return
        self._list.addItem(cat)
        self._input.clear()
        self._on_changed()

    def _rename(self, item: QListWidgetItem) -> None:
        old = item.text()
        new, ok = QInputDialog.getText(
            self, "Rename Category", "New name:", text=old
        )
        if not ok or not new.strip() or new.strip() == old:
            return
        new = new.strip()
        try:
            with sqlite3.connect(self._db_path) as conn:
                conn.execute(
                    "UPDATE facts SET category = ? WHERE category = ?",
                    (new, old),
                )
                conn.commit()
            self._load()
            self._on_changed()
            log.info("Renamed category '%s' → '%s'", old, new)
        except Exception as exc:
            log.error("Rename category error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    def _delete(self) -> None:
        item = self._list.currentItem()
        if not item:
            return
        cat = item.text()
        reply = QMessageBox.question(
            self,
            "Delete Category",
            f"Delete ALL facts in category '{cat}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        try:
            with sqlite3.connect(self._db_path) as conn:
                conn.execute("DELETE FROM facts WHERE category = ?", (cat,))
                conn.commit()
            self._load()
            self._on_changed()
            log.info("Deleted category '%s' and its facts", cat)
        except Exception as exc:
            log.error("Delete category error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))


# =============================================================================
# DataPanel
# =============================================================================
class DataPanel(QWidget):
    """Memory browser with CRUD, filtering, bulk operations, and auto-refresh."""

    def __init__(self) -> None:
        super().__init__()
        self._all_facts: list[dict] = []
        self._block_cell_change = False
        self._last_deleted: Optional[dict] = None

        self._build_ui()
        self.refresh()

        # Auto-refresh timer
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(max(_REFRESH_INTERVAL_MS, 5000))
        self._refresh_timer.timeout.connect(self.refresh)
        self._refresh_timer.start()

        # Undo timer
        self._undo_timer = QTimer(self)
        self._undo_timer.setSingleShot(True)
        self._undo_timer.timeout.connect(self._clear_undo)

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        self.setWindowTitle("Nexumi — Memory")
        self.setMinimumSize(720, 520)
        self.setStyleSheet(_SS)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        # Title
        title = QLabel("Nexumi Memory")
        title.setFont(QFont("Noto Sans", 14, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("color:#ff9ec4; padding-bottom:4px;")
        layout.addWidget(title)

        # Filter row
        filter_row = QHBoxLayout()
        filter_row.setSpacing(8)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search facts…")
        self._search.textChanged.connect(self._apply_filter)
        filter_row.addWidget(self._search, stretch=1)

        self._cat_filter = QComboBox()
        self._cat_filter.addItem("All categories")
        self._cat_filter.currentTextChanged.connect(self._apply_filter)
        filter_row.addWidget(self._cat_filter)

        cat_btn = QPushButton("Manage Categories")
        cat_btn.clicked.connect(self._open_category_dialog)
        filter_row.addWidget(cat_btn)

        layout.addLayout(filter_row)

        # Table
        self._table = QTableWidget()
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(
            ["ID", "Fact", "Category", "Learned At", ""]
        )
        self._table.horizontalHeader().setSectionResizeMode(
            _COL_FACT, QHeaderView.ResizeMode.Stretch
        )
        self._table.horizontalHeader().setSectionResizeMode(
            _COL_ID, QHeaderView.ResizeMode.ResizeToContents
        )
        self._table.horizontalHeader().setSectionResizeMode(
            _COL_DEL, QHeaderView.ResizeMode.ResizeToContents
        )
        self._table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self._table.setSelectionMode(
            QAbstractItemView.SelectionMode.ExtendedSelection
        )
        self._table.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked
        )
        self._table.verticalHeader().setVisible(False)
        self._table.setAlternatingRowColors(True)
        self._table.cellChanged.connect(self._on_cell_changed)
        layout.addWidget(self._table)

        # Bottom row
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self._count_label = QLabel("0 facts")
        self._count_label.setStyleSheet("color:#7050a0; font-size:11px;")
        btn_row.addWidget(self._count_label)
        btn_row.addStretch()

        self._undo_btn = QPushButton("Undo Delete")
        self._undo_btn.setObjectName("undo_btn")
        self._undo_btn.clicked.connect(self._undo_delete)
        self._undo_btn.hide()
        btn_row.addWidget(self._undo_btn)

        del_sel_btn = QPushButton("Delete Selected")
        del_sel_btn.setObjectName("del_btn")
        del_sel_btn.clicked.connect(self._delete_selected)
        btn_row.addWidget(del_sel_btn)

        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self.refresh)
        btn_row.addWidget(refresh_btn)

        add_btn = QPushButton("Add Fact")
        add_btn.clicked.connect(self._add_fact_dialog)
        btn_row.addWidget(add_btn)

        layout.addLayout(btn_row)

    # ── Data loading ──────────────────────────────────────────────────────────
    def refresh(self) -> None:
        """Reload all facts from the DB and re-render the table."""
        self._all_facts = self._fetch_facts()
        self._update_category_filter()
        self._apply_filter()

    def _fetch_facts(self) -> list[dict]:
        try:
            with sqlite3.connect(DB_PATH) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT * FROM facts ORDER BY learned_at DESC"
                ).fetchall()
                return [dict(r) for r in rows]
        except sqlite3.OperationalError as exc:
            log.debug("DB operational error (table may not exist yet): %s", exc)
            return []
        except Exception as exc:
            log.error("DB fetch error: %s", exc)
            return []

    def _update_category_filter(self) -> None:
        cats = sorted({f["category"] for f in self._all_facts})
        current = self._cat_filter.currentText()
        self._cat_filter.blockSignals(True)
        self._cat_filter.clear()
        self._cat_filter.addItem("All categories")
        for cat in cats:
            self._cat_filter.addItem(cat)
        idx = self._cat_filter.findText(current)
        self._cat_filter.setCurrentIndex(max(0, idx))
        self._cat_filter.blockSignals(False)

    # ── Filtering ─────────────────────────────────────────────────────────────
    def _apply_filter(self) -> None:
        query = self._search.text().strip().lower()
        cat = self._cat_filter.currentText()

        filtered = [
            f
            for f in self._all_facts
            if (not query or query in f["fact_text"].lower())
            and (cat == "All categories" or f["category"] == cat)
        ]
        self._render_table(filtered)

    # ── Table rendering ───────────────────────────────────────────────────────
    def _render_table(self, facts: list[dict]) -> None:
        self._block_cell_change = True
        self._table.setRowCount(len(facts))

        for row, fact in enumerate(facts):
            fid = fact["id"]

            def _item(text: str, editable: bool = False) -> QTableWidgetItem:
                item = QTableWidgetItem(str(text))
                flags = Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled
                if editable:
                    flags |= Qt.ItemFlag.ItemIsEditable
                item.setFlags(flags)
                return item

            self._table.setItem(row, _COL_ID, _item(fid))
            self._table.setItem(row, _COL_FACT, _item(fact["fact_text"], editable=True))
            self._table.setItem(row, _COL_CAT, _item(fact["category"]))
            self._table.setItem(row, _COL_DATE, _item(str(fact["learned_at"])[:16]))

            del_btn = QPushButton("Delete")
            del_btn.setObjectName("del_btn")
            del_btn.clicked.connect(
                lambda _, f=fid, t=fact: self._confirm_delete(f, t)
            )
            self._table.setCellWidget(row, _COL_DEL, del_btn)

        count = len(facts)
        total = len(self._all_facts)
        self._count_label.setText(
            f"{count} fact{'s' if count != 1 else ''}"
            + (f" (filtered from {total})" if count != total else "")
        )
        self._block_cell_change = False

    # ── Inline editing ────────────────────────────────────────────────────────
    def _on_cell_changed(self, row: int, col: int) -> None:
        if self._block_cell_change or col != _COL_FACT:
            return
        id_item = self._table.item(row, _COL_ID)
        if id_item is None:
            return
        fact_id = int(id_item.text())
        new_text = self._table.item(row, col).text()
        self._update_fact_text(fact_id, new_text)

    def _update_fact_text(self, fact_id: int, new_text: str) -> None:
        try:
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    "UPDATE facts SET fact_text = ? WHERE id = ?",
                    (new_text, fact_id),
                )
                conn.commit()
            for f in self._all_facts:
                if f["id"] == fact_id:
                    f["fact_text"] = new_text
                    break
            log.info("Updated fact ID %d", fact_id)
        except Exception as exc:
            log.error("Update fact error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))
            self.refresh()

    # ── CRUD ──────────────────────────────────────────────────────────────────
    def _confirm_delete(self, fact_id: int, fact: dict) -> None:
        reply = QMessageBox.question(
            self,
            "Delete Memory",
            f'Delete this fact?\n\n"{fact["fact_text"][:100]}"',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self._delete_fact(
                fact_id,
                fact_text=fact["fact_text"],
                category=fact["category"],
                learned_at=fact.get("learned_at", ""),
            )

    def _delete_fact(
        self,
        fact_id: int,
        *,
        fact_text: str = "",
        category: str = "",
        learned_at: str = "",
        show_undo: bool = True,
    ) -> None:
        try:
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute("DELETE FROM facts WHERE id=?", (fact_id,))
                conn.commit()
            if show_undo:
                self._last_deleted = {
                    "text": fact_text,
                    "category": category,
                    "learned_at": learned_at,
                }
                self._show_undo()
            self.refresh()
            log.info("Deleted fact ID %d", fact_id)
        except Exception as exc:
            log.error("Delete error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    def _delete_selected(self) -> None:
        rows = sorted(
            {idx.row() for idx in self._table.selectionModel().selectedRows()},
            reverse=True,
        )
        if not rows:
            return
        reply = QMessageBox.question(
            self,
            "Delete Selected",
            f"Delete {len(rows)} selected fact(s)?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        for row in rows:
            id_item = self._table.item(row, _COL_ID)
            if id_item is None:
                continue
            fact_id = int(id_item.text())
            self._delete_fact(fact_id, show_undo=False)
        self._clear_undo()
        self.refresh()

    def _show_undo(self) -> None:
        self._undo_btn.show()
        self._undo_timer.start(10000)

    def _clear_undo(self) -> None:
        self._last_deleted = None
        self._undo_btn.hide()

    def _undo_delete(self) -> None:
        if not self._last_deleted:
            return
        try:
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    "INSERT INTO facts (fact_text, category) VALUES (?, ?)",
                    (self._last_deleted["text"], self._last_deleted["category"]),
                )
                conn.commit()
            self._clear_undo()
            self.refresh()
            log.info("Undo delete — fact restored")
        except Exception as exc:
            log.error("Undo delete error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    def _add_fact_dialog(self) -> None:
        text, ok = QInputDialog.getText(
            self, "Add Memory", "Enter a new fact to remember:"
        )
        if not ok or not text.strip():
            return
        cat, ok2 = QInputDialog.getItem(
            self,
            "Category",
            "Choose a category:",
            ["general", "preference", "identity", "tech", "manual"],
            0,
            False,
        )
        if not ok2:
            cat = "manual"
        self._add_fact(text.strip(), cat)

    def _add_fact(self, text: str, category: str) -> None:
        try:
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute(
                    "INSERT INTO facts (fact_text, category) VALUES (?, ?)",
                    (text, category),
                )
                conn.commit()
            self.refresh()
            log.info("Added fact: %r [%s]", text, category)
        except Exception as exc:
            log.error("Add fact error: %s", exc)
            QMessageBox.critical(self, "Error", str(exc))

    def _open_category_dialog(self) -> None:
        dlg = _CategoryDialog(self, DB_PATH, self._update_category_filter)
        dlg.exec()

    # ── Cleanup ───────────────────────────────────────────────────────────────
    def closeEvent(self, event) -> None:
        log.debug("DataPanel closing — stopping auto-refresh")
        self._refresh_timer.stop()
        self._undo_timer.stop()
        event.accept()
