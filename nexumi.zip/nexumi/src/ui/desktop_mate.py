"""
src/ui/desktop_mate.py

Frameless, transparent, always-on-top PyQt6 desktop companion window.

Key design decisions
--------------------
- Signals live on a dedicated QObject bus — not mixed into the window class.
- WS listener runs on a daemon thread with a bidirectional send queue so
  outgoing messages reuse the same connection instead of spawning short-lived
  ones for every mode change.
- Drag uses Optional[QPoint] — first drag never jumps to (0,0).
- Panels are stored and reused — not recreated on every open.
- Window geometry is saved to settings.json via a debounced timer on move/resize.
- closeEvent hides the window when tray integration is active; the tray menu
  is the canonical quit path.
- A global Ctrl+Shift+H shortcut toggles visibility.
- If the 3D viewer fails to load, a placeholder with a Retry button is shown.
- All Qt widget access from background threads goes through signals only.
"""

import asyncio
import json
import sys
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from PyQt6.QtCore import Qt, QPoint, QTimer, QUrl, pyqtSignal, QObject
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget,
    QVBoxLayout, QLabel, QMenu, QSizePolicy, QPushButton,
)
from PyQt6.QtGui import QAction, QShortcut, QKeySequence

try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEngineSettings

    _WEBENGINE = True
except ImportError:
    _WEBENGINE = False

from src.utils.logger import get_logger
from src.utils.settings import load_settings

log = get_logger("desktop_mate")
_cfg = load_settings()
_win_cfg = _cfg.get("window", {})
_ws_cfg = _cfg.get("websocket", {})

WS_URI = f"ws://{_ws_cfg.get('host', 'localhost')}:{_ws_cfg.get('port', 8765)}"
VIEWER_HTML = Path(__file__).resolve().parent.parent.parent / "web" / "3d_viewer.html"
SETTINGS_PATH = Path(__file__).resolve().parent.parent.parent / "settings.json"

# ── Stylesheets ───────────────────────────────────────────────────────────────
_SS_STATUS_IDLE = (
    "color:#d0b0ff;background:rgba(10,4,22,190);"
    "border-top:1px solid rgba(140,70,220,50);"
    "padding:5px 12px;font-size:11px;"
    "font-family:'Noto Sans',sans-serif;"
)
_SS_STATUS_WARN = (
    "color:#ffe066;background:rgba(35,18,0,210);"
    "border-top:1px solid rgba(220,160,0,70);"
    "padding:5px 12px;font-size:11px;"
    "font-family:'Noto Sans',sans-serif;"
)
_SS_MENU = """
    QMenu {
        background:#100620; color:#ddb0ff;
        border:1px solid #5a1880; border-radius:6px;
        padding:4px 0; font-family:'Noto Sans',sans-serif; font-size:12px;
    }
    QMenu::item { padding:7px 28px 7px 14px; border-radius:4px; }
    QMenu::item:selected { background:#2c0a55; color:#ff9ec4; }
    QMenu::separator { height:1px; background:#38106a; margin:3px 8px; }
"""
_SS_PLACEHOLDER = (
    "color:#b080d8;background:rgba(10,4,22,210);"
    "border-radius:16px;font-size:14px;"
    "font-family:'Noto Sans',sans-serif;padding:40px 20px;"
)


# =============================================================================
# Signal bus — pure QObject, lives on the main thread
# =============================================================================
class _Bus(QObject):
    ai_message = pyqtSignal(str, str)  # (text, emotion)
    status_msg = pyqtSignal(str, bool)  # (message, is_warning)
    memory_refreshed = pyqtSignal()


# =============================================================================
# WS listener — daemon thread with internal send queue
# =============================================================================
class _WsListener:
    """Persistent WebSocket listener that reuses one connection for send & recv."""

    def __init__(self, bus: _Bus) -> None:
        self._bus = bus
        self._send_queue: Optional[asyncio.Queue] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._shutdown = False
        threading.Thread(
            target=self._thread_main,
            daemon=True,
            name="DM-WsListener",
        ).start()

    def _thread_main(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._send_queue = asyncio.Queue()
        self._loop.run_until_complete(self._main())

    async def _main(self) -> None:
        import websockets

        while not self._shutdown:
            try:
                async with websockets.connect(WS_URI, open_timeout=5) as ws:
                    log.info("DesktopMate connected to WS hub")
                    recv_task = asyncio.create_task(self._recv(ws))
                    send_task = asyncio.create_task(self._send_loop(ws))
                    done, pending = await asyncio.wait(
                        [recv_task, send_task],
                        return_when=asyncio.FIRST_COMPLETED,
                    )
                    for task in pending:
                        task.cancel()
                        try:
                            await task
                        except asyncio.CancelledError:
                            pass
            except Exception as exc:
                if not self._shutdown:
                    log.debug("WS listener: %r — retry in 3s", exc)
                    await asyncio.sleep(3)

    async def _recv(self, ws) -> None:
        async for raw in ws:
            self._dispatch(raw)

    async def _send_loop(self, ws) -> None:
        while True:
            msg = await self._send_queue.get()
            if msg is None:
                break
            await ws.send(msg)

    def _dispatch(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
            kind = msg.get("type", "")
        except json.JSONDecodeError:
            return

        if kind == "ai_message":
            self._bus.ai_message.emit(
                msg.get("text", ""), msg.get("emotion", "neutral")
            )
        elif kind == "status":
            self._bus.status_msg.emit(msg.get("message", ""), False)
        elif kind == "resource_warning":
            self._bus.status_msg.emit(msg.get("message", ""), True)
        elif kind == "memory_updated":
            self._bus.memory_refreshed.emit()

    def send(self, msg: dict) -> None:
        """Enqueue a JSON message to be sent on the existing WS connection."""
        if self._shutdown:
            log.warning("WS listener is shut down — message dropped")
            return
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(
                self._send_queue.put(json.dumps(msg)),
                self._loop,
            )
        else:
            log.warning("WS loop not running — message dropped")

    def stop(self) -> None:
        """Signal the listener to shut down gracefully."""
        self._shutdown = True
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(
                self._send_queue.put(None), self._loop
            )


# =============================================================================
# DesktopMate — main window
# =============================================================================
class DesktopMate(QMainWindow):
    """Frameless desktop companion with 3D viewer, WS integration, and tray support."""

    mood_changed = pyqtSignal(str)

    def __init__(self, *, minimize_to_tray: bool = True) -> None:
        super().__init__()
        self._minimize_to_tray = minimize_to_tray
        self._drag_origin: Optional[QPoint] = None
        self._chat_panel: Optional[QWidget] = None
        self._data_panel: Optional[QWidget] = None

        # Debounced geometry saver
        self._save_geo_timer = QTimer(self)
        self._save_geo_timer.setSingleShot(True)
        self._save_geo_timer.timeout.connect(self._save_geometry)

        # Warning auto-clear
        self._warn_clear = QTimer(self)
        self._warn_clear.setSingleShot(True)
        self._warn_clear.timeout.connect(self._reset_status)

        # Bus wired before listener starts
        self._bus = _Bus()
        self._bus.ai_message.connect(self._on_ai_message)
        self._bus.status_msg.connect(self._on_status)
        self._bus.memory_refreshed.connect(self._on_memory_refreshed)

        self._configure_window()
        self._build_ui()
        self._listener = _WsListener(self._bus)

        # Global shortcut Ctrl+Shift+H
        self._shortcut = QShortcut(QKeySequence("Ctrl+Shift+H"), self)
        self._shortcut.activated.connect(self.toggle_visibility)

        log.info("DesktopMate ready")

    # ── Window ────────────────────────────────────────────────────────────────
    def _configure_window(self) -> None:
        self.setWindowTitle("Nexumi")
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
            | Qt.WindowType.X11BypassWindowManagerHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setGeometry(
            _win_cfg.get("x", 1500),
            _win_cfg.get("y", 200),
            _win_cfg.get("width", 350),
            _win_cfg.get("height", 600),
        )

    # ── UI ────────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        root = QWidget(self)
        root.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCentralWidget(root)

        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self._viewer_container = self._build_viewer()
        layout.addWidget(self._viewer_container, stretch=1)

        self._status = QLabel("Ready", self)
        self._status.setStyleSheet(_SS_STATUS_IDLE)
        self._status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._status.setFixedHeight(26)
        self._status.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        layout.addWidget(self._status)

    def _build_viewer(self) -> QWidget:
        if _WEBENGINE and VIEWER_HTML.is_file():
            view = QWebEngineView(self)
            view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
            view.page().setBackgroundColor(Qt.GlobalColor.transparent)
            s = view.page().settings()
            s.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls,
                True,
            )
            s.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls,
                True,
            )
            view.load(QUrl.fromLocalFile(str(VIEWER_HTML)))
            log.info("WebEngineView loaded: %s", VIEWER_HTML)
            return view

        note = (
            "Install qt6-webengine to\nenable the 3D viewer.\n\n"
            if not _WEBENGINE else ""
        )
        container = QWidget(self)
        vlay = QVBoxLayout(container)
        vlay.setAlignment(Qt.AlignmentFlag.AlignCenter)

        label = QLabel(
            f"Nexumi\n\n{note}Place nexumi.vrm in\nassets/3d_model/",
            self,
        )
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet(_SS_PLACEHOLDER)
        vlay.addWidget(label)

        retry_btn = QPushButton("Retry")
        retry_btn.setStyleSheet(
            "background:#5a28a0; color:#fff; border-radius:6px; padding:6px 14px;"
        )
        retry_btn.clicked.connect(self.reload_viewer)
        vlay.addWidget(retry_btn)

        return container

    # ── Signal handlers (main thread only) ───────────────────────────────────
    def _on_ai_message(self, text: str, emotion: str) -> None:
        preview = text[:55] + ("…" if len(text) > 55 else "")
        self._set_status(f"[{emotion}]  {preview}")
        self.mood_changed.emit(emotion)
        QTimer.singleShot(6000, self._reset_status)

    def _on_status(self, msg: str, warning: bool) -> None:
        self._set_status(msg, warning=warning)
        if warning:
            self._warn_clear.start(8000)

    def _on_memory_refreshed(self) -> None:
        if self._data_panel is not None and self._data_panel.isVisible():
            self._data_panel.refresh()

    def _set_status(self, text: str, *, warning: bool = False) -> None:
        self._status.setStyleSheet(_SS_STATUS_WARN if warning else _SS_STATUS_IDLE)
        self._status.setText(text)

    def _reset_status(self) -> None:
        self._set_status("Ready")

    # ── Drag ──────────────────────────────────────────────────────────────────
    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_origin = (
                event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            )
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._drag_origin is not None and (
            event.buttons() & Qt.MouseButton.LeftButton
        ):
            self.move(event.globalPosition().toPoint() - self._drag_origin)
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_origin = None
        super().mouseReleaseEvent(event)

    # ── Context menu ──────────────────────────────────────────────────────────
    def contextMenuEvent(self, event) -> None:
        menu = QMenu(self)
        menu.setStyleSheet(_SS_MENU)

        def add(label: str, slot) -> None:
            a = QAction(label, menu)
            a.triggered.connect(slot)
            menu.addAction(a)

        add("Open Chat", self.open_chat)
        add("Memory", self.open_data)
        menu.addSeparator()
        add("Normal Mode", lambda: self.send_mode("normal"))
        add("Flirty Mode", lambda: self.send_mode("flirty"))
        menu.addSeparator()
        add("Reload Config", self.reload_config)
        add("Restart 3D Viewer", self.reload_viewer)
        menu.addSeparator()
        add("Exit", QApplication.quit)
        menu.exec(event.globalPos())

    # ── Panels ────────────────────────────────────────────────────────────────
    def open_chat(self) -> None:
        """Open or raise the chat panel."""
        if self._chat_panel is None or not self._chat_panel.isVisible():
            from src.ui.chat_panel import ChatPanel

            self._chat_panel = ChatPanel()
            self._chat_panel.show()
        else:
            self._chat_panel.raise_()
            self._chat_panel.activateWindow()

    def open_data(self) -> None:
        """Open or raise the memory (data) panel."""
        if self._data_panel is None or not self._data_panel.isVisible():
            from src.ui.data_panel import DataPanel

            self._data_panel = DataPanel()
            self._data_panel.show()
        else:
            self._data_panel.raise_()
            self._data_panel.activateWindow()

    # ── Visibility & window flags ─────────────────────────────────────────────
    def toggle_visibility(self) -> None:
        """Show the window if hidden, hide it if visible."""
        if self.isVisible():
            self.hide()
            log.debug("Window hidden")
        else:
            self.show()
            self.raise_()
            self.activateWindow()
            log.debug("Window shown")

    def toggle_always_on_top(self) -> None:
        """Toggle the WindowStaysOnTopHint."""
        flags = self.windowFlags()
        on_top = bool(flags & Qt.WindowType.WindowStaysOnTopHint)
        if on_top:
            self.setWindowFlags(flags & ~Qt.WindowType.WindowStaysOnTopHint)
            log.info("Always-on-top disabled")
        else:
            self.setWindowFlags(flags | Qt.WindowType.WindowStaysOnTopHint)
            log.info("Always-on-top enabled")
        self.show()

    # ── Mode change ───────────────────────────────────────────────────────────
    def send_mode(self, mode: str) -> None:
        """Send a mode-change command through the shared WS connection."""
        self._listener.send({"type": "menu_action", "action": f"mode_{mode}"})
        log.info("Mode → %s", mode)

    # ── Viewer & config reload ────────────────────────────────────────────────
    def reload_viewer(self) -> None:
        """Rebuild the 3D viewer widget (useful after fixing missing files)."""
        log.info("Reloading 3D viewer…")
        old = self._viewer_container
        self._viewer_container = self._build_viewer()
        layout = self.centralWidget().layout()
        layout.replaceWidget(old, self._viewer_container)
        old.deleteLater()
        self._viewer_container.show()

    def reload_config(self) -> None:
        """Reload settings.json and apply runtime changes."""
        global _cfg, _win_cfg, _ws_cfg, WS_URI
        _cfg = load_settings()
        _win_cfg = _cfg.get("window", {})
        _ws_cfg = _cfg.get("websocket", {})
        WS_URI = f"ws://{_ws_cfg.get('host', 'localhost')}:{_ws_cfg.get('port', 8765)}"
        log.info("Configuration reloaded")

    # ── Geometry persistence ──────────────────────────────────────────────────
    def moveEvent(self, event) -> None:
        super().moveEvent(event)
        self._save_geo_timer.start(500)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._save_geo_timer.start(500)

    def _save_geometry(self) -> None:
        try:
            cfg = load_settings()
            cfg.setdefault("window", {})
            cfg["window"]["x"] = self.x()
            cfg["window"]["y"] = self.y()
            cfg["window"]["width"] = self.width()
            cfg["window"]["height"] = self.height()
            if SETTINGS_PATH.exists():
                SETTINGS_PATH.write_text(
                    json.dumps(cfg, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )
                log.debug("Window geometry saved")
        except Exception as exc:
            log.warning("Failed to save geometry: %s", exc)

    # ── Lifecycle ───────────────────────────────────────────────────────────────
    def closeEvent(self, event) -> None:
        """Hide to tray instead of quitting when tray integration is active."""
        if self._minimize_to_tray:
            event.ignore()
            self.hide()
            log.info("Window minimized to tray")
        else:
            self.shutdown()
            event.accept()

    def shutdown(self) -> None:
        """Clean up resources before application exit."""
        log.info("DesktopMate shutting down…")
        self._listener.stop()
        self._save_geometry()
        if self._chat_panel is not None:
            self._chat_panel.close()
        if self._data_panel is not None:
            self._data_panel.close()
        if self._viewer_container is not None:
            self._viewer_container.deleteLater()


# =============================================================================
# Entry point
# =============================================================================
def main() -> None:
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    mate = DesktopMate()
    mate.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
