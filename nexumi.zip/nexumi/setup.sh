#!/usr/bin/env bash
# =============================================================================
# setup.sh – Production-grade Nexumi installer for Arch Linux
# =============================================================================
# One-shot setup: system deps, Python venv, pip packages, Vosk model,
# config scaffolding, and integrity verification.
#
# Architecture (current):
#   - Wake Word: Vosk keyword spotting (no Porcupine)
#   - STT: Google Speech API + Vosk offline fallback
#   - TTS: edge-tts (ja-JP-NanamiNeural, streams at runtime)
#   - Brain: OpenRouter via openai SDK (no LangChain)
#   - GUI: PyQt6 + Qt6 WebEngine + Three.js (built-in 3D viewer)
#   - Desktop Control: pyautogui + xdotool + custom desktop_control module
#
# Usage:
#   chmod +x setup.sh
#   ./setup.sh
# =============================================================================

set -euo pipefail
shopt -s inherit_errexit 2>/dev/null || true

# =============================================================================
# CONFIGURATION
# =============================================================================

readonly NEXUMI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly VENV="$NEXUMI_DIR/venv"
readonly PYTHON="${PYTHON:-python3}"
readonly REQ_FILE="$NEXUMI_DIR/requirements.txt"
readonly CONFIG_DIR="$NEXUMI_DIR/config"
readonly MODELS_DIR="$NEXUMI_DIR/models"
readonly DATA_DIR="$NEXUMI_DIR/data"
readonly LOGS_DIR="$NEXUMI_DIR/logs"
readonly ASSETS_DIR="$NEXUMI_DIR/assets"
readonly VOSK_MODEL="vosk-model-small-en-us-0.15"
readonly VOSK_URL="https://alphacephei.com/vosk/models/${VOSK_MODEL}.zip"
readonly VOSK_PATH="$MODELS_DIR/$VOSK_MODEL"

# Colours
readonly R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' C='\033[0;36m'
readonly B='\033[1m' N='\033[0m'

# =============================================================================
# HELPERS
# =============================================================================

ok()   { echo -e "${G}[OK]${N}   $1"; }
info() { echo -e "${C}[INFO]${N} $1"; }
warn() { echo -e "${Y}[WARN]${N} $1"; }
fail() { echo -e "${R}[FAIL]${N} $1"; exit 1; }

header() {
    echo ""
    echo -e "${B}${C}════════════════════════════════════════════════════════════${N}"
    echo -e "${B}${C}  $1${N}"
    echo -e "${B}${C}════════════════════════════════════════════════════════════${N}"
}

# Atomic download with verification
download() {
    local url="$1" out="$2" tmp="${2}.part"
    if command -v wget &>/dev/null; then
        wget --show-progress --progress=bar:force --tries=3 --timeout=60 \
             -O "$tmp" "$url" || { rm -f "$tmp"; return 1; }
    elif command -v curl &>/dev/null; then
        curl -fsSL --progress-bar -o "$tmp" "$url" || { rm -f "$tmp"; return 1; }
    else
        fail "Neither wget nor curl is installed. Install one with: sudo pacman -S wget"
    fi
    # Verify non-empty
    [[ -s "$tmp" ]] || { rm -f "$tmp"; return 1; }
    mv "$tmp" "$out"
}

# Check if a pacman package is installed (fast)
has_pkg() { pacman -Q "$1" &>/dev/null; }

# =============================================================================
# BANNER
# =============================================================================

echo ""
echo -e "${B}╔══════════════════════════════════════════════════════════════╗${N}"
echo -e "${B}║         Nexumi  –  Dependency Installer                      ║${N}"
echo -e "${B}║         Arch Linux  |  PyQt6 WebEngine  |  NanamiNeural TTS  ║${N}"
echo -e "${B}╚══════════════════════════════════════════════════════════════╝${N}"
echo ""

# =============================================================================
# 1. ENVIRONMENT VALIDATION
# =============================================================================

header "Environment Validation"

# Python version
if ! command -v "$PYTHON" &>/dev/null; then
    fail "Python 3 is not installed. Install with: sudo pacman -S python"
fi

PY_VER=$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
info "Python $PY_VER detected"

if ! "$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
    fail "Python 3.10+ required (found $PY_VER)"
fi
ok "Python $PY_VER is supported"

# Display server
if [[ -z "${DISPLAY:-}" ]] && [[ -z "${WAYLAND_DISPLAY:-}" ]]; then
    warn "No graphical session detected — PyQt6 windows will not open"
    warn "Set DISPLAY=:0 if running via SSH with X11 forwarding"
else
    ok "Graphical session detected"
fi

# requirements.txt
if [[ ! -f "$REQ_FILE" ]]; then
    fail "requirements.txt not found at $REQ_FILE"
fi
ok "requirements.txt found"

# unzip (needed for Vosk model)
if ! command -v unzip &>/dev/null; then
    fail "unzip is required. Install with: sudo pacman -S unzip"
fi
ok "unzip available"

# =============================================================================
# 2. SYSTEM PACKAGES
# =============================================================================

header "System Packages"

# Define packages with descriptions
declare -A SYS_PKGS=(
    [portaudio]="PortAudio (microphone input)"
    [alsa-utils]="ALSA utilities"
    [alsa-lib]="ALSA library"
    [alsa-plugins]="ALSA plugins"
    [pipewire]="PipeWire audio server"
    [pipewire-pulse]="PipeWire PulseAudio compatibility"
    [wireplumber]="PipeWire session manager"
    [ffmpeg]="FFmpeg (audio conversion)"
    [mpg123]="mpg123 (MP3 decode for pygame)"
    [sdl2]="SDL2 (pygame backend)"
    [sdl2_mixer]="SDL2 mixer"
    [xdotool]="xdotool (desktop automation)"
    [xclip]="xclip (clipboard)"
    [xsel]="xsel (clipboard fallback)"
    [xorg-xrandr]="xrandr (display detection)"
    [python-pyqt6]="PyQt6 (GUI framework)"
    [python-pyqt6-webengine]="PyQt6 WebEngine (3D viewer)"
    [qt6-base]="Qt6 base libraries"
    [qt6-webengine]="Qt6 WebEngine (Chromium engine)"
    [qt6-declarative]="Qt6 QML support"
    [qt6-positioning]="Qt6 positioning"
    [qt6-wayland]="Qt6 Wayland support"
    [libxml2]="XML parsing"
    [libxslt]="XSLT processing"
    [git]="Git"
    [curl]="cURL"
    [wget]="Wget"
)

PKGS_MISSING=()
for pkg in "${!SYS_PKGS[@]}"; do
    if has_pkg "$pkg"; then
        echo "  ${G}✓${N}  $pkg"
    else
        echo "  ${Y}✗${N}  $pkg  — ${SYS_PKGS[$pkg]}"
        PKGS_MISSING+=("$pkg")
    fi
done

if [[ ${#PKGS_MISSING[@]} -gt 0 ]]; then
    echo ""
    info "Installing ${#PKGS_MISSING[@]} missing package(s)..."
    # Use -Sy to sync DB, --needed to skip installed, non-fatal on partial failure
    sudo pacman -Sy --needed --noconfirm "${PKGS_MISSING[@]}" \
        && ok "All missing packages installed" \
        || warn "Some packages failed — install manually if needed"
else
    ok "All system packages present"
fi

# =============================================================================
# 3. PYTHON VIRTUAL ENVIRONMENT
# =============================================================================

header "Python Virtual Environment"

if [[ ! -d "$VENV" ]]; then
    "$PYTHON" -m venv "$VENV" || fail "Failed to create virtual environment"
    ok "Created: $VENV"
else
    info "Reusing existing: $VENV"
fi

# Activate and upgrade tooling
source "$VENV/bin/activate" || fail "Failed to activate virtual environment"
pip install --upgrade pip wheel setuptools --quiet \
    && ok "pip, wheel, setuptools upgraded" \
    || warn "pip upgrade failed — continuing with existing version"

# =============================================================================
# 4. PYTHON DEPENDENCIES
# =============================================================================

header "Python Dependencies"

info "Installing from requirements.txt..."
pip install -r "$REQ_FILE" || fail "pip install failed — check requirements.txt"

ok "Python dependencies installed"

# Show key package versions
echo ""
echo "  Installed versions:"
for pkg in edge-tts pygame openai psutil websockets pyautogui vosk; do
    ver=$(pip show "$pkg" 2>/dev/null | awk '/^Version:/{print $2}') || ver="?"
    printf "    %-14s %s\n" "$pkg" "$ver"
done

# =============================================================================
# 5. VERIFY EDGE-TTS + NANAMINEURAL
# =============================================================================

header "TTS Voice Verification"

python3 - <<'PYEOF'
import asyncio, sys

async def check():
    G, Y, N = "\033[0;32m", "\033[1;33m", "\033[0m"
    try:
        import edge_tts
        voices = await edge_tts.list_voices()
        nanami = [v for v in voices if "NanamiNeural" in v.get("ShortName", "")]
        if nanami:
            v = nanami[0]
            print(f"  {G}[OK]{N}  {v['ShortName']}  |  {v['Locale']}")
            styles = v.get("StyleList") or []
            if styles:
                print(f"      Emotion styles: {', '.join(styles)}")
        else:
            print(f"  {G}[OK]{N}  Voice catalogue fetched — NanamiNeural available")
    except Exception as e:
        print(f"  {Y}[SKIP]{N} Cannot reach Microsoft TTS: {e}")
        print("      edge-tts requires internet at runtime only — this is OK")

asyncio.run(check())
PYEOF

# =============================================================================
# 6. CONFIGURATION SCAFFOLDING
# =============================================================================

header "Configuration"

# API keys
if [[ ! -f "$CONFIG_DIR/api_keys.env" ]]; then
    if [[ -f "$CONFIG_DIR/api_keys.env.example" ]]; then
        cp "$CONFIG_DIR/api_keys.env.example" "$CONFIG_DIR/api_keys.env"
        ok "Created config/api_keys.env from example"
    else
        cat > "$CONFIG_DIR/api_keys.env" << 'EOF'
# Nexumi API Configuration — DO NOT COMMIT TO GIT
OPENROUTER_API_KEY=
EOF
        ok "Created config/api_keys.env (fill in your OpenRouter key)"
    fi
    chmod 600 "$CONFIG_DIR/api_keys.env"
else
    info "config/api_keys.env already exists"
fi

# Settings JSON (first-run scaffold)
if [[ ! -f "$CONFIG_DIR/settings.json" ]]; then
    cat > "$CONFIG_DIR/settings.json" << 'EOF'
{
  "version": 2,
  "language": "en",
  "mood": "normal",
  "window": {
    "width": 350,
    "height": 600,
    "x": 1500,
    "y": 200,
    "always_on_top": true,
    "transparent": true,
    "frameless": true,
    "resizable": false
  },
  "theme": {
    "mode": "system",
    "accent_color": "#ff69b4",
    "font_family": "Noto Sans",
    "font_size": 12,
    "border_radius": 12
  },
  "tts": {
    "engine": "edge-tts",
    "voice": "ja-JP-NanamiNeural",
    "language": "en-US",
    "fallback": "pyttsx3",
    "rate": "+0%",
    "volume": "+0%",
    "pitch": "+0Hz",
    "cache_tts_audio": true,
    "cache_dir": "data/tts_cache"
  },
  "stt": {
    "primary": "google",
    "fallback": "vosk",
    "vosk_model_path": "models/vosk-model-small-en-us-0.15"
  },
  "ai": {
    "provider": "openrouter",
    "model": "google/gemma-4-31b-it:free",
    "temperature": 0.7,
    "max_tokens": 1024
  },
  "memory": {
    "short_term_k": 20,
    "db_path": "data/memory.db"
  },
  "desktop_control": {
    "safe_mode": true,
    "confirm_timeout_sec": 30,
    "default_directory": "/home/$USER",
    "pacman_command": "sudo pacman",
    "yay_command": "yay",
    "allow_destructive": true,
    "log_operations": true
  },
  "auto_start": false,
  "first_run": true
}
EOF
    ok "Created config/settings.json"
else
    info "config/settings.json already exists"
fi

# =============================================================================
# 7. VOSK OFFLINE STT MODEL
# =============================================================================

header "Vosk Speech Model"

if [[ -d "$VOSK_PATH" ]]; then
    info "Vosk model already present at $VOSK_PATH"
else
    info "Downloading $VOSK_MODEL (~40 MB)..."
    mkdir -p "$MODELS_DIR"
    TMP_ZIP="$MODELS_DIR/vosk_model.zip"

    if download "$VOSK_URL" "$TMP_ZIP"; then
        unzip -q "$TMP_ZIP" -d "$MODELS_DIR"
        rm -f "$TMP_ZIP"
        ok "Vosk model installed at $VOSK_PATH"
    else
        rm -f "$TMP_ZIP"
        warn "Vosk download failed — STT will use Google API only"
        warn "Retry manually: wget $VOSK_URL -O models/vosk_model.zip"
    fi
fi

# =============================================================================
# 8. DIRECTORY SCAFFOLDING
# =============================================================================

header "Directory Structure"

mkdir -p \
    "$DATA_DIR/screenshots" \
    "$DATA_DIR/tts_cache" \
    "$LOGS_DIR" \
    "$ASSETS_DIR/3d_model/expressions" \
    "$ASSETS_DIR/sounds" \
    "$MODELS_DIR"

ok "Directories created"

# 3D model check
VRM_PATH="$ASSETS_DIR/3d_model/nexumi.vrm"
if [[ -f "$VRM_PATH" ]]; then
    ok "3D model found: nexumi.vrm"
else
    warn "3D model not found at $VRM_PATH"
    warn "The built-in viewer will use a fallback. Place your .vrm file there for full avatar."
fi

# =============================================================================
# 9. FILE PERMISSIONS
# =============================================================================

header "Permissions"

for script in start_nexumi.sh stop_nexumi.sh setup.sh; do
    if [[ -f "$NEXUMI_DIR/$script" ]]; then
        chmod +x "$NEXUMI_DIR/$script"
        ok "Executable: $script"
    fi
done

chmod 600 "$CONFIG_DIR/api_keys.env" 2>/dev/null || true

# =============================================================================
# 10. SYSTEM INTEGRITY CHECK
# =============================================================================

header "System Integrity"

for cmd in aplay mpg123 pactl xdotool; do
    if command -v "$cmd" &>/dev/null; then
        ok "$cmd"
    else
        warn "$cmd not found"
    fi
done

# =============================================================================
# 11. OPTIONAL: zRAM CHECK
# =============================================================================

if [[ "${NEXUMI_CHECK_ZRAM:-}" == "1" ]]; then
    header "zRAM Status"
    if swapon --show 2>/dev/null | grep -q zram; then
        ok "zRAM is active"
    else
        info "zRAM not detected. To enable:"
        echo "    sudo pacman -S zram-generator"
        echo "    printf '[zram0]\\nzram-size = ram / 2\\ncompression-algorithm = zstd\\n' \\"
        echo "      | sudo tee /etc/systemd/zram-generator.conf"
        echo "    sudo systemctl daemon-reload"
        echo "    sudo systemctl start systemd-zram-setup@zram0"
    fi
fi

# =============================================================================
# DONE
# =============================================================================

echo ""
echo -e "${B}╔════════════════════════════════════════════════════════════════════╗${N}"
echo -e "${B}║  Setup complete.                                                   ║${N}"
echo -e "${B}╠════════════════════════════════════════════════════════════════════╣${N}"
echo -e "${B}║  Required next steps:                                              ║${N}"
echo -e "${B}║    1. Edit  config/api_keys.env                                    ║${N}"
echo -e "${B}║         OPENROUTER_API_KEY  →  https://openrouter.ai               ║${N}"
echo -e "${B}║    2. Place nexumi.vrm in assets/3d_model/ (optional)              ║${N}"
echo -e "${B}║    3. Run:  ./start_nexumi.sh                                      ║${N}"
echo -e "${B}╠════════════════════════════════════════════════════════════════════╣${N}"
echo -e "${B}║  Architecture:                                                     ║${N}"
echo -e "${B}║    • Wake word: Vosk keyword spotting                              ║${N}"
echo -e "${B}║    • STT: Google API + Vosk offline fallback                       ║${N}"
echo -e "${B}║    • TTS: edge-tts (ja-JP-NanamiNeural, streams at runtime)        ║${N}"
echo -e "${B}║    • Brain: OpenRouter via openai SDK                              ║${N}"
echo -e "${B}║    • GUI: PyQt6 + Qt6 WebEngine + Three.js (built-in 3D viewer)    ║${N}"
echo -e "${B}║    • Desktop: pyautogui + xdotool + desktop_control module         ║${N}"
echo -e "${B}╚════════════════════════════════════════════════════════════════════╝${N}"
echo ""
