#!/usr/bin/env bash
# =============================================================================
# Nexumi Installer
# =============================================================================
# Supported Platforms:
#   - Arch Linux
#   - EndeavourOS
#   - CachyOS
#   - Manjaro
#
# Features:
#   - Installs required system dependencies
#   - Validates Python version (3.10+ required)
#   - Creates Python virtual environment
#   - Installs Python packages from requirements.txt
#   - Downloads Vosk offline STT model (~40 MB)
#   - Creates required project directories
#   - Verifies installation integrity
#
# Usage:
#   git clone https://github.com/yourname/nexumi.git ~/nexumi
#   cd ~/nexumi
#   chmod +x install.sh
#   ./install.sh
# =============================================================================

set -euo pipefail

# =============================================================================
# VARIABLES
# =============================================================================

readonly PROJECT_NAME="Nexumi"
readonly PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly VENV_DIR="$PROJECT_DIR/venv"
readonly MODELS_DIR="$PROJECT_DIR/models"
readonly VOSK_MODEL_NAME="vosk-model-small-en-us-0.15"
readonly VOSK_MODEL_URL="https://alphacephei.com/vosk/models/${VOSK_MODEL_NAME}.zip"
readonly VOSK_MODEL_PATH="$MODELS_DIR/$VOSK_MODEL_NAME"
readonly REQUIREMENTS_FILE="$PROJECT_DIR/requirements.txt"

# =============================================================================
# COLOURS
# =============================================================================

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly CYAN='\033[0;36m'
readonly BOLD='\033[1m'
readonly RESET='\033[0m'

# =============================================================================
# HELPERS
# =============================================================================

ok()   { echo -e "${GREEN}[OK]${RESET}   $1"; }
info() { echo -e "${CYAN}[INFO]${RESET} $1"; }
warn() { echo -e "${YELLOW}[WARN]${RESET} $1"; }
fail() { echo -e "${RED}[FAIL]${RESET} $1"; exit 1; }

header() {
    echo ""
    echo -e "${BOLD}${CYAN}============================================================${RESET}"
    echo -e "${BOLD}${CYAN}  $1${RESET}"
    echo -e "${BOLD}${CYAN}============================================================${RESET}"
}

download_file() {
    local url="$1"
    local output="$2"
    local tmp_output="${output}.tmp"

    if command -v wget &>/dev/null; then
        wget --show-progress --progress=bar:force \
             --tries=3 --timeout=60 \
             -O "$tmp_output" "$url" || return 1
    elif command -v curl &>/dev/null; then
        curl -L --fail --progress-bar -o "$tmp_output" "$url" || return 1
    else
        fail "Neither wget nor curl is installed"
    fi

    # Verify download succeeded and file is non-empty
    if [[ ! -s "$tmp_output" ]]; then
        rm -f "$tmp_output"
        return 1
    fi

    mv "$tmp_output" "$output"
    return 0
}

# =============================================================================
# BANNER
# =============================================================================

echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e "${BOLD}                    Nexumi Installer                        ${RESET}"
echo -e "${BOLD}  GUI: PyQt6 + WebEngine  |  TTS: ja-JP-NanamiNeural         ${RESET}"
echo -e "${BOLD}============================================================${RESET}"
echo ""

# =============================================================================
# DISTRO CHECK
# =============================================================================

header "Checking Linux Distribution"

if ! command -v pacman &>/dev/null; then
    fail "This installer supports Arch-based distributions only (Arch, EndeavourOS, CachyOS, Manjaro)"
fi

DISTRO_NAME="$(grep '^NAME=' /etc/os-release | cut -d= -f2 | tr -d '"')"
ok "Detected: $DISTRO_NAME"

# =============================================================================
# PYTHON VERSION CHECK
# =============================================================================

header "Checking Python Version"

if ! command -v python3 &>/dev/null; then
    fail "Python 3 is not installed"
fi

PYTHON_VERSION="$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
info "Detected Python $PYTHON_VERSION"

if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
    fail "Python 3.10 or newer is required (detected $PYTHON_VERSION)"
fi

ok "Python $PYTHON_VERSION is supported"

# =============================================================================
# DISPLAY SERVER CHECK
# =============================================================================

header "Checking Display Environment"

if [[ -z "${DISPLAY:-}" ]] && [[ -z "${WAYLAND_DISPLAY:-}" ]]; then
    warn "No graphical session detected — PyQt6 windows will not open"
    warn "Set DISPLAY=:0 if running via SSH with X11 forwarding"
else
    ok "Graphical session detected"
fi

# =============================================================================
# REPOSITORY VALIDATION
# =============================================================================

header "Checking Repository Structure"

if [[ ! -f "$REQUIREMENTS_FILE" ]]; then
    fail "requirements.txt not found at $REQUIREMENTS_FILE"
fi

ok "requirements.txt found"

# =============================================================================
# SYSTEM PACKAGES
# =============================================================================

header "Installing System Packages"

# Check for unzip before we need it
if ! command -v unzip &>/dev/null; then
    fail "unzip is required but not installed. Install with: sudo pacman -S unzip"
fi

SYSTEM_PACKAGES=(
    git curl wget unzip
    python python-pip
    portaudio
    alsa-utils alsa-lib alsa-plugins
    pipewire pipewire-pulse wireplumber
    mpg123
    ffmpeg
    sdl2 sdl2_mixer
    xdotool xclip xsel xorg-xrandr
    python-pyqt6
    python-pyqt6-webengine
    qt6-base
    qt6-webengine
    qt6-declarative
    qt6-positioning
    qt6-wayland
    libxml2 libxslt
)

warn "Running pacman -Sy --needed — this syncs the package database"
warn "Run 'sudo pacman -Syu' manually if you also want to upgrade all packages"

sudo pacman -Sy --needed --noconfirm "${SYSTEM_PACKAGES[@]}" \
    && ok "System packages installed" \
    || warn "Some system packages failed — check output above and install manually if needed"

# =============================================================================
# PYTHON VIRTUAL ENVIRONMENT
# =============================================================================

header "Setting Up Python Virtual Environment"

if [[ ! -d "$VENV_DIR" ]]; then
    info "Creating virtual environment..."
    python3 -m venv "$VENV_DIR" && ok "Virtual environment created at $VENV_DIR" \
        || fail "Failed to create virtual environment"
else
    warn "Virtual environment already exists at $VENV_DIR — reusing it"
fi

# =============================================================================
# PYTHON TOOLING
# =============================================================================

header "Upgrading Python Tooling"

"$VENV_DIR/bin/python" -m pip install --upgrade pip setuptools wheel \
    && ok "pip, setuptools, wheel upgraded" \
    || warn "pip upgrade failed — continuing with existing version"

# =============================================================================
# PYTHON DEPENDENCIES
# =============================================================================

header "Installing Python Dependencies"

"$VENV_DIR/bin/pip" install -r "$REQUIREMENTS_FILE" \
    && ok "Python dependencies installed" \
    || fail "pip install failed — check requirements.txt and the output above"

# =============================================================================
# PROJECT DIRECTORIES
# =============================================================================

header "Creating Project Directories"

mkdir -p "$PROJECT_DIR/logs"
mkdir -p "$PROJECT_DIR/data/screenshots"
mkdir -p "$PROJECT_DIR/assets/3d_model/expressions"
mkdir -p "$PROJECT_DIR/config"
mkdir -p "$MODELS_DIR"

ok "Project directories created"

# =============================================================================
# 3D AVATAR ASSET CHECK
# =============================================================================

header "Checking 3D Avatar Asset"

VRM_PATH="$PROJECT_DIR/assets/3d_model/nexumi.vrm"
if [[ -f "$VRM_PATH" ]]; then
    ok "3D model found: $VRM_PATH"
else
    warn "3D model not found at $VRM_PATH"
    warn "The built-in PyQt6 + Three.js viewer will show a fallback until you place nexumi.vrm there"
fi

# =============================================================================
# FILE PERMISSIONS
# =============================================================================

header "Setting File Permissions"

for file in install.sh start_nexumi.sh stop_nexumi.sh; do
    if [[ -f "$PROJECT_DIR/$file" ]]; then
        chmod +x "$PROJECT_DIR/$file"
        ok "Executable: $file"
    fi
done

# =============================================================================
# API KEY CONFIGURATION
# =============================================================================

header "API Key Configuration"

ENV_FILE="$PROJECT_DIR/config/api_keys.env"

configure_api_key() {
    local key=""
    local masked=""
    local confirm=""

    if [[ -f "$ENV_FILE" ]]; then
        local existing=""
        existing=$(grep "^OPENROUTER_API_KEY=" "$ENV_FILE" 2>/dev/null | cut -d= -f2- || true)
        if [[ -n "$existing" ]]; then
            warn "Existing API key found in $ENV_FILE"
            read -rp "  Use existing key? [Y/n]: " confirm || true
            if [[ "${confirm:-}" =~ ^[Nn]$ ]]; then
                info "Replacing existing key..."
            else
                ok "Keeping existing API key"
                return
            fi
        fi
    fi

    echo ""
    info "Get your free API key at: https://openrouter.ai"
    echo ""
    read -rsp "  Enter OpenRouter API key (input hidden): " key || true
    echo ""

    if [[ -z "${key:-}" ]]; then
        warn "No key entered — skipping"
        warn "You must add OPENROUTER_API_KEY manually before starting Nexumi"
        return
    fi

    masked="${key:0:4}****${key: -4}"
    echo "  Key entered: $masked"
    read -rp "  Save this key? [Y/n]: " confirm || true
    echo ""

    if [[ "${confirm:-}" =~ ^[Nn]$ ]]; then
        warn "Key not saved"
        return
    fi

    cat > "$ENV_FILE" << ENVEOF
# =============================================================================
# Nexumi API Configuration
# =============================================================================
# Do NOT commit this file to git

OPENROUTER_API_KEY=$key
ENVEOF

    ok "API key saved to $ENV_FILE"
    chmod 600 "$ENV_FILE"

    # Optional validation
    info "Validating API key with OpenRouter..."
    local test_result
    test_result=$("$VENV_DIR/bin/python" << PYTEST 2>&1
import os, sys
try:
    from openai import OpenAI
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="$key"
    )
    resp = client.chat.completions.create(
        model="google/gemma-4-31b-it:free",
        messages=[{"role": "user", "content": "Say OK"}],
        max_tokens=5
    )
    print("VALID" if "OK" in resp.choices[0].message.content else "INVALID")
except Exception as e:
    print("ERROR:", str(e)[:80])
PYTEST
) || test_result="ERROR: validation script failed"

    if [[ "$test_result" == VALID* ]]; then
        ok "API key validated successfully"
    else
        warn "API key validation failed: $test_result"
        warn "The key was saved, but Nexumi may not work until fixed"
    fi
}

configure_api_key

# =============================================================================
# VOSK OFFLINE STT MODEL
# =============================================================================

header "Installing Vosk Speech Model"

if [[ -d "$VOSK_MODEL_PATH" ]]; then
    warn "Vosk model already exists at $VOSK_MODEL_PATH"
else
    TEMP_ZIP="$MODELS_DIR/${VOSK_MODEL_NAME}.zip"
    info "Downloading $VOSK_MODEL_NAME (~40 MB)..."

    if download_file "$VOSK_MODEL_URL" "$TEMP_ZIP"; then
        info "Extracting..."
        unzip -q "$TEMP_ZIP" -d "$MODELS_DIR"
        rm -f "$TEMP_ZIP"
        ok "Vosk model installed at $VOSK_MODEL_PATH"
    else
        rm -f "$TEMP_ZIP"
        warn "Vosk model download failed — STT will fall back to Google API only"
        warn "Retry manually later:"
        warn "  wget $VOSK_MODEL_URL -O models/${VOSK_MODEL_NAME}.zip"
        warn "  unzip models/${VOSK_MODEL_NAME}.zip -d models/"
    fi
fi

# =============================================================================
# VERIFICATION
# =============================================================================

header "Verifying Installation"

echo ""
"$VENV_DIR/bin/python" << 'PYCHECK'
import importlib
import sys

GREEN  = "\033[0;32m"
RED    = "\033[0;31m"
YELLOW = "\033[1;33m"
RESET  = "\033[0m"

checks = [
    ("websockets",               "websockets",                  False),
    ("dotenv",                   "python-dotenv",               False),
    ("psutil",                   "psutil",                      False),
    ("openai",                   "openai  (OpenRouter brain)",  False),
    ("httpx",                    "httpx",                       False),
    ("aiohttp",                  "aiohttp",                     False),
    ("speech_recognition",       "SpeechRecognition",           False),
    ("pyaudio",                  "pyaudio",                     False),
    ("vosk",                     "vosk",                        False),
    ("edge_tts",                 "edge-tts  (NanamiNeural)",    False),
    ("pyttsx3",                  "pyttsx3   (TTS fallback)",    False),
    ("pygame",                   "pygame    (audio playback)",  False),
    ("pyautogui",                "pyautogui",                   False),
    ("mss",                      "mss",                         False),
    ("PIL",                      "Pillow",                      False),
    ("bs4",                      "beautifulsoup4",              False),
    ("lxml",                     "lxml",                        False),
    ("PyQt6.QtWidgets",          "PyQt6",                       False),
    ("PyQt6.QtWebEngineWidgets", "PyQt6-WebEngine (3D viewer)", True),
]

passed = failed = optional_missing = 0

for module, label, optional in checks:
    try:
        importlib.import_module(module)
        print(f"  {GREEN}[OK]{RESET}   {label}")
        passed += 1
    except ImportError as e:
        if optional:
            print(f"  {YELLOW}[OPT]{RESET}  {label}  (optional)")
            optional_missing += 1
        else:
            print(f"  {RED}[FAIL]{RESET} {label}  ({e})")
            failed += 1

print("")
print(f"  {passed} OK  |  {optional_missing} optional  |  {failed} failed")

if failed > 0:
    print(f"\n  {RED}Some required packages failed. Re-run install.sh or install manually.{RESET}")
    sys.exit(1)
PYCHECK

echo ""
info "Verifying edge-tts / NanamiNeural voice (requires internet)..."
"$VENV_DIR/bin/python" << 'VOICECHECK'
import asyncio

async def check():
    GREEN  = "\033[0;32m"
    YELLOW = "\033[1;33m"
    RESET  = "\033[0m"
    try:
        import edge_tts
        voices = await edge_tts.list_voices()
        hit = next(
            (v for v in voices if "NanamiNeural" in v.get("ShortName", "")), None
        )
        if hit:
            styles = hit.get("StyleList") or []
            print(f"  {GREEN}[OK]{RESET}   {hit['ShortName']}  |  {hit['Locale']}")
            if styles:
                print(f"         Emotion styles: {', '.join(styles)}")
        else:
            print(f"  {GREEN}[OK]{RESET}   Voice catalogue fetched")
    except Exception as exc:
        print(f"  {YELLOW}[SKIP]{RESET} Cannot reach Microsoft TTS: {exc}")
        print("         edge-tts only needs internet at runtime, not install time")

asyncio.run(check())
VOICECHECK

echo ""
info "Checking system commands..."
for cmd in aplay mpg123 pactl xdotool; do
    if command -v "$cmd" &>/dev/null; then
        ok "$cmd"
    else
        pkg=""
        case $cmd in
            aplay)   pkg="alsa-utils";;
            mpg123)  pkg="mpg123";;
            pactl)   pkg="pipewire-pulse";;
            xdotool) pkg="xdotool";;
        esac
        warn "$cmd not found — install with: sudo pacman -S $pkg"
    fi
done

# =============================================================================
# DONE
# =============================================================================

echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e "${BOLD}  ${PROJECT_NAME} installation complete.${RESET}"
echo -e "${BOLD}============================================================${RESET}"
echo ""
echo "  Next steps:"
echo ""
echo "  1. (Optional) Place your VRM model for the 3D avatar:"
echo "       assets/3d_model/nexumi.vrm"
echo "     The built-in PyQt6 + Three.js viewer will load it automatically."
echo ""
echo "  2. Start Nexumi:"
echo "       ./start_nexumi.sh"
echo ""
echo "  Wake word detection uses Vosk (keyword spotting) — no extra setup."
echo "  TTS: ja-JP-NanamiNeural — streams at runtime, no model download."
echo -e "${BOLD}============================================================${RESET}"
echo ""
