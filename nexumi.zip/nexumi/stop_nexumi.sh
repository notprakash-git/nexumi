#!/usr/bin/env bash
# =============================================================================
#  stop_nexumi.sh
#  Gracefully stops all running Nexumi components.
#
#  Strategy:
#    1. Read nexumi.pids and send SIGTERM to each process
#    2. Wait up to 5 seconds per process for clean exit
#    3. Send SIGKILL to anything that refuses to stop
#    4. Fall back to pkill by module name if PID file is missing
#    5. Confirm everything is dead and remove the PID file
#
#  Usage:
#    ./stop_nexumi.sh           -- normal stop
#    ./stop_nexumi.sh --force   -- skip wait, go straight to SIGKILL
# =============================================================================
set -uo pipefail

NEXUMI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="$NEXUMI_DIR/data/nexumi.pids"
FORCE="${1:-}"

# ── Colours ───────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

ok()   { echo -e "  ${GREEN}[OK]${RESET}   $*"; }
warn() { echo -e "  ${YELLOW}[WARN]${RESET} $*"; }
fail() { echo -e "  ${RED}[FAIL]${RESET} $*"; }
info() { echo -e "  ${CYAN}....${RESET}  $*"; }

echo ""
echo -e "${BOLD}============================================================${RESET}"
echo -e "${BOLD}  Nexumi  --  Stopping                                      ${RESET}"
echo -e "${BOLD}============================================================${RESET}"
echo ""

# ── Verify required tools ─────────────────────────────────────────────────────
for _tool in pgrep pkill; do
    if ! command -v "$_tool" &>/dev/null; then
        warn "$_tool not found — install procps-ng:"
        warn "  sudo pacman -S procps-ng"
        warn "Falling back to kill/ps only — some checks may be incomplete."
    fi
done

# =============================================================================
# _stop_pid  pid  name
#
# Sends SIGTERM, waits up to 5 seconds, then sends SIGKILL if needed.
# =============================================================================
_stop_pid() {
    local pid="$1"
    local name="$2"

    # Already dead
    if ! kill -0 "$pid" 2>/dev/null; then
        warn "$name (PID $pid) was already stopped"
        return 0
    fi

    if [ "$FORCE" = "--force" ]; then
        info "Force-killing $name (PID $pid) ..."
        kill -9 "$pid" 2>/dev/null || true
        ok "$name killed"
        return 0
    fi

    info "Stopping $name (PID $pid) ..."
    kill -TERM "$pid" 2>/dev/null || true

    # Wait up to 5 seconds for clean exit
    local waited=0
    while kill -0 "$pid" 2>/dev/null; do
        sleep 0.5
        waited=$((waited + 1))
        if [ "$waited" -ge 10 ]; then
            warn "$name did not exit after 5s -- sending SIGKILL"
            kill -9 "$pid" 2>/dev/null || true
            sleep 0.3
            break
        fi
    done

    if kill -0 "$pid" 2>/dev/null; then
        fail "$name (PID $pid) could not be stopped"
        return 1
    else
        ok "$name stopped"
        return 0
    fi
}

# =============================================================================
# Main stop logic
# =============================================================================
if [ -f "$PID_FILE" ]; then
    # Stop in reverse order (UI first, WebSocket server last)
    mapfile -t ENTRIES < "$PID_FILE"

    # Reverse the array
    REVERSED=()
    for (( i=${#ENTRIES[@]}-1; i>=0; i-- )); do
        REVERSED+=("${ENTRIES[$i]}")
    done

    for entry in "${REVERSED[@]}"; do
        IFS='|' read -r pid name _log <<< "$entry"
        [ -z "$pid" ] && continue
        _stop_pid "$pid" "$name"
    done

    rm -f "$PID_FILE"
    ok "PID file removed"

else
    # No PID file -- fall back to pkill by module name
    warn "PID file not found at $PID_FILE"
    warn "Falling back to pkill by module name..."
    echo ""

    # Stop in reverse boot order
    MODULES=(
        "src.ui.desktop_mate"
        "src.utils.resource_monitor"
        "src.core.wakeword"
        "src.ui.websocket_server"
    )

    for mod in "${MODULES[@]}"; do
        if pgrep -f "$mod" > /dev/null 2>&1; then
            info "Stopping processes matching: $mod"
            pkill -TERM -f "$mod" 2>/dev/null || true
            sleep 1
            # Force-kill stragglers
            if pgrep -f "$mod" > /dev/null 2>&1; then
                pkill -9 -f "$mod" 2>/dev/null || true
            fi
            ok "Stopped: $mod"
        else
            warn "Not running: $mod"
        fi
    done
fi

# =============================================================================
# Final confirmation -- check nothing is still alive
# =============================================================================
echo ""
echo -e "${BOLD}  Verifying all components stopped...${RESET}"

REMAINING=0
for mod in "src.ui.websocket_server" "src.core.wakeword" \
           "src.utils.resource_monitor" "src.ui.desktop_mate"; do
    if pgrep -f "$mod" > /dev/null 2>&1; then
        fail "Still running: $mod  (PIDs: $(pgrep -f "$mod" | tr '\n' ' '))"
        REMAINING=$((REMAINING + 1))
    fi
done

echo ""
if [ "$REMAINING" -eq 0 ]; then
    echo -e "${BOLD}============================================================${RESET}"
    ok "All Nexumi components stopped."
    echo -e "${BOLD}============================================================${RESET}"
else
    echo -e "${BOLD}============================================================${RESET}"
    warn "$REMAINING component(s) could not be stopped."
    warn "Try: ./stop_nexumi.sh --force"
    echo -e "${BOLD}============================================================${RESET}"
fi
echo ""
